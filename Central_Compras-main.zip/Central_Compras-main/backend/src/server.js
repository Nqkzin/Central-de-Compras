import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import { db } from './database/database.js';

// Routes
import authRoutes from './routes/auth.js';
import storeRoutes from './routes/stores.js';
import supplierRoutes from './routes/suppliers.js';
import productRoutes from './routes/products.js';
import orderRoutes from './routes/orders.js';
import campaignRoutes from './routes/campaigns.js';
import stateConditionRoutes from './routes/stateConditions.js';
import contactRoutes from './routes/contacts.js';
import uploadRoutes from './routes/upload.js';
import categoryRoutes from './routes/categories.js';

// Configurar variáveis de ambiente
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const envPath = path.resolve(__dirname, '../.env');
console.log('🔍 Procurando arquivo .env em:', envPath);
dotenv.config({ path: envPath });

// Verificar se as variáveis foram carregadas
console.log('📧 RESEND_API_KEY:', process.env.RESEND_API_KEY ? '✅ Configurada (' + process.env.RESEND_API_KEY.substring(0, 10) + '...)' : '❌ NÃO configurada');
console.log('📬 RESEND_FROM_EMAIL:', process.env.RESEND_FROM_EMAIL || '❌ NÃO configurado');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos com CORS
app.use('/uploads', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET');
  res.header('Cross-Origin-Resource-Policy', 'cross-origin');
  next();
}, express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/stores', storeRoutes);
app.use('/api/suppliers', supplierRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/campaigns', campaignRoutes);
app.use('/api/state-conditions', stateConditionRoutes);
app.use('/api/contacts', contactRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/categories', categoryRoutes);

// Rota de health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);  
});