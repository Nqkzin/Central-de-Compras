import express from 'express';
import { db } from '../database/database.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const router = express.Router();

// Utilitário para montar payload unificado de usuário, suportando múltiplas lojas/fornecedores
async function buildUserPayload(userRow) {
  // Perfis do usuário
  const perfisRes = await db.query(
    'SELECT perfil FROM tb_sistema_usuario_perfil WHERE id_usuario = $1',
    [userRow.id]
  );
  const perfis = perfisRes.rows.map(r => r.perfil);
  let user_type = 'user';
  if (perfis.includes('admin')) user_type = 'admin';
  else if (perfis.includes('store')) user_type = 'store';
  else if (perfis.includes('supplier')) user_type = 'supplier';

  // Todas as lojas vinculadas (pode haver mais de uma se reutilizar email)
  let store_ids = [];
  try {
    const lojasRes = await db.query(
      'SELECT id FROM tb_loja WHERE id_usuario_owner = $1 AND ativo = true ORDER BY dt_inc DESC',
      [userRow.id]
    );
    store_ids = lojasRes.rows.map(r => r.id);
  } catch {}

  // Todas os fornecedores vinculados
  let supplier_ids = [];
  try {
    const fornRes = await db.query(
      'SELECT id FROM tb_fornecedor WHERE id_usuario_owner = $1 AND ativo = true ORDER BY dt_inc DESC',
      [userRow.id]
    );
    supplier_ids = fornRes.rows.map(r => r.id);
  } catch {}

  // Manter compatibilidade: se houver exatamente uma loja/fornecedor, expor store_id/supplier_id direto.
  const store_id = store_ids.length === 1 ? store_ids[0] : null;
  const supplier_id = supplier_ids.length === 1 ? supplier_ids[0] : null;

  return {
    id: userRow.id,
    email: userRow.email,
    full_name: userRow.nome,
    user_type,
    role: user_type,
    store_id,
    supplier_id,
    store_ids,
    supplier_ids,
  };
}

// POST /api/auth/login - autenticação baseada no banco
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email e senha são obrigatórios' });

    // Busca usuário ativo pelo email (escopo por conta opcional)
    const userRes = await db.query(
      `SELECT id, id_conta, nome, email, senha, ativo,
              COALESCE(must_change_password, false) AS must_change_password
       FROM tb_sistema_usuario 
       WHERE email = $1 AND ativo = true LIMIT 1`,
      [email]
    );
    if (userRes.rows.length === 0) return res.status(401).json({ error: 'Credenciais inválidas' });
    const user = userRes.rows[0];

    const ok = await bcrypt.compare(password, user.senha);
    if (!ok) return res.status(401).json({ error: 'Credenciais inválidas' });

    // Bloqueia login se todas as lojas/fornecedores vinculados estiverem inativos
    const lojasRes = await db.query('SELECT ativo FROM tb_loja WHERE id_usuario_owner = $1', [user.id]);
    const fornRes = await db.query('SELECT ativo FROM tb_fornecedor WHERE id_usuario_owner = $1', [user.id]);
    const lojas = lojasRes.rows.map(r => r.ativo);
    const forn = fornRes.rows.map(r => r.ativo);
    const hasAnyBinding = lojas.length > 0 || forn.length > 0;
    const anyActive = [...lojas, ...forn].some(v => v === true);
    if (hasAnyBinding && !anyActive) {
      return res.status(403).json({ error: 'Conta inativa. Contate o administrador.' });
    }

    const payload = await buildUserPayload(user);
    const token = jwt.sign({ sub: user.id, acc: user.id_conta, mcp: user.must_change_password ? 1 : 0 }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '12h' });

    res.json({ token, user: payload, require_password_change: user.must_change_password === true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/auth/change-password - troca senha e limpa flag de 1º acesso
router.post('/change-password', async (req, res) => {
  try {
    const auth = req.headers.authorization || '';
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Não autenticado' });
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret');
    } catch (e) {
      return res.status(401).json({ error: 'Token inválido' });
    }

    const { current_password, new_password } = req.body || {};
    if (!new_password || new_password.length < 6) {
      return res.status(400).json({ error: 'Nova senha deve ter ao menos 6 caracteres' });
    }

    const userRes = await db.query(
      `SELECT id, senha, COALESCE(must_change_password, false) AS must_change_password
       FROM tb_sistema_usuario WHERE id = $1 AND ativo = true`,
      [decoded.sub]
    );
    if (userRes.rows.length === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    const user = userRes.rows[0];

    // Se flag exige troca, current_password é opcional; se não exige, pedimos validação
    if (!user.must_change_password) {
      if (!current_password) return res.status(400).json({ error: 'Senha atual é obrigatória' });
      const ok = await bcrypt.compare(current_password, user.senha);
      if (!ok) return res.status(401).json({ error: 'Senha atual incorreta' });
    }

    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(new_password, salt);
    await db.query(
      `UPDATE tb_sistema_usuario SET senha = $1, must_change_password = false WHERE id = $2`,
      [hash, decoded.sub]
    );

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Rota para obter dados do usuário atual
// GET /api/auth/me - retorna usuário atual baseado no JWT
router.get('/me', async (req, res) => {
  try {
    const auth = req.headers.authorization || '';
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Não autenticado' });
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret');
    } catch (e) {
      return res.status(401).json({ error: 'Token inválido' });
    }

    const userRes = await db.query(
      'SELECT id, id_conta, nome, email FROM tb_sistema_usuario WHERE id = $1 AND ativo = true',
      [decoded.sub]
    );
    if (userRes.rows.length === 0) return res.status(401).json({ error: 'Usuário não encontrado' });

    const payload = await buildUserPayload(userRes.rows[0]);
    res.json(payload);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;