// routes/contacts.js
import express from 'express';
import { db } from '../database/database.js';

const router = express.Router();

// GET /api/contacts
router.get('/', async (req, res) => {
  try {
    const { supplier_id } = req.query;
    
    let query = `
      SELECT 
        id, nome as name, email, telefone as phone, cargo as position,
        is_responsavel as is_primary, outras_informacoes as notes,
        id_fornecedor as supplier_id, dt_inc as created_date
      FROM tb_contato
      WHERE id_fornecedor IS NOT NULL
    `;
    
    const params = [];
    let paramCount = 0;

    if (supplier_id) {
      paramCount++;
      query += ` AND id_fornecedor = $${paramCount}`;
      params.push(supplier_id);
    }

    query += ' ORDER BY dt_inc DESC';

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/contacts
router.post('/', async (req, res) => {
  try {
    const {
      name, email, phone, position, is_primary, notes, supplier_id, id_conta
    } = req.body;
    let accountId = id_conta ?? null;
    // Fallback: tenta pegar conta do fornecedor ou qualquer conta existente
    if (!accountId && supplier_id) {
      try {
        const sAcc = await db.query('SELECT id_conta FROM tb_fornecedor WHERE id = $1', [supplier_id]);
        if (sAcc.rows.length && sAcc.rows[0].id_conta) {
          accountId = sAcc.rows[0].id_conta;
        }
      } catch {}
    }
    if (!accountId) {
      const accRes = await db.query('SELECT id FROM tb_sistema_conta LIMIT 1');
      if (accRes.rows.length) accountId = accRes.rows[0].id;
    }
    if (!accountId) {
      const newAcc = await db.query(
        'INSERT INTO tb_sistema_conta (nm_conta, dh_inc) VALUES ($1, CURRENT_TIMESTAMP) RETURNING id',
        ['Conta Padrão']
      );
      accountId = newAcc.rows[0].id;
    }

    const result = await db.query(
      `INSERT INTO tb_contato (
        nome, email, telefone, cargo, outras_informacoes, is_responsavel, id_fornecedor, id_conta
  ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING 
        id, nome as name, email, telefone as phone, cargo as position,
        outras_informacoes as notes, is_responsavel as is_primary,
        id_fornecedor as supplier_id, dt_inc as created_date`,
      [name, email, phone, position || null, notes || null, is_primary || false, supplier_id, accountId]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /api/contacts/:id
router.put('/:id', async (req, res) => {
  try {
    const {
      name, email, phone, position, is_primary, notes
    } = req.body;

    const result = await db.query(
      `UPDATE tb_contato SET 
        nome = $1, email = $2, telefone = $3, 
        cargo = $4, outras_informacoes = $5, is_responsavel = $6
      WHERE id = $7
      RETURNING 
        id, nome as name, email, telefone as phone, cargo as position,
        outras_informacoes as notes, is_responsavel as is_primary,
        id_fornecedor as supplier_id, dt_inc as created_date`,
      [name, email, phone, position || null, notes || null, is_primary || false, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/contacts/:id
router.delete('/:id', async (req, res) => {
  try {
    const result = await db.query(
      'DELETE FROM tb_contato WHERE id = $1 RETURNING id',
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;