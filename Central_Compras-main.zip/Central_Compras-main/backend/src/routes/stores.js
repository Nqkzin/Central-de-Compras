import express from 'express';
import { db } from '../database/database.js';
import bcrypt from 'bcryptjs';
import { sendWelcomeEmail } from '../services/emailService.js';

const router = express.Router();

// Helper: gera email padronizado @central.com a partir do nome completo
function generateCentralEmail(fullName) {
  if (!fullName || typeof fullName !== 'string') return 'usuario@central.com';
  
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'usuario@central.com';
  
  const firstName = parts[0].toLowerCase();
  const lastName = parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
  
  // Remove acentos e caracteres especiais
  const normalize = (str) => str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  
  const firstNormalized = normalize(firstName);
  const lastNormalized = normalize(lastName);
  
  if (lastNormalized) {
    return `${firstNormalized}.${lastNormalized}@central.com`;
  }
  return `${firstNormalized}@central.com`;
}

// Helper simples para extrair id do usuário autenticado (usado na aprovação de cashback)
async function getUserIdFromRequest(req) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return null;
  try {
    const jwt = (await import('jsonwebtoken')).default;
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret');
    return decoded.sub || null;
  } catch {
    return null;
  }
}

// GET /api/stores - Listar todas as lojas
router.get('/', async (req, res) => {
  try {
    const { status, sort, id } = req.query;
    let query = `
      SELECT 
        l.id,
        l.razao_social as name,
        l.nome_fantasia as fantasy_name,
        l.cnpj,
        l.inscricao_estadual,
        l.site,
        l.termo_aceito,
        le.logradouro as address,
        le.numero as address_number,
        le.bairro as neighborhood,
        le.referencia as reference,
        le.cidade as city,
        le.estado as state,
        le.cep as zip_code,
        c.nome as responsible_name,
        c.email as responsible_email,
        l.telefone as responsible_phone,
  CASE WHEN l.ativo = true THEN 'active' ELSE 'inactive' END as status,
        l.id_usuario_owner as user_id
      FROM tb_loja l
      LEFT JOIN tb_loja_endereco le ON l.id = le.id_loja AND le.is_endereco_principal = true
      LEFT JOIN tb_contato c ON l.id = c.id_loja AND c.is_responsavel = true
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (id) {
      const rawId = Array.isArray(id) ? id[0] : id;
      const numericId = Number(rawId);
      if (!Number.isInteger(numericId)) {
        return res.status(400).json({ error: 'Invalid store id filter' });
      }
      paramCount++;
      query += ` AND l.id = $${paramCount}`;
      params.push(numericId);
    }

    if (status) {
      paramCount++;
      query += ` AND l.ativo = $${paramCount}`;
      params.push(status === 'active');
    }

    if (sort) {
      const sortField = sort.startsWith('-') ? sort.slice(1) : sort;
      const sortOrder = sort.startsWith('-') ? 'DESC' : 'ASC';
      // Map friendly sort fields used by frontend to actual DB columns
      const sortMap = {
        created_date: 'l.dt_inc',
        name: 'l.razao_social',
        cnpj: 'l.cnpj'
      };
      const sortColumn = sortMap[sortField] || sortField;
      query += ` ORDER BY ${sortColumn} ${sortOrder}`;
    } else {
      query += ' ORDER BY l.razao_social ASC';
    }

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/stores/cashback/summary - resumo por loja (admin)
router.get('/cashback/summary', async (_req, res) => {
  try {
    const result = await db.query(
      `SELECT 
         l.id AS store_id,
         l.nome_fantasia AS store_name,
         l.cnpj,
         l.ativo AS is_active,
         COALESCE(cb.total_previsto, 0) AS total_previsto,
         COALESCE(cb.total_realizado, 0) AS total_realizado,
         COALESCE(cb.orders_with_cashback, 0) AS orders_with_cashback
       FROM tb_loja l
       LEFT JOIN (
         SELECT lc.id_loja,
                SUM(d.vl_previsto) AS total_previsto,
                SUM(COALESCE(d.vl_realizado, 0)) AS total_realizado,
                COUNT(DISTINCT lc.id_pedido) AS orders_with_cashback
         FROM tb_loja_cashback_detalhes d
         JOIN tb_loja_cashback lc ON lc.id = d.id_cashback
         JOIN tb_pedido p ON p.id = lc.id_pedido
         WHERE TRIM(UPPER(COALESCE(p.status, ''))) <> 'CANCELADO'
         GROUP BY lc.id_loja
       ) cb ON cb.id_loja = l.id
       ORDER BY l.nome_fantasia ASC`
    );
    const payload = result.rows.map(row => ({
      store_id: row.store_id,
      store_name: row.store_name,
      cnpj: row.cnpj,
      is_active: row.is_active,
      total_previsto: Number(row.total_previsto || 0),
      total_realizado: Number(row.total_realizado || 0),
      orders_with_cashback: Number(row.orders_with_cashback || 0),
    }));
    res.json(payload);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/stores/cashback/pending - lista de cashbacks previstos ainda não realizados (admin)
router.get('/cashback/pending', async (_req, res) => {
  try {
    const result = await db.query(
      `SELECT 
          d.id,
          d.id_loja,
          l.razao_social AS store_name,
          d.id_fornecedor,
          f.razao_social AS supplier_name,
          d.vl_previsto,
          d.vl_realizado,
          d.dt_inc,
          d.id_cashback,
          d.id_pedido_item
         FROM tb_loja_cashback_detalhes d
         LEFT JOIN tb_loja l ON l.id = d.id_loja
         LEFT JOIN tb_fornecedor f ON f.id = d.id_fornecedor
         WHERE COALESCE(d.vl_realizado, 0) = 0`);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/stores/cashback/:id/approve - aprovar um cashback previsto e marcar como realizado
router.post('/cashback/:id/approve', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const detailId = Number(req.params.id);
    if (!Number.isFinite(detailId)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'ID de cashback inválido.' });
    }

    const { amount } = req.body || {};

    // Buscar detalhe atual
    const detailRes = await client.query(
      `SELECT id, vl_previsto, vl_realizado
         FROM tb_loja_cashback_detalhes
        WHERE id = $1
        FOR UPDATE`,
      [detailId]
    );
    if (detailRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Registro de cashback não encontrado.' });
    }
    const detail = detailRes.rows[0];

    // Se já tiver vl_realizado > 0, não reaprovar
    if (detail.vl_realizado && Number(detail.vl_realizado) > 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Este cashback já foi aprovado.' });
    }

    // Valor realizado padrão: igual ao previsto, salvo se o admin mandar outro valor positivo
    const basePrevisto = Number(detail.vl_previsto || 0);
    let realized = basePrevisto;
    if (amount !== undefined && amount !== null && amount !== '') {
      const num = Number(amount);
      if (!Number.isFinite(num) || num < 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Valor realizado inválido.' });
      }
      realized = num;
    }

    const userId = await getUserIdFromRequest(req);

    const updateRes = await client.query(
      `UPDATE tb_loja_cashback_detalhes
          SET vl_realizado = $1,
              id_usuario = COALESCE($2, id_usuario)
        WHERE id = $3
        RETURNING *`,
      [realized, userId, detailId]
    );

    await client.query('COMMIT');
    res.json(updateRes.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

// GET /api/stores/:id - Buscar loja por ID
router.get('/:id', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT 
        l.id,
        l.razao_social as name,
        l.nome_fantasia as fantasy_name,
        l.cnpj,
        l.inscricao_estadual,
        l.site,
        l.termo_aceito,
        le.logradouro || ' ' || COALESCE(le.numero, '') || ' ' || COALESCE(le.complemento, '') as address,
        le.numero as address_number,
        le.bairro as neighborhood,
        le.referencia as reference,
        le.cidade as city,
        le.estado as state,
        le.cep as zip_code,
        c.nome as responsible_name,
        c.email as responsible_email,
        l.telefone as responsible_phone,
  CASE WHEN l.ativo = true THEN 'active' ELSE 'inactive' END as status,
        l.id_usuario_owner as user_id
      FROM tb_loja l
      LEFT JOIN tb_loja_endereco le ON l.id = le.id_loja AND le.is_endereco_principal = true
      LEFT JOIN tb_contato c ON l.id = c.id_loja AND c.is_responsavel = true
      WHERE l.id = $1`,
      [req.params.id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/stores/:id/cashback - total cashback previsto/realizado por loja
router.get('/:id/cashback', async (req, res) => {
  try {
    const storeId = req.params.id;
    console.log('Cashback request for store ID:', storeId, 'Type:', typeof storeId);
    const result = await db.query(
      `SELECT 
          COALESCE(SUM(d.vl_previsto), 0) AS total_previsto,
          COALESCE(SUM(COALESCE(d.vl_realizado, 0)), 0) AS total_realizado
         FROM tb_loja_cashback_detalhes d
         JOIN tb_loja_cashback lc ON lc.id = d.id_cashback
         JOIN tb_pedido p ON p.id = lc.id_pedido
         WHERE lc.id_loja = $1
           AND TRIM(UPPER(COALESCE(p.status, ''))) <> 'CANCELADO'`,
      [storeId]
    );
    console.log('Cashback query result:', result.rows[0]);
    const row = result.rows[0] || {};
    res.json({
      store_id: storeId,
      total_previsto: Number(row.total_previsto || 0),
      total_realizado: Number(row.total_realizado || 0),
    });
  } catch (error) {
    console.error('Cashback query error:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/stores - Criar nova loja
router.post('/', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    
    const {
      name, fantasy_name, inscricao_estadual, site, termo_aceito,
      cnpj, address, address_number, neighborhood, reference, city, state, zip_code,
      responsible_name, responsible_position, responsible_email, responsible_phone, status = 'active', user_id, id_conta
    } = req.body;
    const accountId = id_conta ?? null;

    // Resolve a valid account id: se não foi enviado, tenta usar uma conta existente
    // ou cria uma conta padrão dentro da mesma transação para não violar NOT NULL / FK.
    let accountIdResolved = accountId;
    if (!accountIdResolved) {
      try {
        // tentar encontrar uma conta existente
        const accRes = await client.query('SELECT id FROM tb_sistema_conta LIMIT 1');
        if (accRes.rows.length > 0) {
          accountIdResolved = accRes.rows[0].id;
        } else {
          // criar conta padrão
          const newAcc = await client.query(
            'INSERT INTO tb_sistema_conta (nm_conta, dh_inc) VALUES ($1, CURRENT_TIMESTAMP) RETURNING id',
            ['Conta Padrão']
          );
          accountIdResolved = newAcc.rows[0].id;
        }
      } catch (err) {
        // Tabela tb_sistema_conta não existe - usar null (se a coluna permitir)
        console.warn('⚠️ Tabela tb_sistema_conta não existe, usando id_conta como null');
        accountIdResolved = null;
      }
    }

    // Normalize numeric fields (accept formatted input from frontend)
    const cnpjClean = (cnpj || '').toString().replace(/\D/g, '');
    const zipClean = (zip_code || '').toString().replace(/\D/g, '');
    const phoneClean = (responsible_phone || '').toString().replace(/\D/g, '');

    // Criar usuário owner (opcional) antes de inserir a loja - usa email padronizado @central.com
    let ownerUserId = user_id || null;
    let generatedPassword = null;
    if (!ownerUserId && responsible_email) {
      // SEM reutilizar usuário existente: sempre criar novo usuário para cada loja
      const centralEmail = generateCentralEmail(responsible_name || name || 'Usuario Loja');
      const gen = () => Math.random().toString(36).slice(-10);
      generatedPassword = gen();
      const salt = await bcrypt.genSalt(10);
      const hash = await bcrypt.hash(generatedPassword, salt);
      const userIns = await client.query(
        `INSERT INTO tb_sistema_usuario (id_conta, nome, email, senha, ativo, must_change_password)
         VALUES ($1, $2, $3, $4, true, true) RETURNING id`,
        [accountIdResolved, responsible_name || name || 'Usuário Loja', centralEmail, hash]
      );
      ownerUserId = userIns.rows[0].id;
      await client.query(
        `INSERT INTO tb_sistema_usuario_perfil (id_usuario, perfil) VALUES ($1, $2)`,
        [ownerUserId, 'store']
      );
    }

    // Preparar timestamp do termo de aceite
    let termoAceitoTs = null;
    const termoAceiteAlt = req.body.termo_aceite /* legacy spelling */;
    const acceptedTermsFlag = req.body.accepted_terms;
    if (acceptedTermsFlag && !termo_aceito && !termoAceiteAlt) {
      termoAceitoTs = new Date();
    } else if (termo_aceito) {
      const d = new Date(termo_aceito);
      termoAceitoTs = isNaN(d.getTime()) ? null : d;
    } else if (termoAceiteAlt) {
      const d = new Date(termoAceiteAlt);
      termoAceitoTs = isNaN(d.getTime()) ? null : d;
    }

    // Inserir loja
    const storeResult = await client.query(
      `INSERT INTO tb_loja (
        razao_social, nome_fantasia, cnpj, inscricao_estadual, site, termo_aceito,
        telefone, ativo, id_usuario_owner, id_conta
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id`,
      [name, fantasy_name || null, cnpjClean, inscricao_estadual || null, site || null, termoAceitoTs,
       phoneClean, status === 'active', ownerUserId, accountIdResolved]
    );

    const storeId = storeResult.rows[0].id;

    // Inserir endereço
    if (address && city && state && zip_code) {
      await client.query(
        `INSERT INTO tb_loja_endereco (
          id_loja, logradouro, numero, bairro, referencia, cidade, estado, cep, is_endereco_principal, id_conta
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [storeId, address, address_number || null, neighborhood || null, reference || null, city, state, zipClean, true, accountIdResolved]
      );
    }

    // Inserir contato
    if (responsible_name && responsible_email) {
      await client.query(
        `INSERT INTO tb_contato (
          id_loja, nome, email, telefone, cargo, is_responsavel, id_conta
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [storeId, responsible_name, responsible_email, phoneClean, responsible_position || null, true, accountIdResolved]
      );
    }

    await client.query('COMMIT');

    // Retornar loja criada
    const result = await client.query(
      `SELECT 
        l.id,
        l.razao_social as name,
        l.nome_fantasia as fantasy_name,
        l.cnpj,
        l.inscricao_estadual,
        l.site,
        l.termo_aceito,
        l.telefone as responsible_phone,
        l.ativo as status,
        l.id_usuario_owner as user_id
      FROM tb_loja l
      WHERE l.id = $1`,
      [storeId]
    );

    const payload = { ...result.rows[0] };
    if (generatedPassword) {
      const centralEmail = generateCentralEmail(responsible_name || name || 'Usuario Loja');
      payload.generated_password = generatedPassword;
      payload.generated_email = centralEmail;
      
      // Enviar email com as credenciais (não bloqueia a resposta se falhar)
      if (responsible_email) {
        console.log('📧 Tentando enviar email para:', responsible_email);
        sendWelcomeEmail({
          to: responsible_email,
          name: responsible_name || name || 'Usuário',
          email: centralEmail,
          password: generatedPassword,
          type: 'store'
        }).then(result => {
          if (result.success) {
            console.log('✅ Email enviado com sucesso!');
          } else {
            console.log('⚠️ Email não foi enviado:', result.error);
          }
        }).catch(err => {
          console.error('❌ Erro ao enviar email de boas-vindas:', err);
        });
      } else {
        console.log('⚠️ Nenhum email de responsável fornecido, email não será enviado');
      }
    }
    res.status(201).json(payload);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

// PUT /api/stores/:id - Atualizar loja
router.put('/:id', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const {
      name, fantasy_name, inscricao_estadual, site, termo_aceito,
      cnpj, address, address_number, neighborhood, reference, city, state, zip_code,
      responsible_name, responsible_position, responsible_email, responsible_phone, status
    } = req.body;

    const id = req.params.id;

    // Sanitize inputs
    const cnpjClean = (cnpj || '').toString().replace(/\D/g, '');
    const zipClean = (zip_code || '').toString().replace(/\D/g, '');
    const phoneClean = (responsible_phone || '').toString().replace(/\D/g, '');

    // Resolve account id from store
    const lojaRes = await client.query('SELECT id_conta FROM tb_loja WHERE id = $1', [id]);
    if (lojaRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Store not found' });
    }
    const accountId = lojaRes.rows[0].id_conta;

    const currentUserId = req.user?.id ?? null;

    // Preparar timestamp do termo de aceite
    let termoAceitoUpdate = null;
    const termoAceiteAltPut = req.body.termo_aceite; // legacy spelling
    const acceptedTermsFlagPut = req.body.accepted_terms;
    if (typeof termo_aceito !== 'undefined') {
      const d = termo_aceito ? new Date(termo_aceito) : null;
      termoAceitoUpdate = d && !isNaN(d.getTime()) ? d : null;
    } else if (typeof termoAceiteAltPut !== 'undefined') {
      const d = termoAceiteAltPut ? new Date(termoAceiteAltPut) : null;
      termoAceitoUpdate = d && !isNaN(d.getTime()) ? d : null;
    } else if (acceptedTermsFlagPut) {
      termoAceitoUpdate = new Date();
    }

    // Update core store fields
    await client.query(
      `UPDATE tb_loja SET 
        razao_social = COALESCE($1, razao_social),
        nome_fantasia = $2,
        cnpj = COALESCE(NULLIF($3, ''), cnpj),
        inscricao_estadual = COALESCE($4, inscricao_estadual),
        site = COALESCE($5, site),
        termo_aceito = COALESCE($6, termo_aceito),
        telefone = $7,
        ativo = $8,
        dt_alt = CURRENT_TIMESTAMP,
        id_usuario_alt = COALESCE($9, id_usuario_alt)
      WHERE id = $10`,
      [name, fantasy_name || null, cnpjClean, inscricao_estadual, site, termoAceitoUpdate, phoneClean, status === 'active', currentUserId, id]
    );

    // Upsert principal address
    if (address || city || state || zip_code || address_number || neighborhood || reference) {
      const addrRes = await client.query(
        'SELECT id FROM tb_loja_endereco WHERE id_loja = $1 AND is_endereco_principal = true',
        [id]
      );
      if (addrRes.rows.length > 0) {
        await client.query(
          `UPDATE tb_loja_endereco SET 
            logradouro = COALESCE($1, logradouro),
            numero = COALESCE($2, numero),
            bairro = COALESCE($3, bairro),
            referencia = COALESCE($4, referencia),
            cidade = COALESCE($5, cidade),
            estado = COALESCE($6, estado),
            cep = COALESCE($7, cep)
          WHERE id_loja = $8 AND is_endereco_principal = true`,
          [address || null, address_number || null, neighborhood || null, reference || null, city || null, state || null, zipClean || null, id]
        );
      } else {
        // Insert if any address info provided
        await client.query(
          `INSERT INTO tb_loja_endereco (
            id_loja, logradouro, numero, bairro, referencia, cidade, estado, cep, is_endereco_principal, id_conta
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, $9)`,
          [id, address || null, address_number || null, neighborhood || null, reference || null, city || null, state || null, zipClean || null, accountId]
        );
      }
    }

    // Upsert de contato responsável
    if (responsible_name || responsible_email || responsible_phone) {
      const contRes = await client.query(
        'SELECT id FROM tb_contato WHERE id_loja = $1 AND is_responsavel = true',
        [id]
      );
      if (contRes.rows.length > 0) {
        await client.query(
          `UPDATE tb_contato SET 
            nome = COALESCE($1, nome),
            email = COALESCE($2, email),
            telefone = COALESCE($3, telefone),
            cargo = COALESCE($4, cargo)
          WHERE id_loja = $5 AND is_responsavel = true`,
          [responsible_name || null, responsible_email || null, phoneClean || null, responsible_position || null, id]
        );
      } else if (responsible_name && responsible_email) {
        await client.query(
          `INSERT INTO tb_contato (
            id_loja, nome, email, telefone, cargo, is_responsavel, id_conta
          ) VALUES ($1, $2, $3, $4, $5, true, $6)`,
          [id, responsible_name, responsible_email, phoneClean || null, responsible_position || null, accountId]
        );
      }
    }

    await client.query('COMMIT');

    // Return full store data consistent with GET
    const result = await db.query(
      `SELECT 
        l.id,
        l.razao_social as name,
        l.nome_fantasia as fantasy_name,
        l.cnpj,
        l.inscricao_estadual,
        l.site,
        l.termo_aceito,
        le.logradouro || ' ' || COALESCE(le.numero, '') || ' ' || COALESCE(le.complemento, '') as address,
        le.numero as address_number,
        le.bairro as neighborhood,
        le.referencia as reference,
        le.cidade as city,
        le.estado as state,
        le.cep as zip_code,
        c.nome as responsible_name,
        c.email as responsible_email,
        l.telefone as responsible_phone,
        CASE WHEN l.ativo = true THEN 'active' ELSE 'inactive' END as status,
        l.id_usuario_owner as user_id
      FROM tb_loja l
      LEFT JOIN tb_loja_endereco le ON l.id = le.id_loja AND le.is_endereco_principal = true
      LEFT JOIN tb_contato c ON l.id = c.id_loja AND c.is_responsavel = true
      WHERE l.id = $1`,
      [id]
    );

    res.json(result.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

export default router;