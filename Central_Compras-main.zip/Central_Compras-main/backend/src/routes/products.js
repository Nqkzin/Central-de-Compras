import express from 'express';
import { db } from '../database/database.js';

const router = express.Router();

// GET /api/products
router.get('/', async (req, res) => {
  try {
    const { status, supplier_id, sort } = req.query;
    let query = `
      SELECT 
        fp.id,
        fp.produto as name,
        fp.descricao as description,
        fp.gtin as gtin,
        fp.codigo_produto as code,
        c.nome as category,
        fp.id_fornecedor as supplier_id,
        fp.valor_produto as price,
        fp.valor_produto_campanha as promotional_price,
        fp.tipo_embalagem as unit,
        fp.foto_url as image_url,
        fp.quantidade_estoque as stock_quantity,
        CASE 
          WHEN fp.id IS NOT NULL THEN 'active'
          ELSE 'inactive'
        END as status
      FROM tb_fornecedor_produto fp
      LEFT JOIN tb_categoria c ON fp.id_categoria = c.id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (status) {
      // Não incrementar paramCount aqui pois nenhum placeholder é adicionado
      query += ` AND fp.id IS NOT NULL`;
    }

    if (supplier_id) {
      paramCount++;
      query += ` AND fp.id_fornecedor = $${paramCount}`;
      params.push(supplier_id);
    }

    if (sort) {
      const sortField = sort.startsWith('-') ? sort.slice(1) : sort;
      const sortOrder = sort.startsWith('-') ? 'DESC' : 'ASC';
      const sortMap = {
        // Se a tabela não tiver coluna de timestamp criado, usar id como proxy de ordenação
        created_date: 'fp.id',
        name: 'fp.produto',
        code: 'fp.codigo_produto',
        price: 'fp.valor_produto'
      };
      let sortColumn = sortMap[sortField] || 'fp.produto';
      // Segurança básica: permitir apenas padrão de colunas conhecidas para prevenir erros SQL
      if (!/^fp\.(id|produto|codigo_produto|valor_produto)$/.test(sortColumn)) {
        sortColumn = 'fp.produto';
      }
      query += ` ORDER BY ${sortColumn} ${sortOrder}`;
    } else {
      query += ' ORDER BY fp.produto ASC';
    }

    const result = await db.query(query, params);

    // Verificar colunas opcionais
    const cols = await db.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'tb_fornecedor_produto' AND column_name IN ('codigo_referencia','gtin')
    `);
    const colNames = cols.rows.map(r => r.column_name);
    const hasCodigoReferencia = colNames.includes('codigo_referencia');
    const hasGtin = colNames.includes('gtin');

    // Mapear linhas: preferir coluna gtin explícita e expor internal_code de codigo_produto quando tiver 8 dígitos
    const mapped = result.rows.map(r => {
      const out = { ...r };
      if (hasGtin && r.gtin) {
        const cleaned = String(r.gtin).replace(/\D/g, '');
        out.gtin = cleaned || null;
      } else {
        out.gtin = null;
      }
      const rawCode = r.code ? String(r.code).replace(/\D/g, '') : '';
      out.internal_code = rawCode.length === 8 ? rawCode : null;
      if (hasCodigoReferencia && typeof r.codigo_referencia !== 'undefined') {
        out.codigo_referencia = r.codigo_referencia;
      }
      return out;
    });

    res.json(mapped);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/products
router.post('/', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const {
      name, description, code, gtin, internal_code, codigo_referencia, category, supplier_id,
      price, promotional_price, unit, stock_quantity, image_url, status = 'active', id_conta
    } = req.body;
    const incomingAccountId = id_conta ?? null;

    // Primeiro, buscar ou criar categoria
    // Resolver/garantir um account id similar a suppliers/stores
    let accountIdResolved = incomingAccountId;
    if (!accountIdResolved) {
      const accRes = await client.query('SELECT id FROM tb_sistema_conta LIMIT 1');
      if (accRes.rows.length > 0) {
        accountIdResolved = accRes.rows[0].id;
      } else {
        const newAcc = await client.query(
          'INSERT INTO tb_sistema_conta (nm_conta, dh_inc) VALUES ($1, CURRENT_TIMESTAMP) RETURNING id',
          ['Conta Padrão']
        );
        accountIdResolved = newAcc.rows[0].id;
      }
    }

    let categoriaId = null;
    if (category) {
      const catResult = await client.query(
        'SELECT id FROM tb_categoria WHERE nome = $1',
        [category]
      );
      if (catResult.rows.length > 0) {
        categoriaId = catResult.rows[0].id;
      } else {
        const newCatResult = await client.query(
          'INSERT INTO tb_categoria (nome) VALUES ($1) RETURNING id',
          [category]
        );
        categoriaId = newCatResult.rows[0].id;
      }
    }

    // Garantir que coluna gtin existe; criar se estiver faltando
    const colGtin = await client.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'tb_fornecedor_produto' AND column_name = 'gtin'
    `);
    if (colGtin.rows.length === 0) {
      await client.query(`ALTER TABLE tb_fornecedor_produto ADD COLUMN gtin TEXT`);
    }

    // Preparar valores: gtin (13) armazenado na coluna gtin; codigo_produto permanece para códigos internos
    let storeGtin = null;
    let storeInternal = null;
    if (gtin) {
      const cleaned = String(gtin).replace(/\D/g, '');
      if (cleaned.length !== 13) throw new Error('GTIN must have 13 digits');
      storeGtin = cleaned;
    }
    if (internal_code) {
      const cleaned = String(internal_code).replace(/\D/g, '');
      if (cleaned.length !== 8) throw new Error('Internal product code must have 8 digits');
      storeInternal = cleaned;
    }
    // Fallback para código legado
    if (!storeGtin && !storeInternal && code) {
      const cleaned = String(code).replace(/\D/g, '');
      if (cleaned.length === 13) storeGtin = cleaned;
      else storeInternal = cleaned || null;
    }

    // Verificar se coluna codigo_referencia existe
    const colRes = await client.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'tb_fornecedor_produto' AND column_name = 'codigo_referencia'
    `);
    const hasCodigoReferencia = colRes.rows.length > 0;

    let insertSql, insertValues;
    if (hasCodigoReferencia) {
      insertSql = `INSERT INTO tb_fornecedor_produto (
        produto, descricao, gtin, codigo_produto, codigo_referencia, id_categoria, id_fornecedor,
        valor_produto, valor_produto_campanha, tipo_embalagem, quantidade_estoque, foto_url, id_conta
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING id`;
      insertValues = [name, description, storeGtin, storeInternal, codigo_referencia || null, categoriaId, supplier_id,
        price, promotional_price || null, unit, stock_quantity, image_url || null, accountIdResolved];
    } else {
      insertSql = `INSERT INTO tb_fornecedor_produto (
        produto, descricao, gtin, codigo_produto, id_categoria, id_fornecedor,
        valor_produto, valor_produto_campanha, tipo_embalagem, quantidade_estoque, foto_url, id_conta
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING id`;
      insertValues = [name, description, storeGtin, storeInternal, categoriaId, supplier_id,
        price, promotional_price || null, unit, stock_quantity, image_url || null, accountIdResolved];
    }

    const result = await client.query(insertSql, insertValues);

    const newId = result.rows[0].id;
    await client.query('COMMIT');

    // Retornar formato completo do produto consistente com GET
    // Construir SELECT incluindo codigo_referencia se presente
    // Construir SELECT incluindo gtin e codigo_referencia se presente
    const colCheck = await db.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'tb_fornecedor_produto' AND column_name IN ('codigo_referencia','gtin')
    `);
    const selectCols = colCheck.rows.map(r => r.column_name);
    const selectHasRef = selectCols.includes('codigo_referencia');
    const selectHasGtin = selectCols.includes('gtin');

    const selectSql = selectHasRef && selectHasGtin ? `
      SELECT 
        fp.id,
        fp.produto as name,
        fp.descricao as description,
        fp.gtin as gtin,
        fp.codigo_produto as code,
        fp.codigo_referencia as codigo_referencia,
        c.nome as category,
        fp.id_fornecedor as supplier_id,
        fp.valor_produto as price,
        fp.valor_produto_campanha as promotional_price,
        fp.tipo_embalagem as unit,
        fp.foto_url as image_url,
        fp.quantidade_estoque as stock_quantity,
        CASE WHEN fp.id IS NOT NULL THEN 'active' ELSE 'inactive' END as status
      FROM tb_fornecedor_produto fp
      LEFT JOIN tb_categoria c ON fp.id_categoria = c.id
      WHERE fp.id = $1` : selectHasGtin ? `
      SELECT 
        fp.id,
        fp.produto as name,
        fp.descricao as description,
        fp.gtin as gtin,
        fp.codigo_produto as code,
        c.nome as category,
        fp.id_fornecedor as supplier_id,
        fp.valor_produto as price,
        fp.valor_produto_campanha as promotional_price,
        fp.tipo_embalagem as unit,
        fp.foto_url as image_url,
        fp.quantidade_estoque as stock_quantity,
        CASE WHEN fp.id IS NOT NULL THEN 'active' ELSE 'inactive' END as status
      FROM tb_fornecedor_produto fp
      LEFT JOIN tb_categoria c ON fp.id_categoria = c.id
      WHERE fp.id = $1` : selectHasRef ? `
      SELECT 
        fp.id,
        fp.produto as name,
        fp.descricao as description,
        fp.codigo_produto as code,
        fp.codigo_referencia as codigo_referencia,
        c.nome as category,
        fp.id_fornecedor as supplier_id,
        fp.valor_produto as price,
        fp.valor_produto_campanha as promotional_price,
        fp.tipo_embalagem as unit,
        fp.foto_url as image_url,
        fp.quantidade_estoque as stock_quantity,
        CASE WHEN fp.id IS NOT NULL THEN 'active' ELSE 'inactive' END as status
      FROM tb_fornecedor_produto fp
      LEFT JOIN tb_categoria c ON fp.id_categoria = c.id
      WHERE fp.id = $1` : `
      SELECT 
        fp.id,
        fp.produto as name,
        fp.descricao as description,
        fp.codigo_produto as code,
        c.nome as category,
        fp.id_fornecedor as supplier_id,
        fp.valor_produto as price,
        fp.valor_produto_campanha as promotional_price,
        fp.tipo_embalagem as unit,
        fp.foto_url as image_url,
        fp.quantidade_estoque as stock_quantity,
        CASE WHEN fp.id IS NOT NULL THEN 'active' ELSE 'inactive' END as status
      FROM tb_fornecedor_produto fp
      LEFT JOIN tb_categoria c ON fp.id_categoria = c.id
      WHERE fp.id = $1`;

    const fullProduct = await db.query(selectSql, [newId]);

    // Mapear linha retornada para incluir gtin/internal_code e codigo_referencia se presente
    const row = fullProduct.rows[0];
    if (row) {
      if (row.gtin) row.gtin = String(row.gtin).replace(/\D/g, '') || null;
      const raw = row.code ? String(row.code).replace(/\D/g, '') : '';
      row.internal_code = raw.length === 8 ? raw : null;
      if (row.codigo_referencia) row.codigo_referencia = row.codigo_referencia;
    }
    res.status(201).json(row);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

// PUT /api/products/:id
router.put('/:id', async (req, res) => {
  try {
    const {
      name, description, code, gtin, internal_code, codigo_referencia, category,
      price, promotional_price, unit, stock_quantity, image_url, supplier_id
    } = req.body;

    // Buscar ou criar categoria
    let categoriaId = null;
    if (category) {
      const catResult = await db.query(
        'SELECT id FROM tb_categoria WHERE nome = $1',
        [category]
      );
      
      if (catResult.rows.length > 0) {
        categoriaId = catResult.rows[0].id;
      } else {
        const newCatResult = await db.query(
          'INSERT INTO tb_categoria (nome) VALUES ($1) RETURNING id',
          [category]
        );
        categoriaId = newCatResult.rows[0].id;
      }
    }

    // Garantir que coluna gtin existe; criar se estiver faltando
    const colGtin = await db.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'tb_fornecedor_produto' AND column_name = 'gtin'
    `);
    if (colGtin.rows.length === 0) {
      await db.query(`ALTER TABLE tb_fornecedor_produto ADD COLUMN gtin TEXT`);
    }

    // Determinar valores armazenados
    let storeGtin = null;
    let storeInternal = null;
    if (gtin) {
      const cleaned = String(gtin).replace(/\D/g, '');
      if (cleaned.length !== 13) throw new Error('GTIN must have 13 digits');
      storeGtin = cleaned;
    }
    if (internal_code) {
      const cleaned = String(internal_code).replace(/\D/g, '');
      if (cleaned.length !== 8) throw new Error('Internal product code must have 8 digits');
      storeInternal = cleaned;
    }
    if (!storeGtin && !storeInternal && code) {
      const cleaned = String(code).replace(/\D/g, '');
      if (cleaned.length === 13) storeGtin = cleaned;
      else storeInternal = cleaned || null;
    }

    // Verificar se coluna codigo_referencia existe
    const colRes = await db.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'tb_fornecedor_produto' AND column_name = 'codigo_referencia'
    `);
    const hasCodigoReferencia = colRes.rows.length > 0;

    let updateSql, updateValues;
    if (hasCodigoReferencia) {
      updateSql = `UPDATE tb_fornecedor_produto SET 
        produto = $1,
        descricao = $2,
        gtin = $3,
        codigo_produto = $4,
        codigo_referencia = $5,
        id_categoria = $6,
        valor_produto = $7,
        valor_produto_campanha = $8,
        tipo_embalagem = $9,
        quantidade_estoque = $10,
        foto_url = $11,
        id_fornecedor = COALESCE($12, id_fornecedor)
      WHERE id = $13
      RETURNING 
        id,
        produto as name,
        descricao as description,
        gtin,
        codigo_produto as code,
        codigo_referencia,
        (SELECT nome FROM tb_categoria WHERE id = id_categoria) as category,
        id_fornecedor as supplier_id,
        valor_produto as price,
        valor_produto_campanha as promotional_price,
        tipo_embalagem as unit,
        quantidade_estoque as stock_quantity,
        foto_url as image_url`;
      updateValues = [name, description, storeGtin, storeInternal, codigo_referencia || null, categoriaId,
        price, promotional_price || null, unit, stock_quantity, image_url || null, supplier_id || null, req.params.id];
    } else {
      updateSql = `UPDATE tb_fornecedor_produto SET 
        produto = $1,
        descricao = $2,
        gtin = $3,
        codigo_produto = $4,
        id_categoria = $5,
        valor_produto = $6,
        valor_produto_campanha = $7,
        tipo_embalagem = $8,
        quantidade_estoque = $9,
        foto_url = $10,
        id_fornecedor = COALESCE($11, id_fornecedor)
      WHERE id = $12
      RETURNING 
        id,
        produto as name,
        descricao as description,
        gtin,
        codigo_produto as code,
        (SELECT nome FROM tb_categoria WHERE id = id_categoria) as category,
        id_fornecedor as supplier_id,
        valor_produto as price,
        valor_produto_campanha as promotional_price,
        tipo_embalagem as unit,
        quantidade_estoque as stock_quantity,
        foto_url as image_url`;
      updateValues = [name, description, storeGtin, storeInternal, categoriaId,
        price, promotional_price || null, unit, stock_quantity, image_url || null, supplier_id || null, req.params.id];
    }

    const result = await db.query(updateSql, updateValues);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
// DELETE /api/products/:id
router.delete('/:id', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const productId = Number(req.params.id);
    if (!Number.isFinite(productId)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'ID de produto inválido' });
    }

    // Verifica se o produto existe
    const existsRes = await client.query(
      'SELECT id FROM tb_fornecedor_produto WHERE id = $1',
      [productId]
    );
    if (existsRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    // Bloquear exclusão se houver referências em pedidos "ativos" (não cancelados ou entregues)
    // Consideramos ativos: PENDENTE, PROCESSANDO e SEPARADO
    const orderRefRes = await client.query(
      `SELECT 1
         FROM tb_pedido_item pi
         JOIN tb_pedido p ON p.id = pi.id_pedido
        WHERE pi.id_produto = $1
          AND p.status IN ('PENDENTE','PROCESSANDO','SEPARADO')
        LIMIT 1`,
      [productId]
    );
    if (orderRefRes.rows.length > 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Não é possível excluir: produto vinculado a pedidos em andamento.' });
    }

    // Bloquear exclusão se estiver vinculado a campanhas de fornecedor
    try {
      const campaignRefRes = await client.query(
        'SELECT 1 FROM tb_fornecedor_campanha_produto WHERE id_produto = $1 LIMIT 1',
        [productId]
      );
      if (campaignRefRes.rows.length > 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Não é possível excluir: produto vinculado a campanhas.' });
      }
    } catch (e) {
      // Se a tabela não existir no ambiente, ignorar esta verificação
    }

    // Excluir o produto
    const delRes = await client.query(
      'DELETE FROM tb_fornecedor_produto WHERE id = $1 RETURNING id',
      [productId]
    );

    await client.query('COMMIT');
    if (delRes.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }
    return res.json({ success: true, id: delRes.rows[0].id });
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});
