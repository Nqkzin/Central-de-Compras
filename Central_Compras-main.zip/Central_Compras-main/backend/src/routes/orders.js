import express from 'express';
import { db } from '../database/database.js';

const router = express.Router();

// Mapeamento de status
const statusMap = {
  'pending': 'PENDENTE',
  'processing': 'PROCESSANDO',
  'separated': 'SEPARADO',
  'shipped': 'ENVIADO',
  'delivered': 'ENTREGUE',
  'cancelled': 'CANCELADO'
};

const reverseStatusMap = {
  'PENDENTE': 'pending',
  'PROCESSANDO': 'processing',
  'SEPARADO': 'separated',
  'ENVIADO': 'shipped',
  'ENTREGUE': 'delivered',
  'CANCELADO': 'cancelled'
};

// GET /api/orders
router.get('/', async (req, res) => {
  try {
    const { store_id, supplier_id, status, sort } = req.query;
    let query = `
      SELECT 
        p.id,
        p.id as order_number,
        p.id_loja as store_id,
        p.id_fornecedor as supplier_id,
        p.status as db_status,
        p.vl_total_pedido as total_amount,
        p.dt_inc as created_date,
        p.valor_adicional as additional_amount,
        p.observacoes as notes,
        p.forma_pagamento as payment_method,
        p.prazo_pagamento as payment_term_days,
        p.numero_nota_fiscal as numero_nota_fiscal,
        p.chave_nota_fiscal as chave_nota_fiscal,
        (
          SELECT COALESCE(SUM(pi.valor_total), 0)
          FROM tb_pedido_item pi 
          WHERE pi.id_pedido = p.id
        ) as subtotal,
        (
          SELECT COALESCE(SUM(lc.vl_previsto), 0)
          FROM tb_loja_cashback lc 
          WHERE lc.id_pedido = p.id
        ) as cashback_amount,
        (
          SELECT json_agg(
            json_build_object(
              'product_id', pi.id_produto,
              'product_name', COALESCE(pi.produto, 'Produto não encontrado'),
              'quantity', pi.quantidade,
              'unit_price', pi.valor_unitario,
              'total', pi.valor_total
            )
          )
          FROM tb_pedido_item pi
          WHERE pi.id_pedido = p.id
        ) as items
      FROM tb_pedido p
      WHERE 1=1
    `;

    let params = [];
    let paramCount = 0;

    if (store_id) {
      paramCount++;
      query += ` AND p.id_loja = $${paramCount}`;
      params.push(store_id);
    }

    if (supplier_id) {
      paramCount++;
      query += ` AND p.id_fornecedor = $${paramCount}`;
      params.push(supplier_id);
    }

    if (status) {
      paramCount++;
      query += ` AND p.status = $${paramCount}`;
      params.push(statusMap[status] || status);
    }

    if (sort) {
      const sortField = sort.startsWith('-') ? sort.slice(1) : sort;
      const sortOrder = sort.startsWith('-') ? 'DESC' : 'ASC';
      query += ` ORDER BY ${sortField} ${sortOrder}`;
    } else {
      query += ' ORDER BY p.dt_inc DESC';
    }

    const result = await db.query(query, params);

    // Buscar campanhas aplicadas separadamente para cada pedido (se tabela existir)
    const processedRows = await Promise.all(result.rows.map(async (row) => {
      let applied_campaigns = [];
      try {
        const campaignsResult = await db.query(`
          SELECT 
            pc.id_campanha as campaign_id,
            fc.nome as campaign_name,
            fc.tipo as campaign_type,
            fc.descricao_brinde as gift_description,
            pc.percentual_cashback as cashback_percentage,
            pc.valor_calculado as calculated_value
          FROM tb_pedido_campanha pc
          LEFT JOIN tb_fornecedor_campanha fc ON fc.id = pc.id_campanha
          WHERE pc.id_pedido = $1
        `, [row.id]);
        applied_campaigns = campaignsResult.rows;
      } catch (err) {
        // Tabela pode não existir ainda, ignora erro
        applied_campaigns = [];
      }
      
      return {
        ...row,
        status: reverseStatusMap[row.db_status] || 'pending',
        applied_campaigns
      };
    }));

    res.json(processedRows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/orders
router.post('/', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const {
      store_id, supplier_id, status = 'pending', items = [],
      notes, payment_method, id_conta
    } = req.body;

    if (!store_id || !supplier_id || !Array.isArray(items) || items.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'store_id, supplier_id e itens são obrigatórios' });
    }

    // Resolver conta
    let accountId = id_conta ?? null;
    if (!accountId) {
      const accRes = await client.query('SELECT id FROM tb_sistema_conta LIMIT 1');
      if (accRes.rows.length > 0) accountId = accRes.rows[0].id; else {
        const newAcc = await client.query(
          'INSERT INTO tb_sistema_conta (nm_conta, dh_inc) VALUES ($1, CURRENT_TIMESTAMP) RETURNING id',
          ['Conta Padrão']
        );
        accountId = newAcc.rows[0].id;
      }
    }

    // Buscar estado da loja para condição
    const storeStateRes = await client.query(
      `SELECT estado FROM tb_loja_endereco WHERE id_loja = $1 ORDER BY id DESC LIMIT 1`,
      [store_id]
    );
    const storeState = storeStateRes.rows[0]?.estado || null;

    // Buscar condição de estado ativa
    let stateCondition = null;
    if (storeState) {
      const scRes = await client.query(
        `SELECT id_fornecedor as supplier_id, estado as state, percentual_cashback as cashback_percentage,
                max_cashback_amount, prazo_dias as payment_term_days, ajuste_valor_unitario as unit_price_adjustment
         FROM tb_fornecedor_condicao
         WHERE id_fornecedor = $1 AND UPPER(TRIM(estado)) = UPPER(TRIM($2))
         ORDER BY id DESC LIMIT 1`,
        [supplier_id, storeState]
      );
      stateCondition = scRes.rows[0] || null;
    }

    // Buscar campanhas ativas do fornecedor
    const campaignsRes = await client.query(
      `SELECT fc.id, fc.descricao_campanha as name, fc.tipo_campanha as type,
              fc.valor_meta as min_value, fc.percentual_cashback as cashback_percentage,
              fc.quantidade_meta as min_quantity,
              fc.dt_inicio as start_date, fc.dt_fim as end_date,
              (SELECT fcp.id_produto FROM tb_fornecedor_campanha_produto fcp WHERE fcp.id_campanha = fc.id LIMIT 1) as product_id
       FROM tb_fornecedor_campanha fc
       WHERE fc.id_fornecedor = $1 
         AND fc.ativa = true
         AND (fc.dt_inicio IS NULL OR fc.dt_inicio::date <= CURRENT_DATE)
         AND (fc.dt_fim IS NULL OR fc.dt_fim::date >= CURRENT_DATE)`,
      [supplier_id]
    );
    const rawCampaigns = campaignsRes.rows;

    // Preparar mapa de produto -> preço para manter autoridade do backend
    // Converte explicitamente para números e filtra inválidos
    const productIds = [...new Set(items.map(i => Number(i.product_id)))]
      .filter(id => Number.isFinite(id));
    if (productIds.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Itens sem product_id válido.' });
    }
    
    // Verificar se a coluna valor_produto_campanha existe
    const colCheck = await client.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'tb_fornecedor_produto' AND column_name = 'valor_produto_campanha'
    `);
    const hasPromotionalPrice = colCheck.rows.length > 0;
    
    const productsRes = await client.query(
      hasPromotionalPrice
        ? `SELECT id, produto as name, valor_produto as price, valor_produto_campanha as promotional_price, tipo_embalagem as unit
           FROM tb_fornecedor_produto 
           WHERE id_fornecedor = $1 AND id = ANY($2::int[])`
        : `SELECT id, produto as name, valor_produto as price, NULL as promotional_price, tipo_embalagem as unit
           FROM tb_fornecedor_produto 
           WHERE id_fornecedor = $1 AND id = ANY($2::int[])`,
      [supplier_id, productIds]
    );
    const productMap = new Map(productsRes.rows.map(r => [Number(r.id), r]));

    // Calcular subtotal usando preços do banco (promocional quando disponível)
    let subtotal = 0;
    let totalUnits = 0;
    const normalizedItems = [];
    for (const item of items) {
      const pid = Number(item.product_id);
      const p = productMap.get(pid);
      if (!p) {
        await client.query('ROLLBACK');
        const missing = productIds.filter(id => !productMap.has(id));
        return res.status(400).json({ 
          error: `Produto ${pid} não encontrado para fornecedor ${supplier_id}.`,
          missing_products: missing
        });
      }
      const qty = Number(item.quantity || 0);
      if (qty <= 0) continue;
      // Usar preço promocional se disponível, senão usar preço normal
      const promoPrice = Number(p.promotional_price || 0);
      const unitPrice = promoPrice > 0 ? promoPrice : Number(p.price || 0);
      const lineTotal = unitPrice * qty;
      subtotal += lineTotal;
      totalUnits += qty;
      normalizedItems.push({
        product_id: p.id,
        product_name: p.name,
        quantity: qty,
        unit_price: unitPrice,
        total: lineTotal
      });
    }
    if (normalizedItems.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Nenhum item válido informado' });
    }

    // Ajustes de condição de estado (acréscimo) & prazo
    let additional_amount = 0;
    let payment_term_days = 30;
    if (stateCondition) {
      const adj = Number(stateCondition.unit_price_adjustment || 0);
      if (adj !== 0) additional_amount = totalUnits * adj;
      const prazo = Number(stateCondition.payment_term_days || 0);
      if (prazo > 0) payment_term_days = prazo;
    }

    // Calcular progresso para campanhas (valor e quantidade) usando pedidos já processados
    const processedStatuses = ['PROCESSANDO','SEPARADO','ENVIADO','ENTREGUE'];
    const applied_campaigns = [];
    const campaign_insights = [];
    let campaignCashback = 0;

    for (const c of rawCampaigns) {
      const percent = Number(c.cashback_percentage || 0) / 100;
      if (percent <= 0 && c.type !== 'PRODUTO') continue;
      let current = 0, target = 0, active = false, willActivate = false, qualifiesNow = false, predictedCashback = 0;
      if (c.type === 'VALOR') {
        target = Number(c.min_value || 0);
        const sumRes = await client.query(
          `SELECT COALESCE(SUM(pi.valor_total),0) AS total
           FROM tb_pedido_item pi
           JOIN tb_pedido p ON p.id = pi.id_pedido
           WHERE p.id_fornecedor = $1 AND p.status = ANY($2)`,
          [supplier_id, processedStatuses]
        );
        current = Number(sumRes.rows[0].total || 0);
        active = target > 0 && current >= target;
        const after = current + subtotal;
        willActivate = !active && target > 0 && after >= target;
        qualifiesNow = active || subtotal >= target || willActivate;
        if (qualifiesNow) {
          predictedCashback = subtotal * percent;
          campaignCashback += predictedCashback;
          applied_campaigns.push(c.id);
        }
      } else if (c.type === 'QUANTIDADE') {
        // Campanha por quantidade: gera cashback quando atinge meta de quantidade do produto
        target = Number(c.min_quantity || 0);
        const productId = c.product_id ? Number(c.product_id) : null;
        if (productId && target > 0) {
          // Buscar quantidade acumulada de pedidos processados
          const qtyRes = await client.query(
            `SELECT COALESCE(SUM(pi.quantidade),0) AS qty
             FROM tb_pedido_item pi
             JOIN tb_pedido p ON p.id = pi.id_pedido
             WHERE p.id_fornecedor = $1 AND p.status = ANY($2) AND pi.id_produto = $3`,
            [supplier_id, processedStatuses, productId]
          );
          current = Number(qtyRes.rows[0].qty || 0);
          active = current >= target;
          
          // Quantidade deste produto no pedido atual
          const orderItem = normalizedItems.find(i => Number(i.product_id) === Number(productId));
          const inOrder = orderItem?.quantity || 0;
          const afterQty = current + inOrder;
          willActivate = !active && afterQty >= target;
          qualifiesNow = active || inOrder >= target || willActivate;
          
          if (qualifiesNow && orderItem) {
            // Cashback sobre o valor deste produto no pedido
            predictedCashback = orderItem.total * percent;
            campaignCashback += predictedCashback;
            applied_campaigns.push(c.id);
          }
        }
      } else if (c.type === 'PRODUTO') {
        // Brinde por quantidade: não gera cashback, apenas registra ativação
        target = Number(c.min_quantity || 0);
        const productId = c.product_id ? Number(c.product_id) : null;
        if (productId && target > 0) {
          const qtyRes = await client.query(
            `SELECT COALESCE(SUM(pi.quantidade),0) AS qty
             FROM tb_pedido_item pi
             JOIN tb_pedido p ON p.id = pi.id_pedido
             WHERE p.id_fornecedor = $1 AND p.status = ANY($2) AND pi.id_produto = $3`,
            [supplier_id, processedStatuses, productId]
          );
          current = Number(qtyRes.rows[0].qty || 0);
          active = current >= target;
          const inOrder = normalizedItems.find(i => i.product_id === productId)?.quantity || 0;
          const afterQty = current + inOrder;
          willActivate = !active && afterQty >= target;
          qualifiesNow = active || inOrder >= target || willActivate;
          // Brinde não gera cashback monetário
        }
      }
      campaign_insights.push({
        id: c.id,
        type: c.type,
        active,
        willActivate,
        qualifiesNow,
        percent: percent * 100,
        predictedCashback
      });
    }

    // Cashback de condição de estado (somente se nenhuma campanha gerou)
    let cashback_amount = 0;
    let cashback_branch = 'none';
    let cashbackSaved = false; // debug flag
    let cashbackDetailsSaved = false; // debug flag
    if (campaignCashback > 0) {
      cashback_amount = campaignCashback;
      cashback_branch = 'campaign_priority';
    } else if (stateCondition && Number(stateCondition.cashback_percentage || 0) > 0) {
      const perc = Number(stateCondition.cashback_percentage) / 100;
      let stateCb = subtotal * perc;
      const maxCb = Number(stateCondition.max_cashback_amount || 0);
      if (maxCb > 0 && stateCb > maxCb) stateCb = maxCb;
      cashback_amount = stateCb;
      if (stateCb > 0) cashback_branch = 'state_only';
    }

    const total_amount = subtotal + additional_amount;

    // Inserir pedido
    const orderResult = await client.query(
      `INSERT INTO tb_pedido (
        id_loja, id_fornecedor, status, vl_total_pedido,
        valor_adicional, observacoes, forma_pagamento, prazo_pagamento, id_conta
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id`,
      [store_id, supplier_id, statusMap[status], total_amount, additional_amount, notes, payment_method || null, payment_term_days, accountId]
    );
    const orderId = orderResult.rows[0].id;

    // Inserir itens normalizados
    for (const ni of normalizedItems) {
      await client.query(
        `INSERT INTO tb_pedido_item (
          id_pedido, id_produto, quantidade, valor_unitario, valor_total,
          produto, id_conta, id_fornecedor
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [orderId, ni.product_id, ni.quantity, ni.unit_price, ni.total, ni.product_name, accountId, supplier_id]
      );
    }

    // Persist applied campaigns if support table exists (safe no-op if missing)
    try {
      const existsRes = await client.query(`SELECT to_regclass('public.tb_pedido_campanha') AS reg`);
      const hasLinkTable = !!existsRes.rows[0]?.reg;
      if (hasLinkTable && applied_campaigns.length > 0) {
        for (const cId of applied_campaigns) {
          const insight = campaign_insights.find(ci => ci.id === cId);
          await client.query(
            `INSERT INTO tb_pedido_campanha (id_pedido, id_campanha, percentual_cashback, valor_calculado)
             VALUES ($1, $2, $3, $4)`,
            [orderId, cId, insight?.percent || null, insight?.predictedCashback || 0]
          );
        }
      }
    } catch (e) {
      // Silencia erro caso tabela ainda não exista; pode ser criada depois
      console.warn('Falha ao persistir campanhas aplicadas (tb_pedido_campanha ausente?):', e.message);
    }

    // Persistir cashback (tb_loja_cashback e, opcionalmente, detalhes) usando SAVEPOINTs
    if (cashback_amount > 0) {
      let cashbackId = null;
      await client.query('SAVEPOINT sp_cashback');
      try {
        const cashbackRes = await client.query(
          `INSERT INTO tb_loja_cashback (
            id_pedido, id_loja, id_fornecedor, vl_previsto, id_conta
          ) VALUES ($1, $2, $3, $4, $5)
          RETURNING id`,
          [orderId, store_id, supplier_id, cashback_amount, accountId]
        );
        cashbackId = cashbackRes.rows[0]?.id || null;
        cashbackSaved = !!cashbackId;
      } catch (e) {
        console.warn('Falha ao inserir tb_loja_cashback (ignorado):', e.message);
        await client.query('ROLLBACK TO SAVEPOINT sp_cashback');
      }

      if (cashbackId) {
        // Tentar registrar detalhe de cashback previsto por pedido (não por item)
        await client.query('SAVEPOINT sp_cashback_details');
        try {
          // Verificar se a tabela existe antes de tentar inserir; se não existir, apenas logar.
          const regRes = await client.query(`SELECT to_regclass('public.tb_loja_cashback_detalhes') AS reg`);
          const hasDetailsTable = !!regRes.rows[0]?.reg;
          if (hasDetailsTable) {
            await client.query(
              `INSERT INTO tb_loja_cashback_detalhes (
                 vl_previsto, vl_realizado, id_usuario, id_conta, dt_inc,
                 id_loja, id_fornecedor, id_cashback, id_pedido_item
               ) VALUES ($1, 0, NULL, $2, CURRENT_TIMESTAMP,
                 $3, $4, $5, NULL)`,
              [cashback_amount, accountId, store_id, supplier_id, cashbackId]
            );
            cashbackDetailsSaved = true;
          } else {
            console.warn('Tabela tb_loja_cashback_detalhes não encontrada; pulando inserção de detalhes.');
          }
        } catch (e) {
          console.warn('Falha ao inserir tb_loja_cashback_detalhes (ignorado):', e.message);
          // Tenta um INSERT mínimo com colunas mais comuns (fallback), antes de reverter o savepoint
          try {
            await client.query(
              `INSERT INTO tb_loja_cashback_detalhes (
                 vl_previsto, vl_realizado, id_loja, id_fornecedor, id_cashback, id_pedido_item, id_conta
               ) VALUES ($1, 0, $2, $3, $4, NULL, $5)`,
              [cashback_amount, store_id, supplier_id, cashbackId, accountId]
            );
            cashbackDetailsSaved = true;
          } catch (e2) {
            console.warn('Fallback de inserção em tb_loja_cashback_detalhes também falhou (ignorado):', e2.message);
            await client.query('ROLLBACK TO SAVEPOINT sp_cashback_details');
          }
        }
      }
    }

    await client.query('COMMIT');

    // Retornar pedido criado no mesmo formato do GET /api/orders, enriquecido com diagnóstico de cashback
    const createdResult = await client.query(
      `SELECT 
        p.id,
        p.id as order_number,
        p.id_loja as store_id,
        p.id_fornecedor as supplier_id,
        p.status as db_status,
        p.vl_total_pedido as total_amount,
        p.dt_inc as created_date,
        p.valor_adicional as additional_amount,
        p.observacoes as notes,
        p.forma_pagamento as payment_method,
        (
          SELECT COALESCE(SUM(pi.valor_total), 0)
          FROM tb_pedido_item pi 
          WHERE pi.id_pedido = p.id
        ) as subtotal,
        (
          SELECT COALESCE(SUM(lc.vl_previsto), 0)
          FROM tb_loja_cashback lc 
          WHERE lc.id_pedido = p.id
        ) as cashback_amount,
        (
          SELECT json_agg(
            json_build_object(
              'product_id', pi.id_produto,
              'product_name', COALESCE(pi.produto, 'Produto não encontrado'),
              'quantity', pi.quantidade,
              'unit_price', pi.valor_unitario,
              'total', pi.valor_total
            )
          )
          FROM tb_pedido_item pi 
          WHERE pi.id_pedido = p.id
        ) as items
      FROM tb_pedido p
      WHERE p.id = $1`,
      [orderId]
    );

    const createdOrder = createdResult.rows[0] || {};
    const response = {
      ...createdOrder,
      status: reverseStatusMap[createdOrder.db_status] || 'pending',
      payment_term_days,
      applied_campaigns,
      diagnostics: {
        cashback: {
          branch: cashback_branch,
          campaign_insights,
          persisted: cashbackSaved,
          details_persisted: cashbackDetailsSaved
        }
      }
    };

    res.status(201).json(response);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

// PUT /api/orders/:id
router.put('/:id', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const { status, numero_nota_fiscal, chave_nota_fiscal } = req.body;
    const newDbStatus = statusMap[status] || status;

    // Validar campos de NF quando fornecidos (regras: chave 44 dígitos; número até 9 dígitos)
    let nfNumeroClean = null;
    let nfChaveClean = null;
    if (typeof numero_nota_fiscal !== 'undefined' && numero_nota_fiscal !== null && String(numero_nota_fiscal).trim() !== '') {
      const cleaned = String(numero_nota_fiscal).replace(/\D/g, '');
      if (cleaned.length > 9) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Número da nota fiscal deve ter no máximo 9 dígitos.' });
      }
      nfNumeroClean = cleaned;
    }
    if (typeof chave_nota_fiscal !== 'undefined' && chave_nota_fiscal !== null && String(chave_nota_fiscal).trim() !== '') {
      const cleaned = String(chave_nota_fiscal).replace(/\D/g, '');
      if (cleaned.length !== 44) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Chave da NF-e deve conter exatamente 44 dígitos.' });
      }
      nfChaveClean = cleaned;
    }

    // Buscar status atual e bloquear linha
    const existingRes = await client.query(
      'SELECT status FROM tb_pedido WHERE id = $1 FOR UPDATE',
      [req.params.id]
    );
    if (existingRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Order not found' });
    }
    const currentDbStatus = existingRes.rows[0].status;

    // Apenas uma vez: ao passar de PENDENTE para PROCESSANDO, decrementa estoque
    if (currentDbStatus === 'PENDENTE' && newDbStatus === 'PROCESSANDO') {
      const itemsRes = await client.query(
        'SELECT id_produto, quantidade FROM tb_pedido_item WHERE id_pedido = $1',
        [req.params.id]
      );
      for (const item of itemsRes.rows) {
        await client.query(
          `UPDATE tb_fornecedor_produto
             SET quantidade_estoque = GREATEST(0, quantidade_estoque - $1)
           WHERE id = $2`,
          [Number(item.quantidade || 0), item.id_produto]
        );
      }
    }

    // Ao cancelar pedido, devolve estoque (só se já tinha sido processado)
    if (newDbStatus === 'CANCELADO' && currentDbStatus !== 'PENDENTE') {
      const itemsRes = await client.query(
        'SELECT id_produto, quantidade FROM tb_pedido_item WHERE id_pedido = $1',
        [req.params.id]
      );
      for (const item of itemsRes.rows) {
        await client.query(
          `UPDATE tb_fornecedor_produto
             SET quantidade_estoque = quantidade_estoque + $1
           WHERE id = $2`,
          [Number(item.quantidade || 0), item.id_produto]
        );
      }
    }

    // Quando marcado como SEPARADO, permitir atualizar numero/chave da nota, se enviados
    let updateSql = `UPDATE tb_pedido SET status = $1, dh_ultima_alteracao = CURRENT_TIMESTAMP`;
    const updateValues = [newDbStatus];
    let idx = 2;
    if (newDbStatus === 'SEPARADO') {
      if (typeof numero_nota_fiscal !== 'undefined') {
        updateSql += `, numero_nota_fiscal = $${idx++}`;
        updateValues.push(nfNumeroClean || null);
      }
      if (typeof chave_nota_fiscal !== 'undefined') {
        updateSql += `, chave_nota_fiscal = $${idx++}`;
        updateValues.push(nfChaveClean || null);
      }
    }
    updateSql += ` WHERE id = $${idx} RETURNING 
        id,
        id as order_number,
        id_loja as store_id,
        id_fornecedor as supplier_id,
        vl_total_pedido as total_amount,
        dt_inc as created_date,
        valor_adicional as additional_amount,
        observacoes as notes,
        numero_nota_fiscal,
        chave_nota_fiscal`;
    updateValues.push(req.params.id);

    const updateRes = await client.query(updateSql, updateValues);

    const itemsAgg = await client.query(
      `SELECT json_agg(
          json_build_object(
            'product_id', pi.id_produto,
            'product_name', COALESCE(pi.produto, 'Produto não encontrado'),
            'quantity', pi.quantidade,
            'unit_price', pi.valor_unitario,
            'total', pi.valor_total
          )
        ) AS items
        FROM tb_pedido_item pi
        WHERE pi.id_pedido = $1`,
      [req.params.id]
    );

    await client.query('COMMIT');

    const payload = {
      ...updateRes.rows[0],
      status,
      items: itemsAgg.rows[0]?.items || []
    };
    res.json(payload);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

export default router;