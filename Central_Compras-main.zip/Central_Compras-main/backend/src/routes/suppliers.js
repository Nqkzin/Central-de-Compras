import express from 'express';
import { db } from '../database/database.js';
import bcrypt from 'bcryptjs';
import { sendWelcomeEmail } from '../services/emailService.js';

const router = express.Router();

// Helper: gera email padronizado @central.com a partir do nome completo
function generateCentralEmail(fullName) {
  if (!fullName || typeof fullName !== 'string') return 'usuario@central.com';
  
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'usuario@central.com';
  
  const firstName = parts[0].toLowerCase();
  const lastName = parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
  
  // Remove acentos e caracteres especiais
  const normalize = (str) => str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  
  const firstNormalized = normalize(firstName);
  const lastNormalized = normalize(lastName);
  
  if (lastNormalized) {
    return `${firstNormalized}.${lastNormalized}@central.com`;
  }
  return `${firstNormalized}@central.com`;
}

// GET /api/suppliers
router.get('/', async (req, res) => {
  try {
    const { status, sort, id } = req.query;
    let query = `
      SELECT 
        f.id,
        f.razao_social as name,
        f.nome_fantasia as fantasy_name,
        f.cnpj,
        f.inscricao_estadual,
        f.site,
        fe.logradouro as address,
        fe.numero as address_number,
        fe.bairro as neighborhood,
        fe.referencia as reference,
        fe.cidade as city,
        fe.estado as state,
        fe.cep as zip_code,
        c.nome as contact_name,
        c.cargo as contact_position,
        c.email as contact_email,
        c.telefone as contact_phone,
        f.email_nfe as nfe_email,
        cat.nome as category,
        COALESCE(f.permitir_gerenciar_produtos, true) as can_manage_products,
        CASE WHEN f.ativo = true THEN 'active' ELSE 'inactive' END as status,
        f.id_usuario_owner as user_id,
        f.foto_url as image_url
      FROM tb_fornecedor f
      LEFT JOIN tb_fornecedor_endereco fe ON f.id = fe.id_fornecedor AND fe.is_endereco_principal = true
      LEFT JOIN tb_contato c ON f.id = c.id_fornecedor AND c.is_responsavel = true
      LEFT JOIN tb_categoria cat ON f.id_categoria = cat.id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (id) {
      const rawId = Array.isArray(id) ? id[0] : id;
      const numericId = Number(rawId);
      if (!Number.isInteger(numericId)) {
        return res.status(400).json({ error: 'Invalid supplier id filter' });
      }
      paramCount++;
      query += ` AND f.id = $${paramCount}`;
      params.push(numericId);
    }

    if (status) {
      paramCount++;
      query += ` AND f.ativo = $${paramCount}`;
      params.push(status === 'active');
    }

    if (sort) {
      const sortField = sort.startsWith('-') ? sort.slice(1) : sort;
      const sortOrder = sort.startsWith('-') ? 'DESC' : 'ASC';
      const sortMap = {
        created_date: 'f.dt_inc',
        name: 'f.razao_social',
        cnpj: 'f.cnpj'
      };
      const sortColumn = sortMap[sortField] || sortField;
      query += ` ORDER BY ${sortColumn} ${sortOrder}`;
    } else {
      query += ' ORDER BY f.razao_social ASC';
    }

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/suppliers/:id
router.get('/:id', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT 
        f.id,
        f.razao_social as name,
        f.nome_fantasia as fantasy_name,
        f.cnpj,
        f.inscricao_estadual,
        f.site,
        fe.logradouro as address,
        fe.numero as address_number,
        fe.bairro as neighborhood,
        fe.referencia as reference,
        fe.cidade as city,
        fe.estado as state,
        fe.cep as zip_code,
        c.nome as contact_name,
        c.email as contact_email,
        f.telefone as contact_phone,
        f.email_nfe as nfe_email,
        cat.nome as category,
        COALESCE(f.permitir_gerenciar_produtos, true) as can_manage_products,
        CASE WHEN f.ativo = true THEN 'active' ELSE 'inactive' END as status,
        f.id_usuario_owner as user_id,
        f.foto_url as image_url
      FROM tb_fornecedor f
      LEFT JOIN tb_fornecedor_endereco fe ON f.id = fe.id_fornecedor AND fe.is_endereco_principal = true
      LEFT JOIN tb_contato c ON f.id = c.id_fornecedor AND c.is_responsavel = true
      LEFT JOIN tb_categoria cat ON f.id_categoria = cat.id
      WHERE f.id = $1`,
      [req.params.id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Supplier not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/suppliers
router.post('/', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    
    const {
      name, fantasy_name, inscricao_estadual, site,
      cnpj, address, city, state, zip_code,
        address_number, neighborhood, reference,
        contact_name, contact_position, contact_email, contact_phone, nfe_email,
        image_url, categories, category, status = 'active', user_id, id_conta,
        can_manage_products = true,
        additional_contacts
      } = req.body;
      const accountId = id_conta ?? null;

      // Resolver um account id válido similar à rota de stores: encontrar existente ou criar padrão
      let accountIdResolved = accountId;
      if (!accountIdResolved) {
        const accRes = await client.query('SELECT id FROM tb_sistema_conta LIMIT 1');
        if (accRes.rows.length > 0) {
          accountIdResolved = accRes.rows[0].id;
        } else {
          const newAcc = await client.query(
            'INSERT INTO tb_sistema_conta (nm_conta, dh_inc) VALUES ($1, CURRENT_TIMESTAMP) RETURNING id',
            ['Conta Padrão']
          );
          accountIdResolved = newAcc.rows[0].id;
        }
      }

    // Normalizar campos numéricos formatados para apenas dígitos (CNPJ, CEP, telefones)
    const cnpjClean = cnpj ? String(cnpj).replace(/\D/g, '') : null;
    const zipClean = zip_code ? String(zip_code).replace(/\D/g, '') : null;
    const phoneClean = contact_phone ? String(contact_phone).replace(/\D/g, '') : null;

    // Garantir que fornecemos um valor não-nulo para a coluna de email requerida do fornecedor
    const emailFornecedor = req.body.email_fornecedor ?? contact_email ?? nfe_email ?? '';

    // Resolver categoria (permitindo usar tanto 'categories' quanto 'category' do frontend)
    const incomingCategoryName = category || categories || null;
    let categoriaId = null;
    if (incomingCategoryName) {
      const catResult = await client.query(
        'SELECT id FROM tb_categoria WHERE nome = $1',
        [incomingCategoryName]
      );
      if (catResult.rows.length > 0) {
        categoriaId = catResult.rows[0].id;
      } else {
        const newCat = await client.query(
          'INSERT INTO tb_categoria (nome) VALUES ($1) RETURNING id',
          [incomingCategoryName]
        );
        categoriaId = newCat.rows[0].id;
      }
    }

    // Criar usuário owner se não enviado: usa email padronizado @central.com
    let ownerUserId = user_id || null;
    let generatedPassword = null;
    if (!ownerUserId && contact_email) {
      const centralEmail = generateCentralEmail(contact_name || name || 'Usuario Fornecedor');
      const existing = await client.query(
        'SELECT id FROM tb_sistema_usuario WHERE email = $1 AND id_conta = $2 AND ativo = true LIMIT 1',
        [centralEmail, accountIdResolved]
      );
      if (existing.rows.length > 0) {
        ownerUserId = existing.rows[0].id;
      } else {
        const gen = () => Math.random().toString(36).slice(-10);
        generatedPassword = gen();
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(generatedPassword, salt);
        const userIns = await client.query(
          `INSERT INTO tb_sistema_usuario (id_conta, nome, email, senha, ativo, must_change_password)
           VALUES ($1, $2, $3, $4, true, true) RETURNING id`,
          [accountIdResolved, contact_name || name || 'Usuário Fornecedor', centralEmail, hash]
        );
        ownerUserId = userIns.rows[0].id;
        await client.query(
          'INSERT INTO tb_sistema_usuario_perfil (id_usuario, perfil) VALUES ($1, $2)',
          [ownerUserId, 'supplier']
        );
      }
    }

    // Inserir fornecedor (inclui foto_url e id_categoria quando disponível)
    const supplierResult = await client.query(
      `INSERT INTO tb_fornecedor (
        razao_social, nome_fantasia, cnpj, inscricao_estadual, site,
        email_fornecedor, telefone, email_nfe, ativo,
        id_usuario_owner, id_conta, foto_url, id_categoria, permitir_gerenciar_produtos
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING id`,
      [name, fantasy_name || null, cnpjClean, inscricao_estadual || null, site || null,
       emailFornecedor, phoneClean, nfe_email, status === 'active', ownerUserId, accountIdResolved,
       image_url || null, categoriaId, can_manage_products]
    );

    const supplierId = supplierResult.rows[0].id;

    // Inserir endereço
      if (address && city && state && zip_code) {
        await client.query(
          `INSERT INTO tb_fornecedor_endereco (
            id_fornecedor, logradouro, numero, bairro, referencia, cidade, estado, cep, is_endereco_principal, id_conta
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
          [supplierId, address, address_number || null, neighborhood || null, reference || null, city, state, zipClean, true, accountIdResolved]
        );
    }

    // Inserir contato principal
      if (contact_name && contact_email) {
        await client.query(
          `INSERT INTO tb_contato (
            id_fornecedor, nome, cargo, email, telefone, is_responsavel, id_conta
          ) VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [supplierId, contact_name, contact_position || null, contact_email, phoneClean, true, accountIdResolved]
        );
    }

    // Inserir contatos adicionais (não responsáveis)
    let insertedExtras = 0;
    const receivedExtras = Array.isArray(additional_contacts) ? additional_contacts.length : 0;
    if (Array.isArray(additional_contacts) && additional_contacts.length > 0) {
      for (const c of additional_contacts) {
        if (!c || (!c.name && !c.email && !c.phone)) continue; // ignora linhas vazias
        const phoneExtra = c.phone ? String(c.phone).replace(/\D/g, '') : null;
        await client.query(
          `INSERT INTO tb_contato (
            id_fornecedor, nome, email, telefone, cargo, outras_informacoes, is_responsavel, id_conta
          ) VALUES ($1, $2, $3, $4, $5, $6, false, $7)`,
          [supplierId, c.name || null, c.email || null, phoneExtra, c.position || null, c.notes || null, accountIdResolved]
        );
        insertedExtras++;
      }
    }

    await client.query('COMMIT');

    // Retornar fornecedor criado (mesmo shape do GET para consistência)
    const result = await client.query(
      `SELECT 
        f.id,
        f.razao_social as name,
        f.nome_fantasia as fantasy_name,
        f.cnpj,
        f.inscricao_estadual,
        f.site,
        fe.logradouro as address,
        fe.cidade as city,
        fe.estado as state,
        fe.cep as zip_code,
        c.nome as contact_name,
        c.email as contact_email,
        f.telefone as contact_phone,
        f.email_nfe as nfe_email,
        cat.nome as category,
        COALESCE(f.permitir_gerenciar_produtos, true) as can_manage_products,
        CASE WHEN f.ativo = true THEN 'active' ELSE 'inactive' END as status,
        f.id_usuario_owner as user_id,
        f.foto_url as image_url
      FROM tb_fornecedor f
      LEFT JOIN tb_fornecedor_endereco fe ON f.id = fe.id_fornecedor AND fe.is_endereco_principal = true
      LEFT JOIN tb_contato c ON f.id = c.id_fornecedor AND c.is_responsavel = true
      LEFT JOIN tb_categoria cat ON f.id_categoria = cat.id
      WHERE f.id = $1`,
      [supplierId]
    );

    const payload = { 
      ...result.rows[0],
      _debug_contacts: {
        receivedAdditionalContactsCount: receivedExtras,
        insertedAdditionalContactsCount: insertedExtras
      }
    };
    if (generatedPassword) {
      const centralEmail = generateCentralEmail(contact_name || name || 'Usuario Fornecedor');
      payload.generated_password = generatedPassword;
      payload.generated_email = centralEmail;
      
      // Enviar email com as credenciais (não bloqueia a resposta se falhar)
      if (contact_email) {
        console.log('📧 Tentando enviar email para:', contact_email);
        sendWelcomeEmail({
          to: contact_email,
          name: contact_name || name || 'Usuário',
          email: centralEmail,
          password: generatedPassword,
          type: 'supplier'
        }).then(result => {
          if (result.success) {
            console.log('✅ Email enviado com sucesso!');
          } else {
            console.log('⚠️ Email não foi enviado:', result.error);
          }
        }).catch(err => {
          console.error('❌ Erro ao enviar email de boas-vindas:', err);
        });
      } else {
        console.log('⚠️ Nenhum email de contato fornecido, email não será enviado');
      }
    }
    res.status(201).json(payload);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

// PUT /api/suppliers/:id
router.put('/:id', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const supplierId = req.params.id;
    const {
      name,
      fantasy_name,
      inscricao_estadual,
      site,
      cnpj,
      address,
        address_number,
        neighborhood,
        reference,
      city,
      state,
      zip_code,
      contact_name,
      contact_position,
      contact_email,
      contact_phone,
      nfe_email,
      image_url,
      status,
      can_manage_products,
      category,
      additional_contacts
    } = req.body;

    // Normalizar campos numéricos
    const cnpjClean = cnpj ? String(cnpj).replace(/\D/g, '') : null;
    const zipClean = zip_code ? String(zip_code).replace(/\D/g, '') : null;
    const phoneClean = contact_phone ? String(contact_phone).replace(/\D/g, '') : null;

    // Opcional: mapear nome da categoria para id
    let categoriaId = null;
    if (category) {
      const catRes = await client.query('SELECT id FROM tb_categoria WHERE nome = $1', [category]);
      if (catRes.rows.length > 0) {
        categoriaId = catRes.rows[0].id;
      } else {
        const newCat = await client.query('INSERT INTO tb_categoria (nome) VALUES ($1) RETURNING id', [category]);
        categoriaId = newCat.rows[0].id;
      }
    }

    // Atualizar tabela central de fornecedor
    const updateRes = await client.query(
      `UPDATE tb_fornecedor SET 
         razao_social = COALESCE($1, razao_social),
         nome_fantasia = $2,
         cnpj = COALESCE($3, cnpj),
         inscricao_estadual = COALESCE($4, inscricao_estadual),
         site = COALESCE($5, site),
         telefone = COALESCE($6, telefone),
         email_nfe = COALESCE($7, email_nfe),
         foto_url = COALESCE($8, foto_url),
         ativo = COALESCE($9, ativo),
         id_categoria = COALESCE($10, id_categoria),
         permitir_gerenciar_produtos = COALESCE($11, permitir_gerenciar_produtos),
         dt_alt = CURRENT_TIMESTAMP
       WHERE id = $12
       RETURNING id`,
      [name, fantasy_name || null, cnpjClean, inscricao_estadual, site, phoneClean, nfe_email, image_url, (typeof status === 'string' ? status === 'active' : undefined), categoriaId, can_manage_products, supplierId]
    );

    if (updFornecedor.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Supplier not found' });
    }

    // Se o fornecedor foi inativado, inativar todas as campanhas dele
    if (status === 'inactive') {
      await client.query(
        'UPDATE tb_fornecedor_campanha SET ativa = false WHERE id_fornecedor = $1',
        [supplierId]
      );
    }

    // Upsert de endereço como endereço principal
    if (address || city || state || zip_code || address_number || neighborhood || reference) {
      const addrRes = await client.query(
        'SELECT id FROM tb_fornecedor_endereco WHERE id_fornecedor = $1 AND is_endereco_principal = true',
        [supplierId]
      );
      if (addrRes.rows.length > 0) {
        await client.query(
          `UPDATE tb_fornecedor_endereco SET 
             logradouro = COALESCE($1, logradouro),
             numero = COALESCE($2, numero),
             bairro = COALESCE($3, bairro),
             referencia = COALESCE($4, referencia),
               cidade = COALESCE($5, cidade),
               estado = COALESCE($6, estado),
             cep = COALESCE($7, cep)
           WHERE id_fornecedor = $8 AND is_endereco_principal = true`,
          [address, address_number || null, neighborhood || null, reference || null, city, state, zipClean, supplierId]
        );
      } else if (address && city && state && zip_code) {
        // Precisa de um account id; fallback para qualquer existente
        const accRes = await client.query('SELECT id FROM tb_sistema_conta LIMIT 1');
        const accountId = accRes.rows[0]?.id ?? null;
        await client.query(
          `INSERT INTO tb_fornecedor_endereco (id_fornecedor, logradouro, numero, bairro, referencia, cidade, estado, cep, is_endereco_principal, id_conta)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, $9)`,
          [supplierId, address, address_number || null, neighborhood || null, reference || null, city, state, zipClean, accountId]
        );
      }
    }

    // Upsert de contato responsável
    if (contact_name || contact_email || contact_phone) {
      const contRes = await client.query(
        'SELECT id FROM tb_contato WHERE id_fornecedor = $1 AND is_responsavel = true',
        [supplierId]
      );
      if (contRes.rows.length > 0) {
        await client.query(
          `UPDATE tb_contato SET 
             nome = COALESCE($1, nome),
             cargo = COALESCE($2, cargo),
             email = COALESCE($3, email),
             telefone = COALESCE($4, telefone)
           WHERE id_fornecedor = $5 AND is_responsavel = true`,
          [contact_name, contact_position || null, contact_email, phoneClean, supplierId]
        );
      } else if (contact_name && contact_email) {
        const accRes = await client.query('SELECT id FROM tb_sistema_conta LIMIT 1');
        const accountId = accRes.rows[0]?.id ?? null;
        await client.query(
          `INSERT INTO tb_contato (id_fornecedor, nome, cargo, email, telefone, is_responsavel, id_conta)
           VALUES ($1, $2, $3, $4, $5, true, $6)`,
          [supplierId, contact_name, contact_position || null, contact_email, phoneClean, accountId]
        );
      }
    }

    // Deletar contatos extras antigos (não responsáveis) e inserir os novos
    await client.query(
      'DELETE FROM tb_contato WHERE id_fornecedor = $1 AND is_responsavel = false',
      [supplierId]
    );

    let insertedExtras = 0;
    let receivedExtras = Array.isArray(additional_contacts) ? additional_contacts.length : 0;
    if (Array.isArray(additional_contacts) && additional_contacts.length > 0) {
      for (const c of additional_contacts) {
        if (!c || (!c.name && !c.email && !c.phone)) continue;
        const phoneExtra = c.phone ? String(c.phone).replace(/\D/g, '') : null;
        await client.query(
          `INSERT INTO tb_contato (id_fornecedor, nome, email, telefone, cargo, outras_informacoes, is_responsavel, id_conta)
           VALUES ($1, $2, $3, $4, $5, $6, false, (SELECT id_conta FROM tb_fornecedor WHERE id = $7 LIMIT 1))`,
          [supplierId, c.name || null, c.email || null, phoneExtra, c.position || null, c.notes || null, supplierId]
        );
        insertedExtras++;
      }
    }

    await client.query('COMMIT');

    // Retornar sumário atualizado do fornecedor similar ao GET por id
    const result = await db.query(
      `SELECT 
        f.id,
        f.razao_social as name,
        f.nome_fantasia as fantasy_name,
        f.cnpj,
        f.inscricao_estadual,
        f.site,
        fe.logradouro as address,
        fe.numero as address_number,
        fe.bairro as neighborhood,
        fe.referencia as reference,
        fe.cidade as city,
        fe.estado as state,
        fe.cep as zip_code,
        c.nome as contact_name,
        c.email as contact_email,
        f.telefone as contact_phone,
        f.email_nfe as nfe_email,
        cat.nome as category,
        COALESCE(f.permitir_gerenciar_produtos, true) as can_manage_products,
        CASE WHEN f.ativo = true THEN 'active' ELSE 'inactive' END as status,
        f.id_usuario_owner as user_id,
        f.foto_url as image_url
      FROM tb_fornecedor f
      LEFT JOIN tb_fornecedor_endereco fe ON f.id = fe.id_fornecedor AND fe.is_endereco_principal = true
      LEFT JOIN tb_contato c ON f.id = c.id_fornecedor AND c.is_responsavel = true
      LEFT JOIN tb_categoria cat ON f.id_categoria = cat.id
      WHERE f.id = $1`,
      [supplierId]
    );

    res.json({
      ...result.rows[0],
      _debug_contacts_update: {
        receivedAdditionalContactsCount: receivedExtras,
        insertedAdditionalContactsCount: insertedExtras
      }
    });
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

export default router;