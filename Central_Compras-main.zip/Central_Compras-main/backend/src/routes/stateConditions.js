import express from 'express';
import { db } from '../database/database.js';

const router = express.Router();

// Convenção para marcar condição inativa dentro do campo de observações
const INACTIVE_TAG = '[INATIVA]';

// GET /api/state-conditions
router.get('/', async (req, res) => {
  try {
    const { supplier_id, state, status } = req.query;
    let query = `
      SELECT 
        fc.id,
        fc.id_fornecedor as supplier_id,
        fc.estado as state,
        fc.percentual_cashback as cashback_percentage,
        fc.max_cashback_amount,
        fc.pedido_minimo as pedido_minimo,
        fc.pedido_minimo_frete_cif as pedido_minimo_frete_cif,
        fc.prazo_dias as payment_term_days,
        fc.ajuste_valor_unitario as unit_price_adjustment,
        fc.link_catalogo as catalog_url,
        fc.observacoes as notes,
        CASE 
          WHEN fc.observacoes ILIKE '%${INACTIVE_TAG.replace(/\[/g,'[').replace(/\]/g,']')}%' THEN 'inactive'
          ELSE 'active'
        END as status
      FROM tb_fornecedor_condicao fc
      WHERE 1=1
    `;

    const params = [];
    let paramCount = 0;

    if (supplier_id) {
      paramCount++;
      query += ` AND fc.id_fornecedor = $${paramCount}`;
      params.push(supplier_id);
    }

    if (state) {
      paramCount++;
      query += ` AND fc.estado = $${paramCount}`;
      params.push(state);
    }

    if (status === 'active') {
      query += ` AND (fc.observacoes IS NULL OR fc.observacoes NOT ILIKE '%${INACTIVE_TAG}%')`;
    } else if (status === 'inactive') {
      query += ` AND fc.observacoes ILIKE '%${INACTIVE_TAG}%'`;
    }

    query += ' ORDER BY fc.estado';

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/state-conditions
router.post('/', async (req, res) => {
  try {
    const {
      supplier_id, state, cashback_percentage, payment_term_days,
      unit_price_adjustment, catalog_url, notes: rawNotes, id_conta,
      max_cashback_amount, status, pedido_minimo, pedido_minimo_frete_cif
    } = req.body;
    let accountId = id_conta ?? null;

    // Fallback: buscar id_conta do fornecedor quando não informado
    if (!accountId && supplier_id) {
      try {
        const supplierRes = await db.query('SELECT id_conta FROM tb_fornecedor WHERE id = $1', [supplier_id]);
        if (supplierRes.rows.length && supplierRes.rows[0].id_conta) {
          accountId = supplierRes.rows[0].id_conta;
        }
      } catch (lookupErr) {
        console.error('Erro ao buscar id_conta do fornecedor:', lookupErr.message);
      }
    }

    // Normalização das observações com a tag de status
    let notes = rawNotes || '';
    const hasInactiveTag = notes.toUpperCase().includes(INACTIVE_TAG);
    if (status === 'inactive' && !hasInactiveTag) {
      notes = notes ? `${notes} ${INACTIVE_TAG}` : INACTIVE_TAG;
    } else if (status === 'active' && hasInactiveTag) {
      notes = notes.replace(new RegExp(INACTIVE_TAG, 'gi'), '').trim();
    }

    const sql = `
      INSERT INTO tb_fornecedor_condicao (
        id_fornecedor, estado, percentual_cashback, max_cashback_amount, pedido_minimo, pedido_minimo_frete_cif, prazo_dias,
        ajuste_valor_unitario, link_catalogo, observacoes, id_conta
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      ON CONFLICT (id_fornecedor, estado)
      DO UPDATE SET
        percentual_cashback = EXCLUDED.percentual_cashback,
        max_cashback_amount = EXCLUDED.max_cashback_amount,
        pedido_minimo = EXCLUDED.pedido_minimo,
        pedido_minimo_frete_cif = EXCLUDED.pedido_minimo_frete_cif,
        prazo_dias = EXCLUDED.prazo_dias,
        ajuste_valor_unitario = EXCLUDED.ajuste_valor_unitario,
        link_catalogo = EXCLUDED.link_catalogo,
        observacoes = EXCLUDED.observacoes
      RETURNING 
        id,
        id_fornecedor as supplier_id,
        estado as state,
        percentual_cashback as cashback_percentage,
        max_cashback_amount,
        pedido_minimo,
        pedido_minimo_frete_cif,
        prazo_dias as payment_term_days,
        ajuste_valor_unitario as unit_price_adjustment,
        link_catalogo as catalog_url,
        observacoes as notes,
        CASE WHEN observacoes ILIKE '%${INACTIVE_TAG}%' THEN 'inactive' ELSE 'active' END as status
    `;

    const values = [
      supplier_id, state, cashback_percentage, max_cashback_amount, pedido_minimo || 0, pedido_minimo_frete_cif || 0, payment_term_days,
      unit_price_adjustment, catalog_url, notes, accountId
    ];

    const result = await db.query(sql, values);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /api/state-conditions/:id
router.put('/:id', async (req, res) => {
  try {
    const {
      state, cashback_percentage, payment_term_days,
      unit_price_adjustment, catalog_url, notes: rawNotes,
      max_cashback_amount, status, pedido_minimo, pedido_minimo_frete_cif
    } = req.body;

    let notes = rawNotes || '';
    const hasInactiveTag = notes.toUpperCase().includes(INACTIVE_TAG);
    if (status === 'inactive' && !hasInactiveTag) {
      notes = notes ? `${notes} ${INACTIVE_TAG}` : INACTIVE_TAG;
    } else if (status === 'active' && hasInactiveTag) {
      notes = notes.replace(new RegExp(INACTIVE_TAG, 'gi'), '').trim();
    }

    const result = await db.query(
      `UPDATE tb_fornecedor_condicao SET 
        estado = COALESCE($1, estado),
        percentual_cashback = $2,
        max_cashback_amount = $3,
        pedido_minimo = $4,
        pedido_minimo_frete_cif = $5,
        prazo_dias = $6,
        ajuste_valor_unitario = $7,
        link_catalogo = $8, 
        observacoes = $9
      WHERE id = $10
      RETURNING 
        id,
        id_fornecedor as supplier_id,
        estado as state,
        percentual_cashback as cashback_percentage,
        max_cashback_amount,
        pedido_minimo,
        pedido_minimo_frete_cif,
        prazo_dias as payment_term_days,
        ajuste_valor_unitario as unit_price_adjustment,
        link_catalogo as catalog_url,
        observacoes as notes,
        CASE WHEN observacoes ILIKE '%${INACTIVE_TAG}%' THEN 'inactive' ELSE 'active' END as status`,
      [state, cashback_percentage, max_cashback_amount, pedido_minimo || 0, pedido_minimo_frete_cif || 0, payment_term_days,
       unit_price_adjustment, catalog_url, notes, req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'State condition not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/state-conditions/:id
router.delete('/:id', async (req, res) => {
  try {
    const result = await db.query(
      'DELETE FROM tb_fornecedor_condicao WHERE id = $1 RETURNING id',
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'State condition not found' });
    }

    res.json({ success: true, id: result.rows[0].id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
// BULK create/replicate endpoint
router.post('/bulk', async (req, res) => {
  try {
    const { conditions } = req.body; // expects array of objects
    if (!Array.isArray(conditions) || conditions.length === 0) {
      return res.status(400).json({ error: 'Nenhuma condição enviada para replicação' });
    }
    const results = [];
    for (const c of conditions) {
      const {
        supplier_id, state, cashback_percentage, payment_term_days,
        unit_price_adjustment, catalog_url, notes: rawNotes, id_conta,
        max_cashback_amount, status, pedido_minimo, pedido_minimo_frete_cif
      } = c;
      let accountId = id_conta ?? null;
      if (!accountId && supplier_id) {
        try {
          const supplierRes = await db.query('SELECT id_conta FROM tb_fornecedor WHERE id = $1', [supplier_id]);
          if (supplierRes.rows.length && supplierRes.rows[0].id_conta) {
            accountId = supplierRes.rows[0].id_conta;
          }
        } catch (lookupErr) {
          console.error('Erro ao buscar id_conta do fornecedor:', lookupErr.message);
        }
      }
      let notes = rawNotes || '';
      const hasInactiveTag = notes.toUpperCase().includes(INACTIVE_TAG);
      if (status === 'inactive' && !hasInactiveTag) {
        notes = notes ? `${notes} ${INACTIVE_TAG}` : INACTIVE_TAG;
      } else if (status === 'active' && hasInactiveTag) {
        notes = notes.replace(new RegExp(INACTIVE_TAG, 'gi'), '').trim();
      }
      const sql = `
        INSERT INTO tb_fornecedor_condicao (
          id_fornecedor, estado, percentual_cashback, max_cashback_amount, pedido_minimo, pedido_minimo_frete_cif, prazo_dias,
          ajuste_valor_unitario, link_catalogo, observacoes, id_conta
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
        ON CONFLICT (id_fornecedor, estado)
        DO UPDATE SET
          percentual_cashback = EXCLUDED.percentual_cashback,
          max_cashback_amount = EXCLUDED.max_cashback_amount,
          pedido_minimo = EXCLUDED.pedido_minimo,
          pedido_minimo_frete_cif = EXCLUDED.pedido_minimo_frete_cif,
          prazo_dias = EXCLUDED.prazo_dias,
          ajuste_valor_unitario = EXCLUDED.ajuste_valor_unitario,
          link_catalogo = EXCLUDED.link_catalogo,
          observacoes = EXCLUDED.observacoes
        RETURNING 
          id,
          id_fornecedor as supplier_id,
          estado as state,
          percentual_cashback as cashback_percentage,
          max_cashback_amount,
          pedido_minimo,
          pedido_minimo_frete_cif,
          prazo_dias as payment_term_days,
          ajuste_valor_unitario as unit_price_adjustment,
          link_catalogo as catalog_url,
          observacoes as notes,
          CASE WHEN observacoes ILIKE '%${INACTIVE_TAG}%' THEN 'inactive' ELSE 'active' END as status
      `;
      const values = [
        supplier_id, state, cashback_percentage, max_cashback_amount, pedido_minimo || 0, pedido_minimo_frete_cif || 0, payment_term_days,
        unit_price_adjustment, catalog_url, notes, accountId
      ];
      const ins = await db.query(sql, values);
      results.push(ins.rows[0]);
    }
    res.status(201).json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Ensure latest row for supplier/state has desired values
router.post('/ensure-latest', async (req, res) => {
  try {
    const { supplier_id, state, cashback_percentage, max_cashback_amount, status, notes: rawNotes, pedido_minimo, pedido_minimo_frete_cif } = req.body;
    if (!supplier_id || !state) {
      return res.status(400).json({ error: 'supplier_id e state são obrigatórios' });
    }
    const uf = state.toString().trim().toUpperCase();

    // Try update latest row
    const latestRes = await db.query(
      `SELECT id, observacoes FROM tb_fornecedor_condicao
       WHERE id_fornecedor = $1 AND UPPER(TRIM(estado)) = $2
       ORDER BY id DESC
       LIMIT 1`,
      [supplier_id, uf]
    );

    // Normalize notes with INACTIVE tag handling
    const INACTIVE_TAG = '[INATIVA]';
    let notes = rawNotes || (latestRes.rows[0]?.observacoes || '');
    const hasInactiveTag = (notes || '').toUpperCase().includes(INACTIVE_TAG);
    if (status === 'inactive' && !hasInactiveTag) {
      notes = notes ? `${notes} ${INACTIVE_TAG}` : INACTIVE_TAG;
    } else if (status === 'active' && hasInactiveTag) {
      notes = notes.replace(new RegExp(INACTIVE_TAG, 'gi'), '').trim();
    }

    if (latestRes.rows.length > 0) {
      const upd = await db.query(
        `UPDATE tb_fornecedor_condicao SET 
           percentual_cashback = COALESCE($3, percentual_cashback),
           max_cashback_amount = COALESCE($4, max_cashback_amount),
           pedido_minimo = COALESCE($5, pedido_minimo),
           pedido_minimo_frete_cif = COALESCE($6, pedido_minimo_frete_cif),
           observacoes = $7
         WHERE id = $8
         RETURNING id, id_fornecedor as supplier_id, estado as state, percentual_cashback as cashback_percentage, max_cashback_amount, pedido_minimo, pedido_minimo_frete_cif, observacoes as notes`,
        [supplier_id, uf, cashback_percentage, max_cashback_amount, pedido_minimo || 0, pedido_minimo_frete_cif || 0, notes, latestRes.rows[0].id]
      );
      return res.json({ mode: 'updated-latest', row: upd.rows[0] });
    } else {
      // Insert new row as latest
      const accountRes = await db.query('SELECT id_conta FROM tb_fornecedor WHERE id = $1', [supplier_id]);
      const id_conta = accountRes.rows[0]?.id_conta || null;
      const ins = await db.query(
        `INSERT INTO tb_fornecedor_condicao (id_fornecedor, estado, percentual_cashback, max_cashback_amount, pedido_minimo, pedido_minimo_frete_cif, observacoes, id_conta)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         RETURNING id, id_fornecedor as supplier_id, estado as state, percentual_cashback as cashback_percentage, max_cashback_amount, pedido_minimo, pedido_minimo_frete_cif, observacoes as notes`,
        [supplier_id, uf, cashback_percentage, max_cashback_amount, pedido_minimo || 0, pedido_minimo_frete_cif || 0, notes, id_conta]
      );
      return res.status(201).json({ mode: 'inserted', row: ins.rows[0] });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});