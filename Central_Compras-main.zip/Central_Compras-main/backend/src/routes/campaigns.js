import express from 'express';
import { db } from '../database/database.js';

const router = express.Router();

// Mapeamento de tipos de campanha
const campaignTypeMap = {
  'cashback_value': 'VALOR',
  'cashback_quantity': 'QUANTIDADE',
  'gift_quantity': 'PRODUTO'
};

const reverseCampaignTypeMap = {
  'VALOR': 'cashback_value',
  'QUANTIDADE': 'cashback_quantity',
  'PRODUTO': 'gift_quantity'
};

// GET /api/campaigns
router.get('/', async (req, res) => {
  try {
    // Primeiro, inativa automaticamente campanhas expiradas
    await db.query(`
      UPDATE tb_fornecedor_campanha 
      SET ativa = false 
      WHERE ativa = true 
      AND dt_fim IS NOT NULL 
      AND dt_fim < CURRENT_DATE
    `);

    const { supplier_id, status, sort } = req.query;
    let query = `
      SELECT 
        fc.id,
        fc.descricao_campanha as name,
        fc.id_fornecedor as supplier_id,
        fc.tipo_campanha as type, -- valor do banco: VALOR | QUANTIDADE | PRODUTO
        fc.descricao as description,
        fc.foto_url as image_url,
        fc.valor_meta as min_value,
        fc.percentual_cashback as cashback_percentage,
        (
          SELECT fcp.id_produto 
          FROM tb_fornecedor_campanha_produto fcp 
          WHERE fcp.id_campanha = fc.id 
          LIMIT 1
        ) as product_id,
        fc.quantidade_meta as min_quantity,
        fc.descricao_brinde as gift_description,
        fc.dt_inicio as start_date,
        fc.dt_fim as end_date,
        CASE 
          WHEN fc.ativa = true THEN 'active'
          WHEN fc.dt_fim IS NOT NULL AND fc.dt_fim < CURRENT_DATE THEN 'expired'
          ELSE 'inactive'
        END as status
      FROM tb_fornecedor_campanha fc
      INNER JOIN tb_fornecedor f ON f.id = fc.id_fornecedor
      WHERE f.ativo = true
    `;
    const params = [];
    let paramCount = 0;

    if (supplier_id) {
      paramCount++;
      query += ` AND fc.id_fornecedor = $${paramCount}`;
      params.push(supplier_id);
    }

    if (status) {
      paramCount++;
      query += ` AND fc.ativa = $${paramCount}`;
      params.push(status === 'active');
    }

    if (sort) {
      const sortFieldRaw = sort.startsWith('-') ? sort.slice(1) : sort;
      const sortOrder = sort.startsWith('-') ? 'DESC' : 'ASC';
      // Whitelist de campos ordenáveis mapeados para colunas reais
      const sortMap = {
        created_date: 'fc.dt_inicio',
        start_date: 'fc.dt_inicio',
        end_date: 'fc.dt_fim',
        name: 'fc.descricao_campanha',
        min_value: 'fc.valor_meta',
        cashback_percentage: 'fc.percentual_cashback',
        status: 'fc.ativa',
        id: 'fc.id'
      };
      const mapped = sortMap[sortFieldRaw];
      if (mapped) {
        query += ` ORDER BY ${mapped} ${sortOrder}`;
      } else {
        // Fallback seguro
        query += ' ORDER BY fc.dt_inicio DESC NULLS LAST, fc.id DESC';
      }
    } else {
      query += ' ORDER BY fc.dt_inicio DESC NULLS LAST, fc.id DESC';
    }

    const result = await db.query(query, params);

    // Para cada campanha, calcular progresso global com base em pedidos processados
    const processedRows = [];
    for (const row of result.rows) {
      const typeApp = reverseCampaignTypeMap[row.type] || row.type;
      let progress = {
        mode: null,
        current: 0,
        target: 0,
        percent: 0,
        active: false
      };

      try {
        // Try to fetch achieved fields to prefer persisted progress when available
        let achievedValue = null;
        let achievedQuantity = null;
        try {
          const ach = await db.query(
            'SELECT valor_atingido, quantidade_atingida FROM tb_fornecedor_campanha WHERE id = $1',
            [row.id]
          );
          if (ach.rows.length > 0) {
            achievedValue = ach.rows[0]?.valor_atingido != null ? Number(ach.rows[0].valor_atingido) : null;
            achievedQuantity = ach.rows[0]?.quantidade_atingida != null ? Number(ach.rows[0].quantidade_atingida) : null;
          }
        } catch (e) {
          // ignorar se colunas estiverem ausentes; recorrer a somas computadas abaixo
        }
        if (typeApp === 'cashback_value') {
          // Soma do valor dos itens de pedidos do fornecedor após PROCESSANDO, no intervalo da campanha
          let current = null;
          
          // Sempre calcular direto da query (não usar achievedValue que pode estar desatualizado)
          const sumSql = `
            SELECT COALESCE(SUM(pi.valor_total), 0) AS total
            FROM tb_pedido_item pi
            JOIN tb_pedido p ON p.id = pi.id_pedido
            WHERE p.id_fornecedor = $1
              AND p.status IN ('PROCESSANDO','SEPARADO','ENVIADO','ENTREGUE')
              AND ($2::date IS NULL OR p.dt_inc::date >= $2::date)
              AND ($3::date IS NULL OR p.dt_inc::date <= $3::date)
          `;
          const sumRes = await db.query(sumSql, [row.supplier_id, row.start_date, row.end_date]);
          current = Number(sumRes.rows[0]?.total || 0);
          
          const target = Number(row.min_value || 0);
          const percent = target > 0 ? Math.min(100, (current / target) * 100) : 0;
          progress = {
            mode: 'value',
            current,
            target,
            percent,
            active: target > 0 && current >= target
          };
        } else if (typeApp === 'cashback_quantity' || typeApp === 'gift_quantity') {
          // Soma de quantidades do produto alvo em pedidos processados
          let current = null;
          
          // Sempre calcular direto da query (não usar achievedQuantity que pode estar desatualizado)
          const sumSql = `
            SELECT COALESCE(SUM(pi.quantidade), 0) AS qty
            FROM tb_pedido_item pi
            JOIN tb_pedido p ON p.id = pi.id_pedido
            WHERE p.id_fornecedor = $1
              AND p.status IN ('PROCESSANDO','SEPARADO','ENVIADO','ENTREGUE')
              AND pi.id_produto = $2
              AND ($3::date IS NULL OR p.dt_inc::date >= $3::date)
              AND ($4::date IS NULL OR p.dt_inc::date <= $4::date)
          `;
          const prodIdRes = await db.query(sumSql, [row.supplier_id, row.product_id, row.start_date, row.end_date]);
          current = Number(prodIdRes.rows[0]?.qty || 0);
          
          const target = Number(row.min_quantity || 0);
          const percent = target > 0 ? Math.min(100, (current / target) * 100) : 0;
          progress = {
            mode: 'quantity',
            current,
            target,
            percent,
            active: target > 0 && current >= target
          };
        }
      } catch (e) {
        // Em caso de falha no cálculo, mantemos progresso padrão e registramos no objeto
        progress.error = e.message;
      }

      processedRows.push({
        ...row,
        type: typeApp,
        progress
      });
    }

    res.json(processedRows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/campaigns
router.post('/', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    
    const {
      name, supplier_id, type, description, min_value,
      cashback_percentage, product_id, min_quantity,
      gift_description, start_date, end_date, status = 'active', id_conta, image_url
    } = req.body;
    // Garantir que id_conta (accountId) seja sempre preenchido para respeitar NOT NULL
    let accountId = id_conta ?? null;
    if (!accountId && supplier_id) {
      try {
        const supplierRes = await client.query('SELECT id_conta FROM tb_fornecedor WHERE id = $1', [supplier_id]);
        if (supplierRes.rows.length && supplierRes.rows[0].id_conta) {
          accountId = supplierRes.rows[0].id_conta;
        }
      } catch (lookupErr) {
        // Se falhar lookup, continua e deixa erro explícito na inserção
        console.error('Erro ao buscar id_conta do fornecedor:', lookupErr.message);
      }
    }

    if (!accountId) {
      return res.status(400).json({ error: 'Conta associada (id_conta) não encontrada para o fornecedor.' });
    }

    // Inserir campanha
    const campaignResult = await client.query(
      `INSERT INTO tb_fornecedor_campanha (
        descricao_campanha, descricao, id_fornecedor, tipo_campanha, 
        valor_meta, percentual_cashback, quantidade_meta,
        descricao_brinde, foto_url, dt_inicio, dt_fim, ativa, id_conta
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING id`,
      [name, description, supplier_id, campaignTypeMap[type], min_value,
     cashback_percentage, min_quantity, gift_description,
     image_url || null, start_date, end_date, status === 'active', accountId]
    );

    const campaignId = campaignResult.rows[0].id;

    // Inserir produto da campanha se houver
    if (product_id) {
      await client.query(
        `INSERT INTO tb_fornecedor_campanha_produto (
          id_campanha, id_produto, id_conta
        ) VALUES ($1, $2, $3)`,
        [campaignId, product_id, accountId]
      );
    }

    await client.query('COMMIT');

    // Retornar campanha criada
    const result = await client.query(
      `SELECT 
        fc.id,
        fc.descricao_campanha as name,
        fc.id_fornecedor as supplier_id,
        $1 as type,
        fc.descricao as description,
        fc.foto_url as image_url,
        fc.valor_meta as min_value,
        fc.percentual_cashback as cashback_percentage,
        fc.quantidade_meta as min_quantity,
        fc.descricao_brinde as gift_description,
        fc.dt_inicio as start_date,
        fc.dt_fim as end_date,
        CASE 
          WHEN fc.ativa = true THEN 'active'
          ELSE 'inactive'
        END as status
      FROM tb_fornecedor_campanha fc
      WHERE fc.id = $2`,
      [type, campaignId]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

// PUT /api/campaigns/:id
router.put('/:id', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const {
      name, description, min_value,
      cashback_percentage, min_quantity,
      gift_description, image_url, start_date, end_date, status,
      type, product_id
    } = req.body;

    // Validar se está tentando ativar uma campanha expirada
    if (status === 'active' && end_date) {
      const endDateObj = new Date(end_date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      endDateObj.setHours(0, 0, 0, 0);
      
      if (endDateObj < today) {
        await client.query('ROLLBACK');
        return res.status(400).json({ 
          error: 'Não é possível ativar uma campanha com data de término já passada.' 
        });
      }
    }

    // Atualizar campos básicos + tipo (se fornecido)
    const updateSql = `UPDATE tb_fornecedor_campanha SET 
        descricao_campanha = COALESCE($1, descricao_campanha),
        descricao = COALESCE($2, descricao),
        valor_meta = $3,
        percentual_cashback = $4,
        quantidade_meta = $5,
        descricao_brinde = $6,
        foto_url = $7,
        dt_inicio = $8,
        dt_fim = $9,
        ativa = $10,
        tipo_campanha = COALESCE($11, tipo_campanha)
      WHERE id = $12
      RETURNING id, id_fornecedor`;

    const mappedType = type ? campaignTypeMap[type] : null;
    const upd = await client.query(updateSql, [
      name,
      description,
      min_value,
      cashback_percentage,
      min_quantity,
      gift_description,
      image_url || null,
      start_date,
      end_date,
      status === 'active',
      mappedType,
      req.params.id
    ]);

    if (upd.rows.length === 0) {
      await client.query('ROLLBACK');
      client.release();
      return res.status(404).json({ error: 'Campaign not found' });
    }

    const campaignId = req.params.id;

    // Ajustar associação de produto: remover existente e inserir o novo se product_id fornecido
    if (product_id !== undefined) {
      await client.query('DELETE FROM tb_fornecedor_campanha_produto WHERE id_campanha = $1', [campaignId]);
      if (product_id) {
        // recuperar id_conta da campanha
        const accRes = await client.query('SELECT id_conta FROM tb_fornecedor_campanha WHERE id = $1', [campaignId]);
        const accountId = accRes.rows[0]?.id_conta || null;
        await client.query(
          `INSERT INTO tb_fornecedor_campanha_produto (id_campanha, id_produto, id_conta)
           VALUES ($1, $2, $3)`,
          [campaignId, product_id, accountId]
        );
      }
    }

    // Retornar campanha atualizada com tipo traduzido e produto atual
    const result = await client.query(
      `SELECT 
        fc.id,
        fc.descricao_campanha as name,
        fc.id_fornecedor as supplier_id,
        fc.tipo_campanha as type,
        fc.descricao as description,
        fc.foto_url as image_url,
        fc.valor_meta as min_value,
        fc.percentual_cashback as cashback_percentage,
        (
          SELECT fcp.id_produto 
          FROM tb_fornecedor_campanha_produto fcp 
          WHERE fcp.id_campanha = fc.id 
          LIMIT 1
        ) as product_id,
        fc.quantidade_meta as min_quantity,
        fc.descricao_brinde as gift_description,
        fc.dt_inicio as start_date,
        fc.dt_fim as end_date,
        CASE WHEN fc.ativa = true THEN 'active' ELSE 'inactive' END as status
      FROM tb_fornecedor_campanha fc
      WHERE fc.id = $1`,
      [campaignId]
    );

    await client.query('COMMIT');
    const row = result.rows[0];
    row.type = reverseCampaignTypeMap[row.type] || row.type;
    res.json(row);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

// DELETE /api/campaigns/:id
router.delete('/:id', async (req, res) => {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    
    // Remover associações de produtos primeiro
    await client.query(
      'DELETE FROM tb_fornecedor_campanha_produto WHERE id_campanha = $1',
      [req.params.id]
    );
    
    // Remover campanha
    const result = await client.query(
      'DELETE FROM tb_fornecedor_campanha WHERE id = $1 RETURNING id',
      [req.params.id]
    );
    
    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Campaign not found' });
    }
    
    await client.query('COMMIT');
    res.json({ success: true, id: req.params.id });
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

export default router;