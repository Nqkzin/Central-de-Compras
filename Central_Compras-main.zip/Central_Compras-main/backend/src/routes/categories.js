import express from 'express';
import { db } from '../database/database.js';

const router = express.Router();

// GET /api/categories?search=term
router.get('/', async (req, res) => {
  try {
    const { search, limit = 100 } = req.query;
    let query = `SELECT id, nome as name, descricao as description FROM tb_categoria WHERE 1=1`;
    const params = [];
    let paramCount = 0;
    if (search && search.trim() !== '') {
      paramCount++;
      query += ` AND (nome ILIKE $${paramCount} OR descricao ILIKE $${paramCount})`;
      params.push(`%${search.trim()}%`);
    }
    const safeLimit = Number(limit);
    query += ` ORDER BY nome ASC LIMIT ${Number.isFinite(safeLimit) ? Math.min(safeLimit, 500) : 100}`;
    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
