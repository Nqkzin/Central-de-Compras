import { Resend } from 'resend';

/**
 * Envia email com as credenciais de acesso geradas
 * @param {Object} params - Parâmetros do email
 * @param {string} params.to - Email do destinatário
 * @param {string} params.name - Nome do destinatário
 * @param {string} params.email - Email de login (email central)
 * @param {string} params.password - Senha gerada
 * @param {string} params.type - Tipo de usuário ('store' ou 'supplier')
 * @returns {Promise<Object>} Resultado do envio
 */
export async function sendWelcomeEmail({ to, name, email, password, type }) {
  try {
    // Verificar se a API key está configurada
    if (!process.env.RESEND_API_KEY) {
      console.warn('⚠️ RESEND_API_KEY não configurada. Email não será enviado.');
      return { success: false, error: 'API key não configurada' };
    }

    if (!process.env.RESEND_FROM_EMAIL) {
      console.warn('⚠️ RESEND_FROM_EMAIL não configurado. Usando padrão.');
    }

    console.log('🔑 API Key encontrada (primeiros 10 chars):', process.env.RESEND_API_KEY?.substring(0, 10) + '...');
    console.log('📬 Email remetente:', process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev');

    // Inicializar Resend apenas quando a API key estiver disponível
    const resend = new Resend(process.env.RESEND_API_KEY);

    const userTypeName = type === 'store' ? 'Loja' : 'Fornecedor';
    const portalName = 'Central de Compras';

    const { data, error } = await resend.emails.send({
      from: process.env.RESEND_FROM_EMAIL || 'Central de Compras <onboarding@resend.dev>',
      to: [to],
      subject: `Bem-vindo(a) ao ${portalName}!`,
      html: `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Bem-vindo ao ${portalName}</title>
          </head>
          <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f4; padding: 20px;">
              <tr>
                <td align="center">
                  <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    
                    <!-- Header -->
                    <tr>
                      <td style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center;">
                        <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: bold;">
                          ${portalName}
                        </h1>
                        <p style="margin: 10px 0 0 0; color: #e0e7ff; font-size: 14px;">
                          Sistema de Gestão de Compras
                        </p>
                      </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                      <td style="padding: 40px 30px;">
                        <h2 style="margin: 0 0 20px 0; color: #1f2937; font-size: 24px;">
                          Olá, ${name}!
                        </h2>
                        
                        <p style="margin: 0 0 20px 0; color: #4b5563; font-size: 16px; line-height: 1.6;">
                          Seu cadastro como <strong>${userTypeName}</strong> foi realizado com sucesso! 🎉
                        </p>
                        
                        <p style="margin: 0 0 30px 0; color: #4b5563; font-size: 16px; line-height: 1.6;">
                          Abaixo estão suas credenciais de acesso ao sistema:
                        </p>
                        
                        <!-- Credentials Box -->
                        <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border: 2px solid #e5e7eb; border-radius: 8px; margin: 0 0 30px 0;">
                          <tr>
                            <td style="padding: 25px;">
                              <table width="100%" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td style="padding: 8px 0;">
                                    <span style="color: #6b7280; font-size: 14px; display: block; margin-bottom: 5px;">
                                      📧 Email de Acesso:
                                    </span>
                                    <span style="color: #1f2937; font-size: 16px; font-weight: 600; font-family: 'Courier New', monospace;">
                                      ${email}
                                    </span>
                                  </td>
                                </tr>
                                <tr>
                                  <td style="padding: 15px 0 8px 0;">
                                    <span style="color: #6b7280; font-size: 14px; display: block; margin-bottom: 5px;">
                                      🔑 Senha Temporária:
                                    </span>
                                    <span style="color: #1f2937; font-size: 18px; font-weight: 700; font-family: 'Courier New', monospace; background-color: #fef3c7; padding: 8px 12px; border-radius: 4px; display: inline-block;">
                                      ${password}
                                    </span>
                                  </td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                        
                        <!-- Warning Box -->
                        <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fef2f2; border-left: 4px solid #ef4444; border-radius: 4px; margin: 0 0 30px 0;">
                          <tr>
                            <td style="padding: 15px 20px;">
                              <p style="margin: 0; color: #991b1b; font-size: 14px; line-height: 1.6;">
                                <strong>⚠️ Importante:</strong> Por motivos de segurança, você será solicitado a alterar sua senha no primeiro acesso ao sistema.
                              </p>
                            </td>
                          </tr>
                        </table>
                        
                        <p style="margin: 0 0 30px 0; color: #4b5563; font-size: 16px; line-height: 1.6;">
                          <strong>Email de Contato:</strong><br>
                          Este email foi enviado para: <span style="color: #667eea; font-weight: 600;">${to}</span>
                        </p>
                        
                        <!-- CTA Button -->
                        <table width="100%" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" style="padding: 10px 0 20px 0;">
                              <a href="${process.env.FRONTEND_URL || 'http://localhost:3000/login'}" 
                                 style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 6px; font-size: 16px; font-weight: 600; box-shadow: 0 4px 6px rgba(102, 126, 234, 0.3);">
                                Acessar o Sistema
                              </a>
                            </td>
                          </tr>
                        </table>
                        
                        <p style="margin: 20px 0 0 0; color: #6b7280; font-size: 14px; line-height: 1.6;">
                          Se você tiver alguma dúvida, entre em contato com nosso suporte.
                        </p>
                      </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                      <td style="background-color: #f9fafb; padding: 20px 30px; border-top: 1px solid #e5e7eb;">
                        <p style="margin: 0; color: #9ca3af; font-size: 12px; text-align: center; line-height: 1.5;">
                          © ${new Date().getFullYear()} ${portalName}. Todos os direitos reservados.<br>
                          Este é um email automático, por favor não responda.
                        </p>
                      </td>
                    </tr>
                    
                  </table>
                </td>
              </tr>
            </table>
          </body>
        </html>
      `,
    });

    if (error) {
      console.error('❌ Erro retornado pelo Resend:', error);
      return { success: false, error: error.message };
    }

    console.log('✅ Email enviado com sucesso!');
    console.log('   ID do email:', data?.id);
    return { success: true, data };
  } catch (error) {
    console.error('❌ Exceção ao enviar email:', error.message);
    console.error('   Stack:', error.stack);
    return { success: false, error: error.message };
  }
}
