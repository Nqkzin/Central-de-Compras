// tailwind.config.cjs
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx,vue,html}",
  ],
  theme: {
    extend: {
      colors: {
        // ajuste os valores para combinar com seu estilo original
        border: "var(--border, #e5e7eb)",
        input:  "var(--input, #ffffff)",
        ring:   "var(--ring, #6366f1)",
        background: "var(--background, #ffffff)",
        foreground: "var(--foreground, #111827)",

        // exemplos de paleta (adicione as que seu projeto usava)
        primary: {
          DEFAULT: "var(--primary, #2563eb)",
          50: "#eff6ff",
          100: "#dbeafe",
          200: "#bfdbfe",
        },
        // ...adicione outras cores semânticas aqui
      },
      borderRadius: {
        xl: "2rem",
      },
      // outras extensões que você usava
    },
  },
  plugins: [],
};
