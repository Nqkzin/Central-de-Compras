import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/services/apiClient";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, RefreshCw } from "lucide-react";

const toMoney = (value) => {
  if (value === null || value === undefined || value === "") return "0,00";
  const num = Number(value) || 0;
  return num.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

export default function AdminCashback() {
  const queryClient = useQueryClient();
  const [selected, setSelected] = React.useState(null);
  const [realizedValue, setRealizedValue] = React.useState("");

  const { data: pending = [], isLoading, refetch, isFetching } = useQuery({
    queryKey: ["cashback", "pending"],
    queryFn: () => apiClient.entities.Store.cashbackPending(),
    initialData: [],
  });

  const approveMutation = useMutation({
    mutationFn: ({ id, amount }) => apiClient.entities.Store.approveCashback(id, amount != null ? { amount } : {}),
    onSuccess: () => {
      toast.success("Cashback aprovado com sucesso.");
      setSelected(null);
      setRealizedValue("");
      queryClient.invalidateQueries({ queryKey: ["cashback", "pending"] });
      queryClient.invalidateQueries({ queryKey: ["stores", "cashback", "summary"] });
    },
    onError: (error) => {
      toast.error(error?.message || "Erro ao aprovar cashback.");
    },
  });

  const openApproveDialog = (detail) => {
    setSelected(detail);
    setRealizedValue(String(detail.vl_previsto ?? ""));
  };

  const handleConfirmApprove = () => {
    if (!selected) return;
    let amount = realizedValue;
    if (amount === "") amount = null;
    approveMutation.mutate({ id: selected.id, amount: amount != null ? Number(amount) : null });
  };

  const hasPending = pending && pending.length > 0;

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1">Aprovação de Cashback</h1>
            <p className="text-gray-600 text-sm">Revise e aprove os cashbacks previstos das lojas.</p>
          </div>
          <Button variant="outline" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isFetching ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
        </div>

        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-emerald-50 to-green-50 flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              Cashbacks Pendentes
            </CardTitle>
            <Badge variant={hasPending ? "default" : "secondary"}>
              {hasPending ? `${pending.length} pendente(s)` : "Nenhum pendente"}
            </Badge>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex items-center justify-center py-10">
                <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
              </div>
            ) : !hasPending ? (
              <div className="py-12 text-center text-gray-500 text-sm">
                Nenhum cashback pendente de aprovação no momento.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Loja</TableHead>
                      <TableHead>Fornecedor</TableHead>
                      <TableHead>Previsto</TableHead>
                      <TableHead>Realizado</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pending.map((row) => (
                      <TableRow key={row.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="font-medium text-gray-900 text-sm">{row.store_name || `Loja #${row.id_loja}`}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-gray-800">{row.supplier_name || `Fornecedor #${row.id_fornecedor}`}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm font-semibold text-emerald-700">R$ {toMoney(row.vl_previsto)}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-gray-700">R$ {toMoney(row.vl_realizado)}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-xs text-gray-500">
                            {row.dt_inc ? new Date(row.dt_inc).toLocaleString("pt-BR") : "-"}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-emerald-500 text-emerald-700 hover:bg-emerald-50"
                            onClick={() => openApproveDialog(row)}
                          >
                            Aprovar
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {selected && (
        <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Aprovar Cashback</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="text-sm text-gray-700">
                <div><span className="font-semibold">Loja:</span> {selected.store_name || `Loja #${selected.id_loja}`}</div>
                <div><span className="font-semibold">Fornecedor:</span> {selected.supplier_name || `Fornecedor #${selected.id_fornecedor}`}</div>
              </div>
              <div className="grid grid-cols-2 gap-4 items-end">
                <div>
                  <div className="text-xs text-gray-500 mb-1">Valor previsto</div>
                  <div className="text-sm font-semibold text-emerald-700">R$ {toMoney(selected.vl_previsto)}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-1">Valor a efetivar</div>
                  <Input
                    type="number"
                    step="0.01"
                    value={realizedValue}
                    onChange={(e) => setRealizedValue(e.target.value)}
                  />
                  <p className="text-[10px] text-gray-500 mt-1">
                    Deixe igual ao previsto ou ajuste se necessário.
                  </p>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setSelected(null)}
                  disabled={approveMutation.isPending}
                >
                  Cancelar
                </Button>
                <Button
                  type="button"
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={handleConfirmApprove}
                  disabled={approveMutation.isPending}
                >
                  {approveMutation.isPending ? "Aprovando..." : "Aprovar"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
