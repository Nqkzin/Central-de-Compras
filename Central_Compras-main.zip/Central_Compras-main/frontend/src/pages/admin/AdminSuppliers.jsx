
import React, { useState } from "react";
import { toast } from 'sonner';
import { apiClient } from "@/services/apiClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Building2, Edit, Search, Mail, Phone, MapPin, AlertCircle, XCircle, Loader2, Copy, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  formatCNPJ,
  formatCEP,
  formatPhone,
  validateCNPJ,
  validateCEP,
  validatePhone,
  validateEmail,
  capitalizeName,
  validateIE,
  formatIE
} from "@/components/utils/validators";

const STATES = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"];

// Categorias agora dinâmicas via tb_categoria

export default function AdminSuppliers() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [generatedCredentials, setGeneratedCredentials] = useState(null);
  const [categorySearch, setCategorySearch] = useState("");
  const [validationErrors, setValidationErrors] = useState({});
  const [additionalContacts, setAdditionalContacts] = useState([]);
  const [showAdditionalContacts, setShowAdditionalContacts] = useState(false);
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: "",
    fantasy_name: "",
    cnpj: "",
    image_url: "",
    address: "",
    address_number: "",
    neighborhood: "",
    reference: "",
    city: "",
    state: "",
    zip_code: "",
    inscricao_estadual: "",
    site: "",
    contact_name: "",
    contact_position: "",
    contact_email: "",
    contact_phone: "",
    nfe_email: "",
    can_manage_products: true,
    categories: "",
    status: "active"
  });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageInputMode, setImageInputMode] = useState('upload'); // 'upload' ou 'url'

  const { data: suppliers, isLoading } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.list('-created_date'),
    initialData: [],
  });

  // Buscar categorias com filtro de busca
  const { data: categories = [], isLoading: loadingCategories } = useQuery({
    queryKey: ['categories', categorySearch],
    queryFn: () => apiClient.entities.Category.filter({ search: categorySearch }),
    keepPreviousData: true,
  });

  const createSupplierMutation = useMutation({
    mutationFn: async (supplierData) => {
      const supplier = await apiClient.entities.Supplier.create(supplierData);
      const username = supplier.generated_email || supplierData.contact_email;
      const password = supplier.generated_password || null;
      // Contatos adicionais agora são enviados no mesmo POST (additional_contacts)
      return { supplier, username, password };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['suppliers'] });
      if (data.password) {
        setGeneratedCredentials({
          username: data.username,
          password: data.password,
          email: data.supplier.contact_email
        });
      } else {
        toast.info('Fornecedor cadastrado. Usuário já existia para este email (nenhuma nova senha gerada).');
      }
      resetForm();
    },
    onError: (error) => {
      toast.error(`Erro ao cadastrar fornecedor: ${error?.message || 'Verifique os dados e tente novamente.'}`);
    }
  });

  const updateSupplierMutation = useMutation({
    mutationFn: ({ id, data }) => apiClient.entities.Supplier.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['suppliers'] });
      setShowDialog(false);
      resetForm();
      toast.success('Fornecedor atualizado com sucesso.');
    },
    onError: (error) => {
      toast.error(`Erro ao atualizar fornecedor: ${error?.message || 'Tente novamente mais tarde.'}`);
    }
  });

  const resetForm = () => {
    setFormData({
      name: "",
      fantasy_name: "",
      cnpj: "",
      image_url: "",
      address: "",
      address_number: "",
      neighborhood: "",
      reference: "",
      city: "",
      state: "",
      zip_code: "",
      inscricao_estadual: "",
      site: "",
      contact_name: "",
      contact_position: "",
      contact_email: "",
      contact_phone: "",
      nfe_email: "",
      can_manage_products: true,
      categories: "",
      status: "active"
    });
    setEditingSupplier(null);
    setValidationErrors({});
    setAdditionalContacts([]);
    setShowAdditionalContacts(false);
    setUploadingImage(false);
  };

  const addContactField = () => {
    setAdditionalContacts([...additionalContacts, {
      name: "",
      email: "",
      phone: "",
      position: "",
      is_primary: false,
      notes: ""
    }]);
  };

  const removeContactField = (index) => {
    setAdditionalContacts(additionalContacts.filter((_, i) => i !== index));
  };

  const updateContactField = (index, field, value) => {
    const updated = [...additionalContacts];
    
    if (field === 'phone') {
      updated[index][field] = formatPhone(value);
    } else if (field === 'name' || field === 'position') {
      // O outline não especificou capitalização para contatos adicionais,
      // então mantendo atribuição direta conforme outline
      updated[index][field] = value;
    } else {
      updated[index][field] = value;
    }
    
    setAdditionalContacts(updated);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const result = await apiClient.integrations.Core.UploadFile({ file });
      setFormData({...formData, image_url: result.file_url});
    } catch (error) {
      console.error("Error uploading image:", error);
    } finally {
      setUploadingImage(false);
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.name.trim()) {
      errors.name = "Nome do fornecedor é obrigatório";
    }

    if (!validateCNPJ(formData.cnpj)) {
      errors.cnpj = "CNPJ inválido (deve ter 14 dígitos)";
    }

    if (!formData.address?.trim()) {
      errors.address = "Endereço é obrigatório";
    }

    if (!formData.city?.trim()) {
      errors.city = "Cidade é obrigatória";
    }

    if (formData.zip_code && !validateCEP(formData.zip_code)) {
      errors.zip_code = "CEP inválido (deve ter 8 dígitos)";
    }

    if (!formData.state) {
      errors.state = "Estado é obrigatório";
    }

    if (!formData.contact_name.trim()) {
      errors.contact_name = "Nome do contato é obrigatório";
    }

    if (!validateEmail(formData.contact_email)) {
      errors.contact_email = "Email inválido";
    }

    if (formData.contact_phone && !validatePhone(formData.contact_phone)) {
      errors.contact_phone = "Telefone inválido (deve ter 10 ou 11 dígitos)";
    }

    if (formData.nfe_email && !validateEmail(formData.nfe_email)) {
      errors.nfe_email = "Email para notas fiscais inválido";
    }

    if (formData.inscricao_estadual && !validateIE(formData.inscricao_estadual)) {
      errors.inscricao_estadual = "Inscrição Estadual inválida (8 a 13 dígitos)";
    }

    // Validar contatos adicionais
    additionalContacts.forEach((contact, index) => {
      // Apenas validar email se não estiver vazio, ou se nome for fornecido (implicando tentativa de criar contato)
      if (contact.email && !validateEmail(contact.email)) {
        errors[`additional_contact_${index}_email`] = `Email do contato ${index + 1} é inválido`;
      }
      if (contact.phone && !validatePhone(contact.phone)) {
        errors[`additional_contact_${index}_phone`] = `Telefone do contato ${index + 1} é inválido`;
      }
    });

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    const dataToSave = {
      ...formData,
      name: capitalizeName(formData.name),
      fantasy_name: formData.fantasy_name?.trim() || null,
      city: capitalizeName(formData.city),
      address: capitalizeName(formData.address),
      address_number: formData.address_number?.trim() || null,
      neighborhood: capitalizeName(formData.neighborhood || ''),
      reference: formData.reference?.trim() || null,
      contact_name: capitalizeName(formData.contact_name),
      // Garantir que o backend receba o campo correto
      category: formData.categories || null,
    };

    if (editingSupplier) {
      const cleanedAdditional = showAdditionalContacts && additionalContacts.length > 0
        ? additionalContacts
            .filter(c => c && (c.name || c.email || c.phone))
            .map(c => ({
              name: c.name?.trim() || '',
              email: c.email?.trim() || '',
              phone: c.phone?.replace(/\D/g, '') || '',
              position: c.position?.trim() || '',
              notes: c.notes?.trim() || ''
            }))
        : [];

      updateSupplierMutation.mutate({ id: editingSupplier.id, data: { ...dataToSave, additional_contacts: cleanedAdditional } });
    } else {
      // Enviar contatos adicionais junto no POST de criação para garantir persistência atômica
      const cleanedAdditional = showAdditionalContacts && additionalContacts.length > 0
        ? additionalContacts
            .filter(c => c && (c.name || c.email || c.phone))
            .map(c => ({
              name: c.name?.trim() || '',
              email: c.email?.trim() || '',
              phone: c.phone?.replace(/\D/g, '') || '',
              position: c.position?.trim() || '',
              notes: c.notes?.trim() || ''
            }))
        : [];

      createSupplierMutation.mutate({
        ...dataToSave,
        additional_contacts: cleanedAdditional
      });
    }
  };

  const handleEdit = async (supplier) => {
    setEditingSupplier(supplier);
    setFormData({
      ...supplier,
      address_number: supplier.address_number || "",
      neighborhood: supplier.neighborhood || "",
      reference: supplier.reference || "",
      categories: supplier.category ?? "",
    });
    
    // Buscar contatos extras (não responsáveis)
    try {
      const contacts = await apiClient.entities.Contact.filter({ supplier_id: supplier.id });
      const extraContacts = contacts.filter(c => !c.is_primary).map(c => ({
        name: c.name || '',
        email: c.email || '',
        phone: c.phone || '',
        position: c.position || '',
        notes: c.notes || ''
      }));
      
      if (extraContacts.length > 0) {
        setAdditionalContacts(extraContacts);
        setShowAdditionalContacts(true);
      } else {
        setAdditionalContacts([]);
        setShowAdditionalContacts(false);
      }
    } catch (error) {
      console.error('Erro ao buscar contatos:', error);
      setAdditionalContacts([]);
      setShowAdditionalContacts(false);
    }
    
    setShowDialog(true);
  };

  const handleInputChange = (field, value) => {
    let formattedValue = value;

    if (field === 'cnpj') {
      formattedValue = formatCNPJ(value);
    } else if (field === 'zip_code') {
      formattedValue = formatCEP(value);
    } else if (field === 'contact_phone') {
      formattedValue = formatPhone(value);
    } else if (field === 'inscricao_estadual') {
      formattedValue = formatIE(value);
    }

    setFormData({ ...formData, [field]: formattedValue });

    // Limpar erro de validação para este campo enquanto usuário digita
    if (validationErrors[field]) {
      setValidationErrors({ ...validationErrors, [field]: null });
    }
  };

  const handleCategoryChange = (category) => {
    setFormData({ ...formData, categories: category });
  };

  const filteredSuppliers = suppliers.filter(supplier =>
    supplier.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.fantasy_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.cnpj?.includes(searchTerm) ||
    supplier.city?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Gerenciar Fornecedores</h1>
            <p className="text-gray-600">Cadastre e gerencie os fornecedores da central</p>
          </div>
          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                Novo Fornecedor
              </Button>
            </DialogTrigger>
            <DialogContent className="w-full max-w-5xl overflow-y-auto max-h-[88vh]">
              <DialogHeader>
                <DialogTitle>{editingSupplier ? 'Editar Fornecedor' : 'Cadastrar Novo Fornecedor'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-12 gap-4">
                  {/* Left stacked razão social + nome fantasia */}
                  <div className="col-span-8 space-y-4">
                    <div>
                      <Label>Razão Social *</Label>
                      <Input
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Ex: Distribuidora ABC"
                        className={validationErrors.name ? 'border-red-500' : ''}
                      />
                      {validationErrors.name && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.name}</p>
                      )}
                    </div>
                    <div>
                      <Label>Nome Fantasia (opcional)</Label>
                      <Input
                        value={formData.fantasy_name}
                        onChange={(e) => handleInputChange('fantasy_name', e.target.value)}
                        placeholder="Ex: ABC Distribuidora"
                      />
                    </div>
                  </div>

                  {/* Image to the right */}
                  <div className="col-span-4">
                    <Label>Foto do Fornecedor</Label>
                    <div className="space-y-3">
                      {/* Abas para escolher modo */}
                      <div className="flex gap-2 border-b">
                        <button
                          type="button"
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            imageInputMode === 'upload'
                              ? 'text-blue-600 border-b-2 border-blue-600'
                              : 'text-gray-500 hover:text-gray-700'
                          }`}
                          onClick={() => setImageInputMode('upload')}
                        >
                          Upload de Arquivo
                        </button>
                        <button
                          type="button"
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            imageInputMode === 'url'
                              ? 'text-blue-600 border-b-2 border-blue-600'
                              : 'text-gray-500 hover:text-gray-700'
                          }`}
                          onClick={() => setImageInputMode('url')}
                        >
                          URL da Imagem
                        </button>
                      </div>

                      {/* Input baseado no modo selecionado */}
                      {imageInputMode === 'upload' ? (
                        <div className="space-y-2">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            disabled={uploadingImage}
                          />
                          <p className="text-xs text-gray-500">
                            Formatos: JPG, PNG ou WebP. Tamanho recomendado: 400x400px
                          </p>
                          {uploadingImage && (
                            <div className="flex items-center gap-2 text-sm text-blue-600">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              Fazendo upload...
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Input
                            type="url"
                            placeholder="https://exemplo.com/fornecedor.jpg"
                            value={formData.image_url}
                            onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                          />
                          <p className="text-xs text-gray-500">
                            Cole a URL completa da imagem (ex: de um repositório online, CDN, etc.)
                          </p>
                        </div>
                      )}

                      {/* Preview da imagem */}
                      {formData.image_url && !uploadingImage && (
                        <div className="relative inline-block">
                          <img 
                            src={formData.image_url} 
                            alt="Preview" 
                            className="w-24 h-24 object-cover rounded-lg border"
                            onError={(e) => {
                              e.target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100"%3E%3Crect fill="%23ddd" width="100" height="100"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%23999" font-size="14"%3EImagem inválida%3C/text%3E%3C/svg%3E';
                            }}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow"
                            onClick={() => setFormData({...formData, image_url: ""})}
                          >
                            <XCircle className="w-4 h-4 text-red-600" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="col-span-4">
                    <Label>CNPJ *</Label>
                    <Input
                      value={formData.cnpj}
                      onChange={(e) => handleInputChange('cnpj', e.target.value)}
                      placeholder="00.000.000/0000-00"
                      maxLength={18}
                      className={validationErrors.cnpj ? 'border-red-500' : ''}
                    />
                    {validationErrors.cnpj && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.cnpj}</p>
                    )}
                  </div>
                  <div className="col-span-4">
                    <Label>Inscrição Estadual</Label>
                    <Input
                      value={formData.inscricao_estadual}
                      onChange={(e) => handleInputChange('inscricao_estadual', e.target.value)}
                      placeholder="Número da IE (opcional)"
                      className={validationErrors.inscricao_estadual ? 'border-red-500' : ''}
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={13}
                    />
                    {validationErrors.inscricao_estadual && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.inscricao_estadual}</p>
                    )}
                  </div>
                  <div className="col-span-4">
                    <Label>CEP</Label>
                    <Input
                      value={formData.zip_code}
                      onChange={(e) => handleInputChange('zip_code', e.target.value)}
                      placeholder="00000-000"
                      maxLength={9}
                      className={validationErrors.zip_code ? 'border-red-500' : ''}
                    />
                    {validationErrors.zip_code && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.zip_code}</p>
                    )}
                  </div>
                  <div className="col-span-8">
                    <Label>Endereço (Logradouro) *</Label>
                    <Input
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      placeholder="Rua, Avenida..."
                      className={validationErrors.address ? 'border-red-500' : ''}
                    />
                    {validationErrors.address && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.address}</p>
                    )}
                  </div>
                  <div className="col-span-4">
                    <Label>Número</Label>
                    <Input
                      value={formData.address_number}
                      onChange={(e) => handleInputChange('address_number', e.target.value)}
                      placeholder="Ex: 123"
                    />
                  </div>
                  <div className="col-span-4">
                    <Label>Bairro</Label>
                    <Input
                      value={formData.neighborhood}
                      onChange={(e) => handleInputChange('neighborhood', e.target.value)}
                      placeholder="Ex: Centro"
                    />
                  </div>
                  <div className="col-span-6">
                    <Label>Referência</Label>
                    <Input
                      value={formData.reference}
                      onChange={(e) => handleInputChange('reference', e.target.value)}
                      placeholder="Ponto de referência (opcional)"
                    />
                  </div>
                  <div className="col-span-6">
                    <Label>Site</Label>
                    <Input
                      value={formData.site}
                      onChange={(e) => handleInputChange('site', e.target.value)}
                      placeholder="https://www.seusite.com (opcional)"
                    />
                  </div>
                  <div className="col-span-6">
                    <Label>Cidade *</Label>
                    <Input
                      value={formData.city}
                      onChange={(e) => handleInputChange('city', e.target.value)}
                      placeholder="Ex: Rio de Janeiro"
                      className={validationErrors.city ? 'border-red-500' : ''}
                    />
                    {validationErrors.city && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.city}</p>
                    )}
                  </div>
                  <div className="col-span-6">
                    <Label>Estado *</Label>
                    <Select
                      value={formData.state}
                      onValueChange={(value) => handleInputChange('state', value)}
                    >
                      <SelectTrigger className={validationErrors.state ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {STATES.map(state => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {validationErrors.state && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.state}</p>
                    )}
                  </div>
                </div>

                <div className="border-t pt-4 grid grid-cols-12 gap-4">
                  <h3 className="font-semibold mb-3 col-span-12">Contato Principal</h3>
                  <div className="col-span-12 grid grid-cols-12 gap-4">
                    <div className="col-span-4">
                      <Label>Nome Completo *</Label>
                      <Input
                        value={formData.contact_name}
                        onChange={(e) => handleInputChange('contact_name', e.target.value)}
                        placeholder="Ex: Maria Santos"
                        className={validationErrors.contact_name ? 'border-red-500' : ''}
                      />
                      {validationErrors.contact_name && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.contact_name}</p>
                      )}
                    </div>
                    <div className="col-span-4">
                      <Label>Cargo</Label>
                      <Input
                        value={formData.contact_position}
                        onChange={(e) => handleInputChange('contact_position', e.target.value)}
                        placeholder="Ex: Gerente Comercial"
                      />
                    </div>
                    <div className="col-span-4">
                      <Label>Telefone</Label>
                      <Input
                        value={formData.contact_phone}
                        onChange={(e) => handleInputChange('contact_phone', e.target.value)}
                        placeholder="(00) 00000-0000"
                        maxLength={15}
                        className={validationErrors.contact_phone ? 'border-red-500' : ''}
                      />
                      {validationErrors.contact_phone && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.contact_phone}</p>
                      )}
                    </div>
                    <div className="col-span-4">
                      <Label>Email *</Label>
                      <Input
                        type="email"
                        value={formData.contact_email}
                        onChange={(e) => handleInputChange('contact_email', e.target.value)}
                        placeholder="email@exemplo.com"
                        className={validationErrors.contact_email ? 'border-red-500' : ''}
                      />
                      {validationErrors.contact_email && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.contact_email}</p>
                      )}
                    </div>
                    <div className="col-span-4">
                      <Label>Email para Notas Fiscais</Label>
                      <Input
                        type="email"
                        value={formData.nfe_email}
                        onChange={(e) => handleInputChange('nfe_email', e.target.value)}
                        placeholder="nfe@exemplo.com (opcional)"
                        className={validationErrors.nfe_email ? 'border-red-500' : ''}
                      />
                      <p className="text-xs text-gray-500 mt-1">Email onde serão enviadas as notas fiscais</p>
                      {validationErrors.nfe_email && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.nfe_email}</p>
                      )}
                    </div>
                    <div className="col-span-4 space-y-1">
                      <Label>Categoria Principal</Label>
                      <Select value={formData.categories} onValueChange={handleCategoryChange}>
                        <SelectTrigger>
                          <SelectValue placeholder={loadingCategories ? 'Carregando...' : 'Selecione'} />
                        </SelectTrigger>
                        <SelectContent className="p-0">
                          <div className="p-2 border-b bg-white sticky top-0">
                            <Input
                              autoFocus
                              placeholder="Buscar categoria..."
                              value={categorySearch}
                              onChange={(e) => setCategorySearch(e.target.value)}
                              className="h-8 text-xs"
                            />
                          </div>
                          {loadingCategories && (
                            <div className="px-2 py-2 text-xs text-gray-500">Carregando...</div>
                          )}
                          {!loadingCategories && categories.length === 0 && (
                            <div className="px-2 py-2 text-xs text-gray-500">Nenhuma categoria encontrada</div>
                          )}
                          {categories.map(cat => (
                            <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold">Contatos Adicionais</h3>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="show_additional"
                        checked={showAdditionalContacts}
                        onChange={(e) => {
                          setShowAdditionalContacts(e.target.checked);
                          if (!e.target.checked) {
                            setAdditionalContacts([]); // Limpar contatos se checkbox for desmarcado
                            // Também limpar quaisquer erros de validação relacionados
                            const newValidationErrors = {...validationErrors};
                            Object.keys(newValidationErrors).forEach(key => {
                              if (key.startsWith('additional_contact_')) {
                                delete newValidationErrors[key];
                              }
                            });
                            setValidationErrors(newValidationErrors);
                          }
                        }}
                        className="w-4 h-4 text-green-600 rounded focus:ring-green-500"
                      />
                      <Label htmlFor="show_additional" className="cursor-pointer text-sm">
                        Adicionar mais contatos
                      </Label>
                    </div>
                  </div>

                  {showAdditionalContacts && (
                    <div className="space-y-4">
                      {additionalContacts.map((contact, index) => (
                        <div key={index} className="border rounded-lg p-4 bg-gray-50 relative">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeContactField(index)}
                            className="absolute top-2 right-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="col-span-2">
                              <Label>Nome</Label>
                              <Input
                                value={contact.name}
                                onChange={(e) => updateContactField(index, 'name', e.target.value)}
                                placeholder="Nome do contato"
                              />
                            </div>
                            <div>
                              <Label>Email</Label>
                              <Input
                                type="email"
                                value={contact.email}
                                onChange={(e) => updateContactField(index, 'email', e.target.value)}
                                placeholder="email@exemplo.com"
                                className={validationErrors[`additional_contact_${index}_email`] ? 'border-red-500' : ''}
                              />
                              {validationErrors[`additional_contact_${index}_email`] && (
                                <p className="text-xs text-red-500 mt-1">{validationErrors[`additional_contact_${index}_email`]}</p>
                              )}
                            </div>
                            <div>
                              <Label>Telefone</Label>
                              <Input
                                value={contact.phone}
                                onChange={(e) => updateContactField(index, 'phone', e.target.value)}
                                placeholder="(00) 00000-0000"
                                maxLength={15}
                                className={validationErrors[`additional_contact_${index}_phone`] ? 'border-red-500' : ''}
                              />
                              {validationErrors[`additional_contact_${index}_phone`] && (
                                <p className="text-xs text-red-500 mt-1">{validationErrors[`additional_contact_${index}_phone`]}</p>
                              )}
                            </div>
                            <div className="col-span-2">
                              <Label>Cargo</Label>
                              <Input
                                value={contact.position}
                                onChange={(e) => updateContactField(index, 'position', e.target.value)}
                                placeholder="Ex: Gerente Comercial"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      <Button
                        type="button"
                        variant="outline"
                        onClick={addContactField}
                        className="w-full border-dashed"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Adicionar Outro Contato
                      </Button>
                    </div>
                  )}
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-3">Permissões e Status</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                    <div className="space-y-3">
                      <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <input
                          type="checkbox"
                          id="can_manage_products"
                          checked={formData.can_manage_products}
                          onChange={(e) => setFormData({...formData, can_manage_products: e.target.checked})}
                          className="w-4 h-4 text-green-600 rounded focus:ring-green-500"
                        />
                        <Label htmlFor="can_manage_products" className="cursor-pointer flex-1">
                          <div className="font-medium">Permitir cadastro e edição de produtos</div>
                          <p className="text-xs text-gray-500 mt-1">
                            Se desmarcado, o fornecedor poderá apenas visualizar seus produtos
                          </p>
                        </Label>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <Label>Status do Fornecedor</Label>
                        <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                          <SelectTrigger>
                            <span>{formData.status === 'active' ? 'Ativo' : 'Inativo'}</span>
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Ativo</SelectItem>
                            <SelectItem value="inactive">Inativo</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-gray-500 mt-1">
                          Fornecedores inativos não podem receber novos pedidos
                        </p>
                      </div>
                    </div>
                  </div>
                </div>


                {Object.keys(validationErrors).length > 0 && (
                  <Alert className="bg-red-50 border-red-200">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      Por favor, corrija os erros acima antes de continuar.
                    </AlertDescription>
                  </Alert>
                )}

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-green-600 to-emerald-600"
                    disabled={createSupplierMutation.isPending || updateSupplierMutation.isPending}
                  >
                    {(createSupplierMutation.isPending || updateSupplierMutation.isPending)
                      ? 'Salvando...'
                      : editingSupplier ? 'Salvar Alterações' : 'Cadastrar Fornecedor'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {generatedCredentials && (
          <Alert className="mb-6 bg-green-50 border-green-200">
            <AlertDescription>
              <div className="font-semibold mb-2">✅ Fornecedor cadastrado com sucesso!</div>
              <div className="text-sm">
                <p className="mb-1"><strong>Credenciais geradas:</strong></p>
                <div className="flex items-center gap-2 mb-2">
                  <p>• Usuário: <span className="font-mono bg-white px-2 py-1 rounded">{generatedCredentials.username}</span></p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0"
                    onClick={() => {
                      navigator.clipboard.writeText(generatedCredentials.username);
                      toast.success('Usuário copiado!');
                    }}
                    title="Copiar usuário"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <p>• Senha: <span className="font-mono bg-white px-2 py-1 rounded">{generatedCredentials.password}</span></p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0"
                    onClick={() => {
                      navigator.clipboard.writeText(generatedCredentials.password);
                      toast.success('Senha copiada!');
                    }}
                    title="Copiar senha"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <p className="mt-2 text-blue-700 flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  📧 Um email com as credenciais foi enviado para o contato.
                </p>
                <p className="mt-2 text-amber-700">⚠️ Anote estas credenciais! Elas não serão exibidas novamente.</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="mt-3"
                onClick={() => setGeneratedCredentials(null)}
              >
                Entendi
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-green-50 to-emerald-50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                Fornecedores Cadastrados ({filteredSuppliers.length})
              </CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar fornecedores..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fornecedor</TableHead>
                    <TableHead>CNPJ</TableHead>
                    <TableHead>Localização</TableHead>
                    <TableHead>Categorias</TableHead>
                    <TableHead>Contato</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
                      </TableCell>
                    </TableRow>
                  ) : filteredSuppliers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-12 text-gray-500">
                        <Building2 className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Nenhum fornecedor cadastrado ainda</p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredSuppliers.map((supplier) => (
                      <TableRow key={supplier.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {supplier.image_url && (
                              <img src={supplier.image_url} alt={supplier.name} className="w-8 h-8 rounded-full object-cover border" />
                            )}
                            <div className="font-medium text-gray-900">{supplier.name}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-gray-600">{formatCNPJ(supplier.cnpj)}</span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <MapPin className="w-3 h-3" />
                            {supplier.city}, {supplier.state}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            {supplier.category || 'Sem categoria'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium text-gray-900">{supplier.contact_name}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <Mail className="w-3 h-3" />
                            {supplier.contact_email}
                          </div>
                        </TableCell>
                        <TableCell>
                          {supplier.contact_phone ? (
                            <div className="flex items-center gap-1 text-sm text-gray-600">
                              <Phone className="w-3 h-3" />
                              {formatPhone(supplier.contact_phone)}
                            </div>
                          ) : (
                            <span className="text-sm text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant={supplier.status === 'active' ? 'default' : 'secondary'}>
                            {supplier.status === 'active' ? 'Ativo' : 'Inativo'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(supplier)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
