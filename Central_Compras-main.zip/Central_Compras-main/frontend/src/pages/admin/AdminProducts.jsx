import React, { useState } from "react";
import { toast } from 'sonner';
import { apiClient } from "@/services/apiClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Package, Edit, Search, Building2, Tag, Loader2, XCircle, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import AIDescriptionHelper from "@/components/AIDescriptionHelper";
import { validateEAN13, formatEAN13, capitalizeName } from "@/components/utils/validators";

// Categorias agora vêm do backend (tb_categoria)

export default function AdminProducts() {
  // Safe currency formatter to avoid crashing when price is string/null
  const toMoney = (value) => {
    if (value === null || value === undefined || value === "") return "0,00";
    let num;
    if (typeof value === "string") {
      const raw = value.toString().trim();
      if (raw.includes(",")) {
        // Brazilian-style string: treat comma as decimal separator and dots as thousands
        const normalized = raw.replace(/\./g, "").replace(",", ".");
        num = Number(normalized);
      } else {
        // Dot is decimal separator already (e.g., "10.0000")
        num = Number(raw);
      }
    } else {
      num = Number(value);
    }
    if (!Number.isFinite(num)) return "0,00";
    return num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };
  const [showDialog, setShowDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [categorySearch, setCategorySearch] = useState("");
  const [deleteTarget, setDeleteTarget] = useState(null);
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    code: "",
    gtin: "",
    internal_code: "",
    codigo_referencia: "",
    category: "",
    supplier_id: "",
    price: 0,
    promotional_price: null,
    unit: "UN",
    stock_quantity: 0,
    image_url: "",
    status: "active"
  });
  const [uploadingImage, setUploadingImage] = useState(false);

  const { data: products, isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => apiClient.entities.Product.list('-created_date'),
    initialData: [],
    onError: (error) => {
      toast.error(`Erro ao carregar produtos: ${error?.message || 'Falha ao consultar a API.'}`);
    }
  });

  // Buscar categorias com filtro de busca (query separada)
  const { data: categories = [], isLoading: loadingCategories } = useQuery({
    queryKey: ['categories', categorySearch],
    queryFn: () => apiClient.entities.Category.filter({ search: categorySearch }),
    keepPreviousData: true,
  });

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.list(),
    initialData: [],
  });

  const createProductMutation = useMutation({
    mutationFn: (productData) => apiClient.entities.Product.create(productData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      setShowDialog(false);
      resetForm();
      toast.success('Produto cadastrado com sucesso.');
    },
    onError: (error) => {
      toast.error(`Erro ao cadastrar produto: ${error?.message || 'Verifique os dados (fornecedor, categoria, preço) e tente novamente.'}`);
    }
  });

  const updateProductMutation = useMutation({
    mutationFn: ({ id, data }) => apiClient.entities.Product.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      setShowDialog(false);
      resetForm();
      toast.success('Produto atualizado com sucesso.');
    },
    onError: (error) => {
      toast.error(`Erro ao atualizar produto: ${error?.message || 'Tente novamente mais tarde.'}`);
    }
  });

  const deleteProductMutation = useMutation({
    mutationFn: (id) => apiClient.entities.Product.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast.success('Produto excluído com sucesso.');
    },
    onError: (error) => {
      toast.error(`Não foi possível excluir: ${error?.message || 'Verifique vínculos e tente novamente.'}`);
    }
  });

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      code: "",
      gtin: "",
      internal_code: "",
      codigo_referencia: "",
      category: "",
      supplier_id: "",
      price: 0,
      promotional_price: null,
      unit: "UN",
      stock_quantity: 0,
      image_url: "",
      status: "active"
    });
    setEditingProduct(null);
    setUploadingImage(false);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const result = await apiClient.integrations.Core.UploadFile({ file });
      setFormData({...formData, image_url: result.file_url});
    } catch (error) {
      console.error("Error uploading image:", error);
  toast.error("Erro ao fazer upload da imagem. Tente novamente.");
    } finally {
      setUploadingImage(false);
      e.target.value = null;
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validação do GTIN (se fornecido)
    if (formData.gtin && !validateEAN13(formData.gtin)) {
      toast.error('GTIN deve ter exatamente 13 números');
      return;
    }
    // Validação do código interno (se fornecido)
    if (formData.internal_code) {
      const cleaned = String(formData.internal_code).replace(/\D/g, '');
      if (cleaned.length !== 8) {
        toast.error('Código interno deve ter exatamente 8 números');
        return;
      }
    }
    // Validação do preço promocional
    if (formData.promotional_price) {
      const promoPrice = Number(formData.promotional_price);
      const normalPrice = Number(formData.price);
      if (promoPrice >= normalPrice) {
        toast.error('Preço promocional deve ser menor que o preço normal');
        return;
      }
    }

    const payload = {
      ...formData,
      name: capitalizeName(formData.name),
      description: formData.description ? capitalizeName(formData.description) : '',
      gtin: formData.gtin || undefined,
      internal_code: formData.internal_code || undefined,
      codigo_referencia: formData.codigo_referencia || undefined,
      supplier_id: formData.supplier_id ? Number(formData.supplier_id) : null,
      price: Number(formData.price) || 0,
      promotional_price: formData.promotional_price ? Number(formData.promotional_price) : null,
      stock_quantity: Number(formData.stock_quantity) || 0,
    };

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data: payload });
    } else {
      createProductMutation.mutate(payload);
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      ...product,
      // map new fields
      gtin: product.gtin || '',
      internal_code: product.internal_code || product.code || '',
      codigo_referencia: product.codigo_referencia || '',
      // Ensure numeric for controlled number inputs
      price: Number(product.price) || 0,
      promotional_price: product.promotional_price ? Number(product.promotional_price) : null,
      stock_quantity: Number(product.stock_quantity) || 0,
      // Ensure Select uses string value for supplier id
      supplier_id: product.supplier_id != null ? String(product.supplier_id) : "",
    });
    setShowDialog(true);
  };

  const getSupplierName = (supplierId) => {
    const supplier = suppliers.find(s => String(s.id) === String(supplierId));
    return supplier?.name || 'N/A';
  };

  const handleDelete = (product) => {
    setDeleteTarget(product);
  };

  const filteredProducts = (products || []).filter(product => {
    const codeToSearch = product.gtin || product.internal_code || product.code || '';
    const matchesSearch =
      product.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      codeToSearch.includes(searchTerm);
    const matchesCategory = filterCategory === "all" || product.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Gerenciar Produtos</h1>
            <p className="text-gray-600">Cadastre e gerencie os produtos dos fornecedores</p>
          </div>
          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                onClick={() => {
                  // Abrir como novo sempre limpa qualquer produto em edição antes de abrir o diálogo
                  if (editingProduct) {
                    resetForm();
                  }
                }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Novo Produto
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProduct ? 'Editar Produto' : 'Cadastrar Novo Produto'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label>Nome do Produto *</Label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      required
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Foto do Produto</Label>
                    <div className="space-y-2">
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        disabled={uploadingImage}
                      />
                      <p className="text-xs text-gray-500">
                        Formatos: JPG, PNG ou WebP. Tamanho recomendado: 800x800px
                      </p>
                      {uploadingImage && (
                        <div className="flex items-center gap-2 text-sm text-blue-600">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Fazendo upload...
                        </div>
                      )}
                      {formData.image_url && !uploadingImage && (
                        <div className="relative inline-block">
                          <img
                            src={formData.image_url}
                            alt="Preview"
                            className="w-32 h-32 object-cover rounded-lg border"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow"
                            onClick={() => setFormData({...formData, image_url: ""})}
                          >
                            <XCircle className="w-4 h-4 text-red-600" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label>GTIN (EAN-13)</Label>
                    <Input
                      value={formData.gtin}
                      onChange={(e) => setFormData({...formData, gtin: formatEAN13(e.target.value)})}
                      placeholder="7891234567890"
                      maxLength={13}
                    />
                    <p className="text-xs text-gray-500 mt-1">13 dígitos numéricos (opcional)</p>
                  </div>
                  <div>
                    <Label>Código Interno (8 dígitos)</Label>
                    <Input
                      value={formData.internal_code}
                      onChange={(e) => setFormData({...formData, internal_code: e.target.value.replace(/\D/g,'')})}
                      placeholder="00000001"
                      maxLength={8}
                    />
                    <p className="text-xs text-gray-500 mt-1">8 dígitos numéricos (opcional)</p>
                  </div>
                  <div>
                    <Label>Código Referência</Label>
                    <Input
                      value={formData.codigo_referencia}
                      onChange={(e) => setFormData({...formData, codigo_referencia: e.target.value.replace(/\D/g, '')})}
                      placeholder="Código referência (opcional)"
                      maxLength={10}
                    />
                    <p className="text-xs text-gray-500 mt-1">Apenas números, máximo 10 dígitos (opcional)</p>
                  </div>
                  <div>
                    <Label>Fornecedor *</Label>
                    <Select 
                      value={String(formData.supplier_id || "")} 
                      onValueChange={(value) => setFormData({...formData, supplier_id: value})} 
                      required
                    >
                      <SelectTrigger>
                        <span className="truncate text-sm text-gray-700">
                          {formData.supplier_id
                            ? (suppliers.find(s => String(s.id) === String(formData.supplier_id))?.name || 'Selecione')
                            : 'Selecione'}
                        </span>
                      </SelectTrigger>
                      <SelectContent>
                        {suppliers
                          .filter(s => (s.status ?? 'active') === 'active')
                          .map(supplier => (
                          <SelectItem key={supplier.id} value={String(supplier.id)}>{supplier.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Categoria *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={loadingCategories ? 'Carregando...' : 'Selecione'} />
                      </SelectTrigger>
                      <SelectContent className="p-0">
                        <div className="p-2 border-b bg-white sticky top-0">
                          <Input
                            autoFocus
                            placeholder="Buscar categoria..."
                            value={categorySearch}
                            onChange={(e) => setCategorySearch(e.target.value)}
                            className="h-8 text-xs"
                          />
                        </div>
                        {loadingCategories && (
                          <div className="px-2 py-2 text-xs text-gray-500">Carregando...</div>
                        )}
                        {!loadingCategories && categories.length === 0 && (
                          <div className="px-2 py-2 text-xs text-gray-500">Nenhuma categoria encontrada</div>
                        )}
                        {categories.map(cat => (
                          <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Unidade</Label>
                    <Select 
                      value={formData.unit} 
                      onValueChange={(value) => setFormData({...formData, unit: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UN">Unidade (UN)</SelectItem>
                        <SelectItem value="CX">Caixa (CX)</SelectItem>
                        <SelectItem value="KG">Quilograma (KG)</SelectItem>
                        <SelectItem value="LT">Litro (LT)</SelectItem>
                        <SelectItem value="MT">Metro (MT)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Preço Unitário *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})}
                      required
                    />
                  </div>
                  <div>
                    <Label>Preço Promocional</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.promotional_price || ''}
                      onChange={(e) => setFormData({...formData, promotional_price: e.target.value ? parseFloat(e.target.value) : null})}
                      placeholder="Opcional"
                    />
                    <p className="text-xs text-gray-500 mt-1">Deixe vazio para usar o preço normal</p>
                  </div>
                  <div>
                    <Label>Quantidade em Estoque</Label>
                    <Input
                      type="number"
                      value={formData.stock_quantity}
                      onChange={(e) => setFormData({...formData, stock_quantity: parseInt(e.target.value)})}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Descrição</Label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      rows={3}
                      placeholder="Descreva o produto..."
                    />
                    <div className="mt-2">
                      <AIDescriptionHelper
                        productName={formData.name}
                        type="product"
                        onSuggestionReceived={(description) => {
                          setFormData({...formData, description: description});
                        }}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancelar
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-gradient-to-r from-purple-600 to-pink-600"
                    disabled={createProductMutation.isPending || updateProductMutation.isPending}
                  >
                    {(createProductMutation.isPending || updateProductMutation.isPending)
                      ? 'Salvando...'
                      : editingProduct ? 'Salvar Alterações' : 'Cadastrar Produto'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-pink-50">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Produtos Cadastrados ({filteredProducts.length})
              </CardTitle>
              <div className="flex gap-3">
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Buscar produtos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-48">
                    <span className="text-sm truncate">
                      {filterCategory === 'all' ? 'Todas as Categorias' : (filterCategory || 'Todas as Categorias')}
                    </span>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as Categorias</SelectItem>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Produto</TableHead>
                    <TableHead>GTIN</TableHead>
                    <TableHead>Código Interno</TableHead>
                    <TableHead>Fornecedor</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Preço</TableHead>
                    <TableHead>Estoque</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
                      </TableCell>
                    </TableRow>
                  ) : filteredProducts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-12 text-gray-500">
                        <Package className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Nenhum produto cadastrado ainda</p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredProducts.map((product) => (
                      <TableRow key={product.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {product.image_url && (
                                <img
                                  src={product.image_url}
                                  alt={product.name}
                                  className="w-10 h-10 object-cover rounded-md"
                                />
                            )}
                            <div>
                              <div className="font-medium text-gray-900">{product.name}</div>
                              {product.description && (
                                <div className="text-xs text-gray-500 mt-1 truncate max-w-[200px]">
                                  {product.description}
                                </div>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-gray-600">{product.gtin || '-'}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-gray-600">{product.internal_code || product.code || '-'}</span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm text-gray-900">
                            <Building2 className="w-3 h-3 text-gray-400" />
                            {getSupplierName(product.supplier_id)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            <Tag className="w-3 h-3 mr-1" />
                            {product.category || 'Sem categoria'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {product.promotional_price && Number(product.promotional_price) > 0 ? (
                            <div>
                              <div className="flex items-center gap-1 mb-1">
                                <Badge variant="secondary" className="bg-green-100 text-green-700 text-[10px] px-1.5 py-0 h-4">
                                  PROMOÇÃO
                                </Badge>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-400 line-through">R$ {toMoney(product.price)}</span>
                                <span className="font-semibold text-green-600">R$ {toMoney(product.promotional_price)}</span>
                              </div>
                              <div className="text-xs text-gray-500">por {product.unit}</div>
                            </div>
                          ) : (
                            <div>
                              <div className="font-semibold text-gray-900">
                                R$ {toMoney(product.price)}
                              </div>
                              <div className="text-xs text-gray-500">
                                por {product.unit}
                              </div>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant={product.stock_quantity > 0 ? "default" : "secondary"}>
                            {product.stock_quantity || 0} {product.unit}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(product)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            onClick={() => handleDelete(product)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
      {deleteTarget && (
        <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Confirmar exclusão do produto</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <p className="text-sm text-gray-700">
                Tem certeza que deseja excluir o produto
                {" "}
                <span className="font-semibold">{deleteTarget.name}</span>
                ? Esta ação não pode ser desfeita.
              </p>
              <p className="text-xs text-gray-500">
                Código: {deleteTarget.gtin || deleteTarget.internal_code || deleteTarget.code || deleteTarget.id}
              </p>
              <div className="flex justify-end gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDeleteTarget(null)}
                  disabled={deleteProductMutation.isPending}
                >
                  Cancelar
                </Button>
                <Button
                  type="button"
                  className="bg-red-600 hover:bg-red-700"
                  onClick={() => {
                    if (!deleteTarget) return;
                    deleteProductMutation.mutate(deleteTarget.id, {
                      onSuccess: () => setDeleteTarget(null),
                    });
                  }}
                  disabled={deleteProductMutation.isPending}
                >
                  {deleteProductMutation.isPending ? 'Excluindo...' : 'Excluir'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}