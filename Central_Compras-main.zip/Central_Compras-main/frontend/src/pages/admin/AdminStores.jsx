import React, { useState } from "react";
import { apiClient } from "@/services/apiClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from 'sonner';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Store, Edit, Search, Mail, Phone, MapPin, AlertCircle, Copy, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  formatCNPJ,
  formatCEP,
  formatPhone,
  validateCNPJ,
  validateCEP,
  validatePhone,
  validateEmail,
  capitalizeName,
  validateIE,
  formatIE
} from "@/components/utils/validators";

const STATES = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"];

export default function AdminStores() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingStore, setEditingStore] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [generatedCredentials, setGeneratedCredentials] = useState(null);
  const [validationErrors, setValidationErrors] = useState({});
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: "", // razao_social
    fantasy_name: "", // nome_fantasia opcional
    cnpj: "",
    address: "",
    address_number: "",
    neighborhood: "",
    reference: "",
    city: "",
    state: "",
    zip_code: "",
    inscricao_estadual: "",
    site: "",
    termo_aceito: "", // texto do termo aceito
    accepted_terms: false, // controle UI
    responsible_name: "",
    responsible_position: "",
    responsible_email: "",
    responsible_phone: "",
    status: "active"
  });

  const { data: stores, isLoading } = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiClient.entities.Store.list('-created_date'),
    initialData: [],
  });

  const createStoreMutation = useMutation({
    mutationFn: async (storeData) => {
      const store = await apiClient.entities.Store.create(storeData);
      const username = store.generated_email || storeData.responsible_email;
      const password = store.generated_password || null; // se já existia usuário, backend não retorna senha
      return { store, username, password };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['stores'] });
      if (data.password) {
        setGeneratedCredentials({
          username: data.username,
          password: data.password,
          email: data.store.responsible_email
        });
      } else {
        toast.info('Loja cadastrada. Usuário já existia para este email (nenhuma nova senha gerada).');
      }
      // Define a nova loja como ativa para facilitar criação de pedidos
      if (data?.store?.id) {
        localStorage.setItem('active_store_id', String(data.store.id));
        toast.success(`Loja ativa definida: ${data.store.name}`);
      }
      resetForm();
      toast.success('Loja cadastrada com sucesso.');
    },
    onError: (error) => {
      toast.error(`Erro ao cadastrar loja: ${error?.message || 'Verifique os dados e tente novamente.'}`);
    }
  });

  const updateStoreMutation = useMutation({
    mutationFn: ({ id, data }) => apiClient.entities.Store.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stores'] });
      setShowDialog(false);
      resetForm();
      toast.success('Loja atualizada com sucesso.');
    },
    onError: (error) => {
      toast.error(`Erro ao atualizar loja: ${error?.message || 'Tente novamente mais tarde.'}`);
    }
  });

  const resetForm = () => {
    setFormData({
      name: "",
      fantasy_name: "",
      cnpj: "",
      address: "",
      address_number: "",
      neighborhood: "",
      reference: "",
      city: "",
      state: "",
      zip_code: "",
      inscricao_estadual: "",
      site: "",
      termo_aceito: "",
      accepted_terms: false,
      responsible_name: "",
      responsible_position: "",
      responsible_email: "",
      responsible_phone: "",
      status: "active"
    });
    setEditingStore(null);
    setValidationErrors({});
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.name.trim()) {
      errors.name = "Razão Social é obrigatória";
    }
    // Termo de aceite obrigatório para criação
    if (!editingStore && !formData.accepted_terms) {
      errors.termo_aceito = "É necessário aceitar o termo de LGPD.";
    }


    if (!validateCNPJ(formData.cnpj)) {
      errors.cnpj = "CNPJ inválido (deve ter 14 dígitos)";
    }

    if (!formData.address?.trim()) {
      errors.address = "Endereço é obrigatório";
    }

    if (!formData.city?.trim()) {
      errors.city = "Cidade é obrigatória";
    }

    if (formData.zip_code && !validateCEP(formData.zip_code)) {
      errors.zip_code = "CEP inválido (deve ter 8 dígitos)";
    }

    if (!formData.state) {
      errors.state = "Estado é obrigatório";
    }

    if (!formData.responsible_name.trim()) {
      errors.responsible_name = "Nome do responsável é obrigatório";
    }

    if (!validateEmail(formData.responsible_email)) {
      errors.responsible_email = "Email inválido";
    }

    if (formData.responsible_phone && !validatePhone(formData.responsible_phone)) {
      errors.responsible_phone = "Telefone inválido (deve ter 10 ou 11 dígitos)";
    }

    if (formData.inscricao_estadual && !validateIE(formData.inscricao_estadual)) {
      errors.inscricao_estadual = "Inscrição Estadual inválida (8 a 13 dígitos)";
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    const dataToSave = {
      ...formData,
      name: capitalizeName(formData.name),
      fantasy_name: formData.fantasy_name?.trim() || null,
      inscricao_estadual: formData.inscricao_estadual?.trim() || null,
      site: formData.site?.trim() || null,
      // enviar timestamp ISO compatível com timestamptz
      termo_aceito: formData.accepted_terms ? new Date().toISOString() : null,
      city: capitalizeName(formData.city),
      address: capitalizeName(formData.address),
      address_number: formData.address_number?.trim() || null,
      neighborhood: capitalizeName(formData.neighborhood || ''),
      reference: formData.reference?.trim() || null,
      responsible_name: capitalizeName(formData.responsible_name),
    };

    if (editingStore) {
      // Send full payload; backend handles upserts for address/contact
      updateStoreMutation.mutate({ id: editingStore.id, data: dataToSave });
    } else {
      createStoreMutation.mutate(dataToSave);
    }
  };

  const handleEdit = (store) => {
    setEditingStore(store);
    // Map store object into formData ensuring we keep only known fields
    setFormData({
      name: store.name || '',
      fantasy_name: store.fantasy_name || '',
      cnpj: formatCNPJ(store.cnpj || ''),
      address: store.address || '',
      address_number: store.address_number || '',
      neighborhood: store.neighborhood || '',
      reference: store.reference || '',
      city: store.city || '',
      state: store.state || '',
      zip_code: formatCEP(store.zip_code || ''),
      inscricao_estadual: store.inscricao_estadual || '',
      site: store.site || '',
      termo_aceito: store.termo_aceito || '',
      accepted_terms: !!store.termo_aceito,
      responsible_name: store.responsible_name || '',
      responsible_position: store.responsible_position || '',
      responsible_email: store.responsible_email || '',
      responsible_phone: store.responsible_phone || '',
      status: store.status || 'active'
    });
    setShowDialog(true);
  };

  const handleInputChange = (field, value) => {
    let formattedValue = value;

    if (field === 'cnpj') {
      formattedValue = formatCNPJ(value);
    } else if (field === 'zip_code') {
      formattedValue = formatCEP(value);
    } else if (field === 'responsible_phone') {
      formattedValue = formatPhone(value);
    } else if (field === 'inscricao_estadual') {
      formattedValue = formatIE(value);
    }

    setFormData({ ...formData, [field]: formattedValue });

    // Clear error when user starts typing
    if (validationErrors[field]) {
      setValidationErrors({ ...validationErrors, [field]: null });
    }
  };

  const filteredStores = stores.filter(store =>
    store.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.fantasy_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.cnpj?.includes(searchTerm) ||
    store.city?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Gerenciar Lojas</h1>
            <p className="text-gray-600">Cadastre e gerencie as lojas da central</p>
          </div>
          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700" onClick={() => {
                  // Force new store flow
                  setEditingStore(null);
                  resetForm();
                }}>
                <Plus className="w-4 h-4 mr-2" />
                Nova Loja
              </Button>
            </DialogTrigger>
            <DialogContent className="w-full max-w-4xl max-h-[88vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingStore ? 'Editar Loja' : 'Cadastrar Nova Loja'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-12 gap-4">
                  <div className="col-span-8 space-y-4">
                    <div>
                      <Label>Razão Social *</Label>
                      <Input
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Ex: Supermercado Silva"
                        className={validationErrors.name ? 'border-red-500' : ''}
                      />
                      {validationErrors.name && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.name}</p>
                      )}
                    </div>
                    <div>
                      <Label>Nome Fantasia (opcional)</Label>
                      <Input
                        value={formData.fantasy_name}
                        onChange={(e) => handleInputChange('fantasy_name', e.target.value)}
                        placeholder="Ex: Mercado Silva"
                      />
                    </div>
                  </div>
                  <div className="col-span-4">
                    <Label>Status da Loja</Label>
                    <Select value={formData.status} onValueChange={(value) => handleInputChange('status', value)}>
                      <SelectTrigger>
                        <span>{formData.status === 'active' ? 'Ativa' : 'Inativa'}</span>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Ativa</SelectItem>
                        <SelectItem value="inactive">Inativa</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1">Lojas inativas não podem fazer novos pedidos</p>
                  </div>

                  <div className="col-span-4">
                    <Label>CNPJ *</Label>
                    <Input
                      value={formData.cnpj}
                      onChange={(e) => handleInputChange('cnpj', e.target.value)}
                      placeholder="00.000.000/0000-00"
                      maxLength={18}
                      className={validationErrors.cnpj ? 'border-red-500' : ''}
                    />
                    {validationErrors.cnpj && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.cnpj}</p>
                    )}
                  </div>
                  <div className="col-span-4">
                    <Label>Inscrição Estadual (opcional)</Label>
                    <Input
                      value={formData.inscricao_estadual}
                      onChange={(e) => handleInputChange('inscricao_estadual', e.target.value)}
                      placeholder="Número IE"
                      className={validationErrors.inscricao_estadual ? 'border-red-500' : ''}
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={13}
                    />
                    {validationErrors.inscricao_estadual && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.inscricao_estadual}</p>
                    )}
                  </div>
                  <div className="col-span-4">
                    <Label>CEP</Label>
                    <Input
                      value={formData.zip_code}
                      onChange={(e) => handleInputChange('zip_code', e.target.value)}
                      placeholder="00000-000"
                      maxLength={9}
                      className={validationErrors.zip_code ? 'border-red-500' : ''}
                    />
                    {validationErrors.zip_code && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.zip_code}</p>
                    )}
                  </div>

                  <div className="col-span-8">
                    <Label>Endereço (Logradouro) *</Label>
                    <Input
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      placeholder="Rua, Avenida..."
                      className={validationErrors.address ? 'border-red-500' : ''}
                    />
                    {validationErrors.address && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.address}</p>
                    )}
                  </div>
                  <div className="col-span-4">
                    <Label>Número</Label>
                    <Input
                      value={formData.address_number}
                      onChange={(e) => handleInputChange('address_number', e.target.value)}
                      placeholder="Ex: 123"
                    />
                  </div>
                  <div className="col-span-4">
                    <Label>Bairro</Label>
                    <Input
                      value={formData.neighborhood}
                      onChange={(e) => handleInputChange('neighborhood', e.target.value)}
                      placeholder="Ex: Centro"
                    />
                  </div>
                  <div className="col-span-4">
                    <Label>Referência</Label>
                    <Input
                      value={formData.reference}
                      onChange={(e) => handleInputChange('reference', e.target.value)}
                      placeholder="Ponto de referência (opcional)"
                    />
                  </div>
                  <div className="col-span-4">
                    <Label>Site (opcional)</Label>
                    <Input
                      value={formData.site}
                      onChange={(e) => handleInputChange('site', e.target.value)}
                      placeholder="https://www.sualoja.com"
                      className={validationErrors.site ? 'border-red-500' : ''}
                    />
                    {validationErrors.site && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.site}</p>
                    )}
                  </div>

                  <div className="col-span-6">
                    <Label>Cidade *</Label>
                    <Input
                      value={formData.city}
                      onChange={(e) => handleInputChange('city', e.target.value)}
                      placeholder="Ex: São Paulo"
                      className={validationErrors.city ? 'border-red-500' : ''}
                    />
                    {validationErrors.city && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.city}</p>
                    )}
                  </div>
                  <div className="col-span-6">
                    <Label>Estado *</Label>
                    <Select
                      value={formData.state}
                      onValueChange={(value) => handleInputChange('state', value)}
                    >
                      <SelectTrigger className={validationErrors.state ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {STATES.map(state => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {validationErrors.state && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.state}</p>
                    )}
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-3">Dados do Responsável</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Nome Completo *</Label>
                      <Input
                        value={formData.responsible_name}
                        onChange={(e) => handleInputChange('responsible_name', e.target.value)}
                        placeholder="Ex: João da Silva"
                        className={validationErrors.responsible_name ? 'border-red-500' : ''}
                      />
                      {validationErrors.responsible_name && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.responsible_name}</p>
                      )}
                    </div>
                    <div>
                      <Label>Cargo</Label>
                      <Input
                        value={formData.responsible_position}
                        onChange={(e) => handleInputChange('responsible_position', e.target.value)}
                        placeholder="Ex: Gerente de Compras"
                      />
                    </div>
                    <div>
                      <Label>Email *</Label>
                      <Input
                        type="email"
                        value={formData.responsible_email}
                        onChange={(e) => handleInputChange('responsible_email', e.target.value)}
                        placeholder="email@exemplo.com"
                        className={validationErrors.responsible_email ? 'border-red-500' : ''}
                      />
                      {validationErrors.responsible_email && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.responsible_email}</p>
                      )}
                    </div>
                    <div>
                      <Label>Telefone</Label>
                      <Input
                        value={formData.responsible_phone}
                        onChange={(e) => handleInputChange('responsible_phone', e.target.value)}
                        placeholder="(00) 00000-0000"
                        maxLength={15}
                        className={validationErrors.responsible_phone ? 'border-red-500' : ''}
                      />
                      {validationErrors.responsible_phone && (
                        <p className="text-xs text-red-500 mt-1">{validationErrors.responsible_phone}</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-3">Termo de Aceite LGPD</h3>
                  <div className="space-y-3 mb-4">
                    <div className="text-xs leading-relaxed bg-gray-50 border border-gray-200 rounded p-3 text-gray-700">
                      Ao marcar a opção abaixo, você declara que leu e aceita os termos de privacidade e o tratamento dos dados conforme a LGPD. O aceite será registrado com data e hora.
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="accepted_terms"
                        checked={formData.accepted_terms}
                        onChange={(e) => setFormData({ ...formData, accepted_terms: e.target.checked })}
                        className="w-4 h-4 text-indigo-600 rounded"
                      />
                      <Label htmlFor="accepted_terms" className="text-sm cursor-pointer">Li e aceito o Termo de LGPD</Label>
                    </div>
                    {validationErrors.termo_aceito && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.termo_aceito}</p>
                    )}
                  </div>
                </div>

                {Object.keys(validationErrors).length > 0 && (
                  <Alert className="bg-red-50 border-red-200">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      Por favor, corrija os erros acima antes de continuar.
                    </AlertDescription>
                  </Alert>
                )}

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-blue-600 to-indigo-600"
                    disabled={createStoreMutation.isPending || updateStoreMutation.isPending}
                  >
                    {(createStoreMutation.isPending || updateStoreMutation.isPending)
                      ? 'Salvando...'
                      : editingStore ? 'Salvar Alterações' : 'Cadastrar Loja'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {generatedCredentials && (
          <Alert className="mb-6 bg-green-50 border-green-200">
            <AlertDescription>
              <div className="font-semibold mb-2">✅ Loja cadastrada com sucesso!</div>
              <div className="text-sm">
                <p className="mb-1"><strong>Credenciais geradas:</strong></p>
                <div className="flex items-center gap-2 mb-2">
                  <p>• Usuário: <span className="font-mono bg-white px-2 py-1 rounded">{generatedCredentials.username}</span></p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0"
                    onClick={() => {
                      navigator.clipboard.writeText(generatedCredentials.username);
                      toast.success('Usuário copiado!');
                    }}
                    title="Copiar usuário"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <p>• Senha: <span className="font-mono bg-white px-2 py-1 rounded">{generatedCredentials.password}</span></p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0"
                    onClick={() => {
                      navigator.clipboard.writeText(generatedCredentials.password);
                      toast.success('Senha copiada!');
                    }}
                    title="Copiar senha"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <p className="mt-2 text-blue-700 flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  📧 Um email com as credenciais foi enviado para o responsável.
                </p>
                <p className="mt-2 text-amber-700">⚠️ Anote estas credenciais! Elas não serão exibidas novamente.</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="mt-3"
                onClick={() => setGeneratedCredentials(null)}
              >
                Entendi
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5" />
                Lojas Cadastradas ({filteredStores.length})
              </CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar lojas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Loja</TableHead>
                    <TableHead>CNPJ</TableHead>
                    <TableHead>Localização</TableHead>
                    <TableHead>Responsável</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                      </TableCell>
                    </TableRow>
                  ) : filteredStores.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-12 text-gray-500">
                        <Store className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Nenhuma loja cadastrada ainda</p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredStores.map((store) => (
                        <TableRow key={store.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="font-medium text-gray-900">{store.name}</div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-gray-600">{formatCNPJ(store.cnpj)}</span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <MapPin className="w-3 h-3" />
                            {store.city}, {store.state}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium text-gray-900">{store.responsible_name}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <Mail className="w-3 h-3" />
                            {store.responsible_email}
                          </div>
                        </TableCell>
                        <TableCell>
                          {store.responsible_phone ? (
                            <div className="flex items-center gap-1 text-sm text-gray-600">
                              <Phone className="w-3 h-3" />
                              {store.responsible_phone}
                            </div>
                          ) : (
                            <span className="text-sm text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant={store.status === 'active' ? 'default' : 'secondary'}>
                            {store.status === 'active' ? 'Ativa' : 'Inativa'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(store)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </TableCell>
                        {/* Botão de ativar contexto removido */}
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
