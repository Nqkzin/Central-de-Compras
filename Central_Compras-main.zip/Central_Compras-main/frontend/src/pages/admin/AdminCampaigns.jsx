import React, { useState } from "react";
import { toast } from 'sonner';
import { apiClient } from "@/services/apiClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, TrendingUp, Edit, Gift, DollarSign, Package, Loader2, XCircle, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import AIDescriptionHelper from "@/components/AIDescriptionHelper";

export default function AdminCampaigns() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deletingCampaign, setDeletingCampaign] = useState(null);
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: "",
    type: "cashback_value",
    description: "",
    image_url: "",
    min_value: 0,
    cashback_percentage: 0,
    product_id: "",
    min_quantity: 0,
    gift_description: "",
    start_date: "",
    end_date: "",
    status: "active",
    supplier_id: ""
  });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageInputMode, setImageInputMode] = useState('upload'); // 'upload' ou 'url'

  // Fetch all campaigns (admin can see all)
  const { data: campaigns, isLoading } = useQuery({
    queryKey: ['adminCampaigns'],
    queryFn: () => apiClient.entities.Campaign.list(),
    initialData: [],
  });

  // Fetch suppliers for dropdown
  const { data: suppliers } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.list(),
    initialData: [],
  });

  // Fetch all products for dropdown
  const { data: products } = useQuery({
    queryKey: ['products'],
    queryFn: () => apiClient.entities.Product.list(),
    initialData: [],
  });

  const createCampaignMutation = useMutation({
    mutationFn: async (campaignData) => {
      // Get account_id from selected supplier
      let accountId = null;
      try {
        const supplierList = await apiClient.entities.Supplier.filter({ id: campaignData.supplier_id });
        if (Array.isArray(supplierList) && supplierList.length > 0) {
          accountId = supplierList[0].id_conta || supplierList[0].account_id || null;
        }
      } catch (e) {
        console.warn('Could not fetch account_id from supplier:', e);
      }

      return apiClient.entities.Campaign.create({
        ...campaignData,
        id_conta: accountId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminCampaigns'] });
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      setShowDialog(false);
      resetForm();
      toast.success('Campanha criada com sucesso!');
    },
    onError: (error) => {
      toast.error(`Erro ao criar campanha: ${error.message || 'Verifique os dados e tente novamente.'}`);
    }
  });

  const updateCampaignMutation = useMutation({
    mutationFn: ({ id, data }) => apiClient.entities.Campaign.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminCampaigns'] });
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      setShowDialog(false);
      resetForm();
      toast.success('Campanha atualizada com sucesso!');
    },
    onError: (error) => {
      toast.error(`Erro ao atualizar campanha: ${error.message || 'Verifique os dados e tente novamente.'}`);
    }
  });

  const deleteCampaignMutation = useMutation({
    mutationFn: (id) => apiClient.entities.Campaign.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminCampaigns'] });
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      setShowDeleteDialog(false);
      setDeletingCampaign(null);
      toast.success('Campanha excluída com sucesso!');
    },
    onError: (error) => {
      toast.error(`Erro ao excluir campanha: ${error.message || 'Não foi possível excluir a campanha.'}`);
    }
  });

  const resetForm = () => {
    setFormData({
      name: "",
      type: "cashback_value",
      description: "",
      image_url: "",
      min_value: 0,
      cashback_percentage: 0,
      product_id: "",
      min_quantity: 0,
      gift_description: "",
      start_date: "",
      end_date: "",
      status: "active",
      supplier_id: ""
    });
    setEditingCampaign(null);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingImage(true);
    try {
      const result = await apiClient.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, image_url: result.file_url });
      toast.success('Imagem carregada com sucesso!');
    } catch (error) {
      console.error("Error uploading image:", error);
      toast.error('Erro ao fazer upload da imagem');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name.trim()) {
      toast.error('Nome da campanha é obrigatório');
      return;
    }

    if (!formData.supplier_id) {
      toast.error('Selecione um fornecedor');
      return;
    }

    if (formData.type === 'cashback_value') {
      if (!formData.min_value || formData.min_value <= 0) {
        toast.error('Valor mínimo de compra é obrigatório e deve ser maior que zero.');
        return;
      }
      if (formData.cashback_percentage === null || formData.cashback_percentage <= 0 || formData.cashback_percentage > 100) {
        toast.error('Percentual de cashback é obrigatório e deve ser entre 0.01% e 100%.');
        return;
      }
    }

    if (formData.type === 'cashback_quantity' || formData.type === 'gift_quantity') {
      if (!formData.product_id) {
        toast.error('Selecione um produto para a campanha.');
        return;
      }
      if (!formData.min_quantity || formData.min_quantity <= 0) {
        toast.error('Quantidade mínima é obrigatória e deve ser maior que zero.');
        return;
      }
    }

    if (formData.type === 'cashback_quantity' && (formData.cashback_percentage === null || formData.cashback_percentage <= 0 || formData.cashback_percentage > 100)) {
      toast.error('Percentual de cashback é obrigatório e deve ser entre 0.01% e 100%.');
      return;
    }

    if (formData.type === 'gift_quantity' && !formData.gift_description?.trim()) {
      toast.error('Descrição do brinde é obrigatória.');
      return;
    }

    if (formData.start_date && formData.end_date && new Date(formData.start_date) > new Date(formData.end_date)) {
      toast.error('A data de início não pode ser posterior à data de término.');
      return;
    }

    // Validar se está tentando ativar uma campanha expirada
    if (formData.status === 'active' && formData.end_date) {
      const endDate = new Date(formData.end_date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      endDate.setHours(0, 0, 0, 0);
      
      if (endDate < today) {
        toast.error('Não é possível ativar uma campanha com data de término já passada.');
        return;
      }
    }

    if (editingCampaign) {
      updateCampaignMutation.mutate({ id: editingCampaign.id, data: formData });
    } else {
      createCampaignMutation.mutate(formData);
    }
  };

  const handleEdit = (campaign) => {
    setEditingCampaign(campaign);
    setFormData({
      ...campaign,
      min_value: parseFloat(campaign.min_value || 0),
      cashback_percentage: parseFloat(campaign.cashback_percentage || 0),
      min_quantity: parseInt(campaign.min_quantity || 0),
      start_date: campaign.start_date ? new Date(campaign.start_date).toISOString().split('T')[0] : '',
      end_date: campaign.end_date ? new Date(campaign.end_date).toISOString().split('T')[0] : '',
      product_id: campaign.product_id ? String(campaign.product_id) : "",
      supplier_id: campaign.supplier_id ? String(campaign.supplier_id) : ""
    });
    setShowDialog(true);
  };

  const handleDeleteClick = (campaign) => {
    setDeletingCampaign(campaign);
    setShowDeleteDialog(true);
  };

  const handleDeleteConfirm = () => {
    if (deletingCampaign) {
      deleteCampaignMutation.mutate(deletingCampaign.id);
    }
  };

  const getCampaignIcon = (type) => {
    switch(type) {
      case 'cashback_value': return DollarSign;
      case 'cashback_quantity': return Package;
      case 'gift_quantity': return Gift;
      default: return TrendingUp;
    }
  };

  const getCampaignTypeLabel = (type) => {
    const labels = {
      cashback_value: 'Cashback por Valor',
      cashback_quantity: 'Cashback por Quantidade',
      gift_quantity: 'Brinde por Quantidade',
    };
    return labels[type] || type;
  };

  const getStatusLabel = (status) => {
    const labels = {
      active: 'Ativa',
      inactive: 'Inativa',
      expired: 'Expirada',
    };
    return labels[status] || status;
  };

  const isExpired = (campaign) => {
    if (!campaign.end_date) return false;
    const endDate = new Date(campaign.end_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    endDate.setHours(0, 0, 0, 0);
    return endDate < today;
  };

  const resolveImageUrl = (url) => {
    if (!url) return null;
    if (/^https?:\/\//i.test(url)) return url;
    return `http://localhost:3001${url.startsWith('/') ? '' : '/'}${url}`;
  };

  const getSupplierName = (supplierId) => {
    const supplier = suppliers.find(s => String(s.id) === String(supplierId));
    return supplier?.fantasy_name || supplier?.name || 'Desconhecido';
  };

  const getProductName = (productId) => {
    const product = products.find(p => String(p.id) === String(productId));
    return product?.name || 'Produto não encontrado';
  };

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Gerenciar Campanhas</h1>
            <p className="text-gray-600">Gerencie todas as campanhas promocionais da plataforma</p>
          </div>
          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                <Plus className="w-4 h-4 mr-2" />
                Nova Campanha
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingCampaign ? 'Editar Campanha' : 'Criar Nova Campanha'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label>Fornecedor *</Label>
                    <Select value={formData.supplier_id} onValueChange={(value) => setFormData({...formData, supplier_id: value})} required>
                      <SelectTrigger>
                        <span className="truncate">{getSupplierName(formData.supplier_id) || 'Selecione o fornecedor'}</span>
                      </SelectTrigger>
                      <SelectContent>
                        {suppliers.length === 0 ? (
                          <SelectItem value={""} disabled>Nenhum fornecedor encontrado</SelectItem>
                        ) : (
                          suppliers.map(supplier => (
                            <SelectItem key={supplier.id} value={String(supplier.id)}>
                              {supplier.fantasy_name || supplier.name}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="col-span-2">
                    <Label>Nome da Campanha *</Label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: Cashback de 10% em compras acima de R$ 100"
                      required
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Banner da Campanha</Label>
                    <div className="space-y-3">
                      {/* Abas para escolher modo */}
                      <div className="flex gap-2 border-b">
                        <button
                          type="button"
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            imageInputMode === 'upload'
                              ? 'text-purple-600 border-b-2 border-purple-600'
                              : 'text-gray-500 hover:text-gray-700'
                          }`}
                          onClick={() => setImageInputMode('upload')}
                        >
                          Upload de Arquivo
                        </button>
                        <button
                          type="button"
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            imageInputMode === 'url'
                              ? 'text-purple-600 border-b-2 border-purple-600'
                              : 'text-gray-500 hover:text-gray-700'
                          }`}
                          onClick={() => setImageInputMode('url')}
                        >
                          URL da Imagem
                        </button>
                      </div>

                      {/* Input baseado no modo selecionado */}
                      {imageInputMode === 'upload' ? (
                        <div className="space-y-2">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            disabled={uploadingImage}
                          />
                          <p className="text-xs text-gray-500">
                            Tamanho recomendado: 1200x400px (proporção 3:1). Formatos: JPG, PNG ou WebP
                          </p>
                          {uploadingImage && (
                            <div className="flex items-center gap-2 text-sm text-blue-600">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              Fazendo upload...
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Input
                            type="url"
                            placeholder="https://exemplo.com/banner.jpg"
                            value={formData.image_url}
                            onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                          />
                          <p className="text-xs text-gray-500">
                            Cole a URL completa da imagem (ex: de um repositório online, CDN, etc.)
                          </p>
                        </div>
                      )}

                      {/* Preview da imagem */}
                      {formData.image_url && !uploadingImage && (
                        <div className="relative">
                          <img 
                            src={resolveImageUrl(formData.image_url)} 
                            alt="Preview" 
                            className="w-full h-32 object-cover rounded-lg border"
                            onError={(e) => {
                              e.target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100"%3E%3Crect fill="%23ddd" width="100" height="100"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%23999" font-size="14"%3EImagem inválida%3C/text%3E%3C/svg%3E';
                            }}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute top-2 right-2 bg-white rounded-full p-1"
                            onClick={() => setFormData({ ...formData, image_url: "" })}
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="col-span-2">
                    <Label>Tipo de Campanha *</Label>
                    <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})} required>
                      <SelectTrigger>
                        <span className="truncate">{getCampaignTypeLabel(formData.type) || 'Selecione o tipo'}</span>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cashback_value">Cashback por Valor de Compra</SelectItem>
                        <SelectItem value="cashback_quantity">Cashback por Quantidade</SelectItem>
                        <SelectItem value="gift_quantity">Brinde por Quantidade</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.type === 'cashback_value' && (
                    <>
                      <div>
                        <Label>Valor Mínimo de Compra (R$) *</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={formData.min_value}
                          onChange={(e) => setFormData({ ...formData, min_value: parseFloat(e.target.value) })}
                          required
                        />
                      </div>
                      <div>
                        <Label>Percentual de Cashback (%) *</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={formData.cashback_percentage}
                          onChange={(e) => setFormData({...formData, cashback_percentage: parseFloat(e.target.value)})}
                          required
                          max="100"
                          min="0.01"
                        />
                      </div>
                    </>
                  )}

                  {(formData.type === 'cashback_quantity' || formData.type === 'gift_quantity') && (
                    <>
                      <div>
                        <Label>Produto *</Label>
                        <Select value={formData.product_id} onValueChange={(value) => setFormData({...formData, product_id: String(value)})} required>
                          <SelectTrigger>
                            <span className="truncate">{getProductName(formData.product_id) || 'Selecione o produto'}</span>
                          </SelectTrigger>
                          <SelectContent>
                            {products.length === 0 ? (
                              <SelectItem value={""} disabled>Nenhum produto encontrado</SelectItem>
                            ) : (
                              products.map(product => (
                                <SelectItem key={product.id} value={String(product.id)}>{product.name}</SelectItem>
                              ))
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Quantidade Mínima *</Label>
                        <Input
                          type="number"
                          value={formData.min_quantity}
                          onChange={(e) => setFormData({...formData, min_quantity: parseInt(e.target.value)})}
                          required
                          min="1"
                        />
                      </div>
                    </>
                  )}

                  {formData.type === 'cashback_quantity' && (
                    <div className="col-span-2">
                      <Label>Percentual de Cashback (%) *</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={formData.cashback_percentage}
                        onChange={(e) => setFormData({...formData, cashback_percentage: parseFloat(e.target.value)})}
                        required
                        max="100"
                        min="0.01"
                      />
                    </div>
                  )}

                  {formData.type === 'gift_quantity' && (
                    <div className="col-span-2">
                      <Label>Descrição do Brinde *</Label>
                      <Input
                        value={formData.gift_description}
                        onChange={(e) => setFormData({...formData, gift_description: e.target.value})}
                        placeholder="Ex: 1 unidade grátis do produto X"
                        required
                      />
                    </div>
                  )}

                  <div>
                    <Label>Data de Início</Label>
                    <Input
                      type="date"
                      value={formData.start_date}
                      onChange={(e) => setFormData({...formData, start_date: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Data de Término</Label>
                    <Input
                      type="date"
                      value={formData.end_date}
                      onChange={(e) => setFormData({...formData, end_date: e.target.value})}
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Descrição</Label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      rows={3}
                      placeholder="Descreva os detalhes da campanha..."
                    />
                    <div className="mt-2">
                      <AIDescriptionHelper
                        productName={formData.name}
                        type="campaign"
                        campaignData={formData}
                        onSuggestionReceived={(description) => {
                          setFormData({...formData, description: description});
                        }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      💡 Preencha os campos acima primeiro para que a IA gere uma descrição mais precisa e contextualizada
                    </p>
                  </div>

                  <div>
                    <Label>Status</Label>
                    <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                      <SelectTrigger>
                        <span className="truncate">{getStatusLabel(formData.status) || 'Selecione o status'}</span>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Ativa</SelectItem>
                        <SelectItem value="inactive">Inativa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancelar
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-gradient-to-r from-purple-600 to-pink-600"
                    disabled={createCampaignMutation.isPending || updateCampaignMutation.isPending || uploadingImage}
                  >
                    {(createCampaignMutation.isPending || updateCampaignMutation.isPending)
                      ? 'Salvando...'
                      : editingCampaign ? 'Salvar Alterações' : 'Criar Campanha'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
          </div>
        ) : campaigns.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="py-12 text-center text-gray-500">
              <TrendingUp className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg">Nenhuma campanha criada ainda</p>
              <p className="text-sm mt-2">Crie campanhas para incentivar as vendas</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {campaigns.map((campaign) => {
              const Icon = getCampaignIcon(campaign.type);
              const imageUrl = resolveImageUrl(campaign.image_url);
              return (
                <Card key={campaign.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                  {imageUrl && (
                    <img 
                      src={imageUrl} 
                      alt={campaign.name}
                      className="w-full h-32 object-cover rounded-t-lg"
                    />
                  )}
                  {!imageUrl && <div className="h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-t-lg" />}
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Icon className="w-6 h-6 text-purple-600" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <CardTitle className="text-lg truncate" title={campaign.name}>
                            {campaign.name}
                          </CardTitle>
                          <Badge variant="secondary" className="mt-1">
                            {getCampaignTypeLabel(campaign.type)}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-sm">
                      <span className="text-gray-500">Fornecedor:</span>
                      <p className="font-semibold text-purple-700">{getSupplierName(campaign.supplier_id)}</p>
                    </div>

                    {campaign.description && (
                      <p className="text-sm text-gray-600 line-clamp-3" title={campaign.description}>
                        {campaign.description}
                      </p>
                    )}

                    <div className="space-y-2 text-sm">
                      {campaign.type === 'cashback_value' && (() => {
                        // Calculate progress for campaigns
                        const prog = {
                          mode: 'value',
                          current: 0,
                          target: Number(campaign.min_value || 0),
                          percent: 0,
                          active: false
                        };
                        
                        if (campaign.progress && typeof campaign.progress.percent === 'number') {
                          prog.current = campaign.progress.current || 0;
                          prog.percent = Math.min(100, campaign.progress.percent || 0);
                          prog.active = campaign.progress.active || false;
                        }
                        
                        return (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Valor Mínimo:</span>
                              <span className="font-semibold">R$ {Number(campaign.min_value || 0).toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Cashback:</span>
                              <span className="font-semibold text-green-600">{campaign.cashback_percentage}%</span>
                            </div>
                            <div className="mt-2 p-3 bg-amber-50 rounded-lg">
                              <div className="flex justify-between text-xs mb-2">
                                <span className="font-medium">Progresso:</span>
                                <span className="font-semibold">{prog.percent.toFixed(0)}%</span>
                              </div>
                              <div className="w-full bg-white rounded-full h-2">
                                <div className="bg-amber-500 h-2 rounded-full transition-all" style={{ width: `${prog.percent}%` }} />
                              </div>
                              <div className="flex justify-between text-xs mt-2 text-gray-600">
                                <span>Acumulado: R$ {Number(prog.current || 0).toFixed(2)}</span>
                                <span>Meta: R$ {Number(prog.target || 0).toFixed(2)}</span>
                              </div>
                              {prog.active && (
                                <div className="mt-2 text-xs text-amber-700 bg-amber-100 border border-amber-200 rounded p-2">
                                  Meta atingida: próximas compras já geram cashback.
                                </div>
                              )}
                            </div>
                          </>
                        );
                      })()}

                      {campaign.type === 'cashback_quantity' && (() => {
                        // Calculate progress for quantity-based campaigns
                        const prog = {
                          mode: 'quantity',
                          current: 0,
                          target: Number(campaign.min_quantity || 0),
                          percent: 0,
                          active: false
                        };
                        
                        if (campaign.progress && typeof campaign.progress.percent === 'number') {
                          prog.current = campaign.progress.current || 0;
                          prog.percent = Math.min(100, campaign.progress.percent || 0);
                          prog.active = campaign.progress.active || false;
                        }
                        
                        return (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Produto:</span>
                              <span className="font-semibold text-sm truncate" title={getProductName(campaign.product_id)}>
                                {getProductName(campaign.product_id)}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Qtd Mínima:</span>
                              <span className="font-semibold">{campaign.min_quantity} unidades</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Cashback:</span>
                              <span className="font-semibold text-green-600">{campaign.cashback_percentage}%</span>
                            </div>
                            <div className="mt-2 p-3 bg-blue-50 rounded-lg">
                              <div className="flex justify-between text-xs mb-2">
                                <span className="font-medium">Progresso:</span>
                                <span className="font-semibold">{prog.percent.toFixed(0)}%</span>
                              </div>
                              <div className="w-full bg-white rounded-full h-2">
                                <div className="bg-blue-500 h-2 rounded-full transition-all" style={{ width: `${prog.percent}%` }} />
                              </div>
                              <div className="flex justify-between text-xs mt-2 text-gray-600">
                                <span>Acumulado: {Number(prog.current || 0)} un.</span>
                                <span>Meta: {Number(prog.target || 0)} un.</span>
                              </div>
                              {prog.active && (
                                <div className="mt-2 text-xs text-blue-700 bg-blue-100 border border-blue-200 rounded p-2">
                                  Meta atingida: próximas compras já geram cashback.
                                </div>
                              )}
                            </div>
                          </>
                        );
                      })()}

                      {campaign.type === 'gift_quantity' && (() => {
                        // Calculate progress for gift campaigns
                        const prog = {
                          mode: 'quantity',
                          current: 0,
                          target: Number(campaign.min_quantity || 0),
                          percent: 0,
                          active: false
                        };
                        
                        if (campaign.progress && typeof campaign.progress.percent === 'number') {
                          prog.current = campaign.progress.current || 0;
                          prog.percent = Math.min(100, campaign.progress.percent || 0);
                          prog.active = campaign.progress.active || false;
                        }
                        
                        return (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Produto:</span>
                              <span className="font-semibold text-sm truncate" title={getProductName(campaign.product_id)}>
                                {getProductName(campaign.product_id)}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Qtd Mínima:</span>
                              <span className="font-semibold">{campaign.min_quantity} unidades</span>
                            </div>
                            <div>
                              <span className="text-gray-500 text-xs">Brinde:</span>
                              <p className="font-semibold text-sm text-purple-600 mt-1 line-clamp-2" title={campaign.gift_description}>
                                {campaign.gift_description}
                              </p>
                            </div>
                            <div className="mt-2 p-3 bg-purple-50 rounded-lg">
                              <div className="flex justify-between text-xs mb-2">
                                <span className="font-medium">Progresso:</span>
                                <span className="font-semibold">{prog.percent.toFixed(0)}%</span>
                              </div>
                              <div className="w-full bg-white rounded-full h-2">
                                <div className="bg-purple-500 h-2 rounded-full transition-all" style={{ width: `${prog.percent}%` }} />
                              </div>
                              <div className="flex justify-between text-xs mt-2 text-gray-600">
                                <span>Acumulado: {Number(prog.current || 0)} un.</span>
                                <span>Meta: {Number(prog.target || 0)} un.</span>
                              </div>
                              {prog.active && (
                                <div className="mt-2 text-xs text-purple-700 bg-purple-100 border border-purple-200 rounded p-2">
                                  Meta atingida: brinde ativo para próximas compras.
                                </div>
                              )}
                            </div>
                          </>
                        );
                      })()}
                    </div>

                    {(campaign.start_date || campaign.end_date) && (
                      <div className="text-xs text-gray-500 border-t pt-3">
                        {campaign.start_date && <p>Início: {new Date(campaign.start_date).toLocaleDateString('pt-BR')}</p>}
                        {campaign.end_date && <p>Término: {new Date(campaign.end_date).toLocaleDateString('pt-BR')}</p>}
                        {isExpired(campaign) && (
                          <div className="mt-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded p-2 font-medium">
                            ⚠️ Esta campanha está expirada e foi automaticamente inativada.
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-3 border-t">
                      <Badge variant={isExpired(campaign) || campaign.status === 'expired' ? 'destructive' : campaign.status === 'active' ? 'default' : 'secondary'}>
                        {isExpired(campaign) || campaign.status === 'expired' ? 'Expirada' : getStatusLabel(campaign.status)}
                      </Badge>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(campaign)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteClick(campaign)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Delete Confirmation Dialog */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Exclusão</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-gray-600">
                Tem certeza que deseja excluir a campanha <strong>{deletingCampaign?.name}</strong>?
              </p>
              <p className="text-sm text-red-600">
                Esta ação não pode ser desfeita.
              </p>
              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowDeleteDialog(false);
                    setDeletingCampaign(null);
                  }}
                >
                  Cancelar
                </Button>
                <Button 
                  type="button" 
                  variant="destructive"
                  onClick={handleDeleteConfirm}
                  disabled={deleteCampaignMutation.isPending}
                >
                  {deleteCampaignMutation.isPending ? 'Excluindo...' : 'Excluir Campanha'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
