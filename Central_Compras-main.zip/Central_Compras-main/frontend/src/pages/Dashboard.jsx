import React, { useState, useEffect } from "react";
import { apiClient } from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Store, Building2, Package, ShoppingCart, TrendingUp, Users, Eye, Megaphone } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user: authUser } = useAuth();
  const [user, setUser] = useState(null);
  const [previewMode, setPreviewMode] = useState(null);
  const [showAllOrders, setShowAllOrders] = useState(false);
  const [showAllTopStores, setShowAllTopStores] = useState(false);
  const [showAllTopCashback, setShowAllTopCashback] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const loadUser = async () => {
      try {
        // Check for preview mode
        // Preview removido: usa usuário do AuthContext
        if (!cancelled) setUser(authUser);
      } catch (e) {
        console.warn('Falha ao carregar usuário no Dashboard:', e);
        if (!cancelled) setUser(authUser || null);
      }
    };
    loadUser();
    return () => { cancelled = true; };
  }, [authUser]);

  const { data: stores } = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiClient.entities.Store.list(),
    initialData: [],
  });

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.list(),
    initialData: [],
  });

  const { data: products } = useQuery({
    queryKey: ['products'],
    queryFn: () => apiClient.entities.Product.list(),
    initialData: [],
  });

  const { data: orders } = useQuery({
    queryKey: ['orders'],
    queryFn: () => apiClient.entities.Order.list('-created_date'),
    initialData: [],
  });

  // Fetch total cashback for store (if store user)
  const storeId = user?.store_id;
  const { data: storeCashback } = useQuery({
    enabled: !!storeId && (user?.user_type === 'store'),
    queryKey: ['store', storeId, 'cashback'],
    queryFn: async () => {
      const res = await apiClient.entities.Store.cashback(storeId);
      return {
        total_previsto: res?.total_previsto ?? 0,
        total_realizado: res?.total_realizado ?? 0,
      };
    },
    initialData: { total_previsto: 0, total_realizado: 0 },
  });
  const userType = user?.user_type || 'admin';

  const { data: cashbackSummary = [] } = useQuery({
    enabled: user?.user_type === 'admin',
    queryKey: ['stores', 'cashback', 'summary'],
    queryFn: () => apiClient.entities.Store.cashbackSummary(),
    initialData: [],
  });

  const { data: campaigns } = useQuery({
    queryKey: ['campaigns'],
    queryFn: () => apiClient.entities.Campaign.filter({ status: 'active' }),
    initialData: [],
    enabled: userType === 'admin' || userType === 'store',
  });

  // Progress helpers for campaigns (prefer backend-provided progress, fallback to local calc)
  const processedStatuses = new Set(['processing', 'separated', 'shipped', 'delivered']);
  const clamp = (num, min = 0, max = 100) => Math.max(min, Math.min(max, num));
  const getCampaignProgress = (campaign) => {
    // If backend attached progress, trust it
    if (campaign?.progress && typeof campaign.progress.percent === 'number') {
      const p = clamp(campaign.progress.percent);
      return {
        mode: campaign.progress.mode,
        current: campaign.progress.current,
        target: campaign.progress.target,
        percent: p,
        active: !!campaign.progress.active,
      };
    }
    // Fallback for value campaigns using orders from dashboard scope
    if (campaign?.type === 'cashback_value') {
      const supplierId = campaign.supplier_id;
      const inWindow = (dateStr) => {
        // If campaign has start/end dates, respect them, else count all
        const d = new Date(dateStr);
        if (campaign.start_date) {
          const start = new Date(campaign.start_date);
          if (d < start) return false;
        }
        if (campaign.end_date) {
          const end = new Date(campaign.end_date);
          if (d > end) return false;
        }
        return true;
      };
      const sum = orders
        .filter(o => o.supplier_id === supplierId && processedStatuses.has(o.status) && inWindow(o.created_date))
        .reduce((acc, o) => acc + toNumber(o.total_amount), 0);
      const target = toNumber(campaign.value_threshold);
      const percent = target > 0 ? clamp((sum / target) * 100) : 0;
      return {
        mode: 'value',
        current: sum,
        target,
        percent,
        active: percent >= 100,
      };
    }
    // Fallback for quantity campaigns
    if (campaign?.type === 'cashback_quantity' || campaign?.type === 'gift_quantity') {
      const supplierId = campaign.supplier_id;
      const productId = campaign.product_id;
      const inWindow = (dateStr) => {
        const d = new Date(dateStr);
        if (campaign.start_date) {
          const start = new Date(campaign.start_date);
          if (d < start) return false;
        }
        if (campaign.end_date) {
          const end = new Date(campaign.end_date);
          if (d > end) return false;
        }
        return true;
      };
      
      let currentQty = 0;
      orders
        .filter(o => o.supplier_id === supplierId && processedStatuses.has(o.status) && inWindow(o.created_date))
        .forEach(order => {
          (order.items || []).forEach(item => {
            if (String(item.product_id) === String(productId)) {
              currentQty += toNumber(item.quantity);
            }
          });
        });
      
      const target = toNumber(campaign.min_quantity);
      const percent = target > 0 ? clamp((currentQty / target) * 100) : 0;
      return {
        mode: 'quantity',
        current: currentQty,
        target,
        percent,
        active: percent >= 100,
      };
    }
    // Default: no progress
    return { mode: null, current: 0, target: 0, percent: 0, active: false };
  };

  // Helpers seguros para números/moeda (tratam string, vírgula, nulo)
  const toNumber = (value) => {
    if (value === null || value === undefined || value === '') return 0;
    if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
    if (typeof value === 'string') {
      const raw = value.trim();
      if (raw === '') return 0;
      if (raw.includes(',')) {
        const normalized = raw.replace(/\./g, '').replace(',', '.');
        const num = Number(normalized);
        return Number.isFinite(num) ? num : 0;
      }
      const num = Number(raw);
      return Number.isFinite(num) ? num : 0;
    }
    return 0;
  };

  const toMoney = (value) => {
    const num = toNumber(value);
    return num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // Calculate sales stats for admin
  const salesByStore = userType === 'admin' ? orders.reduce((acc, order) => {
    if (order.status !== 'cancelled') {
      const storeName = stores.find(s => s.id === order.store_id)?.name || 'Loja Desconhecida';
      if (!acc[storeName]) {
        acc[storeName] = { total: 0, count: 0 };
      }
      acc[storeName].total += toNumber(order.total_amount);
      acc[storeName].count += 1;
    }
    return acc;
  }, {}) : {};

  const topStoresBySales = Object.entries(salesByStore)
    .sort((a, b) => b[1].total - a[1].total)
    .slice(0, 5);

  const totalSalesValue = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, order) => sum + toNumber(order.total_amount), 0);

  const totalCashbackAllStoresPrevisto = cashbackSummary.reduce((sum, entry) => {
    return sum + toNumber(entry.total_previsto);
  }, 0);

  const totalCashbackAllStoresRealizado = cashbackSummary.reduce((sum, entry) => {
    return sum + toNumber(entry.total_realizado);
  }, 0);

  const topCashbackStores = cashbackSummary
    .map(entry => ({
      store_id: entry.store_id,
      store_name: stores.find(s => s.id === entry.store_id)?.name || 'Loja Desconhecida',
      total_previsto: toNumber(entry.total_previsto),
      total_realizado: toNumber(entry.total_realizado),
      is_active: entry.is_active,
      orders_with_cashback: entry.orders_with_cashback || 0,
      total_cashback: toNumber(entry.total_previsto), // usar previsto para ranking
    }))
    .sort((a, b) => b.total_previsto - a.total_previsto)
    .slice(0, 5);

  const activeCampaignsCount = (campaigns || []).length;
  const adminStats = [
    { 
      title: "Total de Lojas", 
      value: stores.filter(s => s.status === 'active').length, 
      icon: Store, 
      color: "from-blue-500 to-blue-600",
      link: "AdminStores"
    },
    { 
      title: "Fornecedores Ativos", 
      value: suppliers.filter(s => s.status === 'active').length, 
      icon: Building2, 
      color: "from-green-500 to-green-600",
      link: "AdminSuppliers"
    },
    { 
      title: "Produtos Cadastrados", 
      value: products.length, 
      icon: Package, 
      color: "from-purple-500 to-purple-600",
      link: "AdminProducts"
    },
    { 
      title: "Volume de Vendas", 
      value: `R$ ${(totalSalesValue / 1000).toFixed(1)}K`, 
      icon: TrendingUp, 
      color: "from-orange-500 to-orange-600",
      subtitle: `${orders.filter(o => o.status !== 'cancelled').length} pedidos`
    },
    { 
      title: "Cashback (Lojas)", 
      value: `R$ ${toMoney(totalCashbackAllStoresPrevisto)}`, 
      icon: TrendingUp, 
      color: "from-emerald-500 to-emerald-600",
      subtitle: `${cashbackSummary.length} loja${cashbackSummary.length === 1 ? '' : 's'} com cashback`
    },
    {
      title: "Campanhas Ativas",
      value: activeCampaignsCount,
      icon: Megaphone,
      color: "from-rose-500 to-pink-600",
      subtitle: activeCampaignsCount === 1 ? '1 campanha' : `${activeCampaignsCount} campanhas`
    },
  ];

  const storeStats = [
    { 
      title: "Fornecedores Disponíveis", 
      value: suppliers.filter(s => s.status === 'active').length, 
      icon: Building2, 
      color: "from-blue-500 to-blue-600",
      link: "StoreSuppliersView"
    },
    { 
      title: "Cashback Previsto", 
      value: `R$ ${toMoney(storeCashback?.total_previsto ?? 0)}`, 
      icon: TrendingUp, 
      color: "from-emerald-500 to-emerald-600"
    },
    { 
      title: "Cashback Efetivado", 
      value: `R$ ${toMoney(storeCashback?.total_realizado ?? 0)}`, 
      icon: TrendingUp, 
      color: "from-green-500 to-green-600"
    },
    { 
      title: "Meus Pedidos", 
      value: orders.filter(o => o.store_id === user?.store_id).length, 
      icon: ShoppingCart, 
      color: "from-green-500 to-green-600",
      link: "StoreOrders"
    },
    { 
      title: "Pedidos Pendentes", 
      value: orders.filter(o => o.store_id === user?.store_id && o.status === 'pending').length, 
      icon: Package, 
      color: "from-orange-500 to-orange-600",
      link: "StoreOrders"
    },
    { 
      title: "Produtos Disponíveis", 
      value: products.filter(p => p.status === 'active').length, 
      icon: TrendingUp, 
      color: "from-purple-500 to-purple-600"
    },
  ];

  const supplierStats = [
    { 
      title: "Pedidos Recebidos", 
      value: orders.filter(o => o.supplier_id === user?.supplier_id).length, 
      icon: ShoppingCart, 
      color: "from-blue-500 to-blue-600",
      link: "SupplierOrders"
    },
    { 
      title: "Pedidos Pendentes", 
      value: orders.filter(o => o.supplier_id === user?.supplier_id && o.status === 'pending').length, 
      icon: Package, 
      color: "from-orange-500 to-orange-600",
      link: "SupplierOrders"
    },
    { 
      title: "Meus Produtos", 
      value: products.filter(p => p.supplier_id === user?.supplier_id).length, 
      icon: Package, 
      color: "from-green-500 to-green-600",
      link: "SupplierProducts"
    },
    { 
      title: "Lojas Ativas", 
      value: stores.filter(s => s.status === 'active').length,
      icon: Store, 
      color: "from-purple-500 to-purple-600"
    },
  ];

  const stats = userType === 'admin' ? adminStats : userType === 'store' ? storeStats : supplierStats;

  // PreviewSelector removido; função antiga eliminada.

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Bem-vindo, {user?.full_name || 'Usuário'}!
          </h1>
          <p className="text-gray-600">
            {userType === 'admin' && 'Gerencie lojas, fornecedores e produtos da central de compras.'}
            {userType === 'store' && 'Encontre fornecedores e faça seus pedidos de forma rápida e fácil.'}
            {userType === 'supplier' && 'Gerencie seus pedidos, produtos e campanhas promocionais.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6 mb-10">
          {stats.map((stat, index) => {
            const card = (
              <Card className="group relative overflow-hidden border border-gray-200 hover:border-gray-300 rounded-2xl shadow-sm hover:shadow-md transition-all">
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-5 group-hover:opacity-10 transition-opacity`} />
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className={`card-icon flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br ${stat.color} text-white flex items-center justify-center shadow-md`}> 
                      <stat.icon className="w-7 h-7" />
                    </div>
                    <div className="flex-1">
                      <p className="text-[13px] tracking-wide font-medium text-gray-600 mb-1">{stat.title}</p>
                      <p className="text-3xl font-semibold text-gray-900 leading-tight">{stat.value}</p>
                      {stat.subtitle && (
                        <p className="text-xs text-gray-500 mt-1">{stat.subtitle}</p>
                      )}
                      {stat.link && (
                        <div className="mt-2">
                          <Button asChild variant="link" className="p-0 h-auto text-blue-600 hover:text-blue-700 text-xs">
                            <Link to={createPageUrl(stat.link)}>Ver detalhes →</Link>
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );

            return stat.link ? (
              <Link key={index} to={createPageUrl(stat.link)} className="no-underline">{card}</Link>
            ) : (
              <div key={index}>{card}</div>
            );
          })}
        </div>

        {userType === 'admin' && campaigns && campaigns.length > 0 && (
          <Card className="border-none shadow-lg mb-8">
            <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-pink-50">
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Campanhas Ativas ({campaigns.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                {campaigns.slice(0, 8).map((campaign) => {
                  const supplier = suppliers.find(s => s.id === campaign.supplier_id);
                  return (
                    <Link key={campaign.id} to={createPageUrl('AdminCampaigns')} className="no-underline">
                      <div className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                      {campaign.image_url && (
                        <img 
                          src={campaign.image_url} 
                          alt={campaign.name}
                          className="w-full h-20 object-cover rounded-md mb-3"
                        />
                      )}
                      <h3 className="font-semibold text-sm text-gray-900 mb-1 truncate" title={campaign.name}>
                        {campaign.name}
                      </h3>
                      <p className="text-xs text-gray-600 truncate" title={supplier?.name}>
                        {supplier?.name}
                      </p>
                      {(campaign.type === 'cashback_value' || campaign.type === 'cashback_quantity' || campaign.type === 'gift_quantity') && (
                        <div className="mt-3 space-y-1">
                          <p className="text-xs text-green-600">
                            💰 {campaign.cashback_percentage}% cashback
                          </p>
                          {(() => {
                            const prog = getCampaignProgress(campaign);
                            const isQuantityCampaign = campaign.type === 'cashback_quantity' || campaign.type === 'gift_quantity';
                            return (
                              <div>
                                <div className={`w-full h-2 rounded ${isQuantityCampaign ? 'bg-purple-100' : 'bg-amber-100'}`}>
                                  <div
                                    className={`h-2 rounded ${isQuantityCampaign ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'bg-amber-500'}`}
                                    style={{ width: `${prog.percent}%` }}
                                  />
                                </div>
                                <div className="flex items-center justify-between mt-1">
                                  <span className="text-[11px] text-gray-600">
                                    {isQuantityCampaign ? `${prog.current || 0} de ${prog.target || 0} unidades` : 'Progresso'}
                                  </span>
                                  <span className={`text-[11px] font-medium ${isQuantityCampaign ? 'text-purple-700' : 'text-amber-700'}`}>
                                    {Math.round(prog.percent)}%
                                  </span>
                                </div>
                                {prog.active && (
                                  <p className="text-[11px] text-emerald-700 mt-1">Meta atingida — próximos pedidos geram cashback</p>
                                )}
                              </div>
                            );
                          })()}
                        </div>
                      )}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {userType === 'admin' && topStoresBySales.length > 0 && (
          <Card className="border-none shadow-lg mb-8">
            <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5" />
                Top Lojas por Volume de Vendas
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {topStoresBySales.slice(0, showAllTopStores ? undefined : 3).map(([storeName, data], index) => (
                  <div key={storeName} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-bold text-blue-600">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{storeName}</p>
                        <p className="text-xs text-gray-500">{data.count} pedidos</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-blue-600">
                        R$ {toMoney(data.total)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              {topStoresBySales.length > 3 && (
                <div className="text-center mt-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowAllTopStores(!showAllTopStores)}
                  >
                    {showAllTopStores ? 'Ver Menos' : `Ver Todas (${topStoresBySales.length})`}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {userType === 'admin' && topCashbackStores.length > 0 && (
          <Card className="border-none shadow-lg mb-8">
            <CardHeader className="border-b bg-gradient-to-r from-emerald-50 to-teal-50">
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
                Top Lojas por Cashback
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {topCashbackStores.slice(0, showAllTopCashback ? undefined : 3).map((entry, index) => (
                  <div key={entry.store_id} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-emerald-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center font-bold text-emerald-600">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{entry.store_name}</p>
                        <p className="text-xs text-gray-500">
                          {entry.orders_with_cashback} pedido{entry.orders_with_cashback === 1 ? '' : 's'} com cashback
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-emerald-600">
                        R$ {toMoney(entry.total_cashback)}
                      </p>
                      {!entry.is_active && (
                        <p className="text-xs text-amber-600">Loja inativa</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              {topCashbackStores.length > 3 && (
                <div className="text-center mt-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowAllTopCashback(!showAllTopCashback)}
                  >
                    {showAllTopCashback ? 'Ver Menos' : `Ver Todas (${topCashbackStores.length})`}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {userType === 'store' && campaigns.length > 0 && (
          <Card className="border-none shadow-lg mb-8">
            <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-pink-50">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Campanhas Ativas ({campaigns.length})
                </CardTitle>
                <Link to={createPageUrl('StoreCampaigns')}>
                  <Button variant="link" className="text-purple-600">
                    Ver Todas →
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-2 gap-4">
                {campaigns.slice(0, 4).map((campaign) => {
                  const supplier = suppliers.find(s => s.id === campaign.supplier_id);
                  return (
                    <div key={campaign.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      {campaign.image_url && (
                        <img 
                          src={campaign.image_url} 
                          alt={campaign.name}
                          className="w-full h-24 object-cover rounded-md mb-3"
                        />
                      )}
                      <h3 className="font-semibold text-gray-900 mb-1">{campaign.name}</h3>
                      <p className="text-sm text-gray-600 mb-3">{supplier?.name}</p>
                      {campaign.description && (
                        <p className="text-xs text-gray-500 mb-3 line-clamp-2">{campaign.description}</p>
                      )}
                      {campaign.type === 'cashback_value' && (
                        <div className="mb-3">
                          {(() => {
                            const prog = getCampaignProgress(campaign);
                            return (
                              <div>
                                <div className="w-full h-2 bg-amber-100 rounded">
                                  <div
                                    className="h-2 bg-amber-500 rounded"
                                    style={{ width: `${prog.percent}%` }}
                                  />
                                </div>
                                <div className="flex items-center justify-between mt-1">
                                  <span className="text-[11px] text-gray-600">Progresso</span>
                                  <span className="text-[11px] font-medium text-amber-700">{Math.round(prog.percent)}%</span>
                                </div>
                                {prog.active && (
                                  <p className="text-[11px] text-emerald-700 mt-1">Meta atingida — próximos pedidos geram cashback</p>
                                )}
                              </div>
                            );
                          })()}
                        </div>
                      )}
                      <Link to={createPageUrl('StoreCampaigns')}>
                        <Button size="sm" variant="outline" className="w-full border-purple-300 text-purple-700 hover:bg-purple-50">
                          Ver Campanha
                        </Button>
                      </Link>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {userType === 'admin' && (
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Últimos Pedidos</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <ShoppingCart className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Nenhum pedido registrado ainda</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.slice(0, showAllOrders ? undefined : 3).map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">Pedido #{order.order_number || order.id.slice(0, 8)}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(order.created_date).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">
                          R$ {toMoney(order.total_amount)}
                        </p>
                        <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${
                          order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                          order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                          order.status === 'shipped' ? 'bg-purple-100 text-purple-800' :
                          order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                          order.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {order.status === 'pending' ? 'Pendente' :
                           order.status === 'processing' ? 'Processando' :
                           order.status === 'separated' ? 'Separado' :
                           order.status === 'shipped' ? 'Enviado' :
                           order.status === 'delivered' ? 'Entregue' :
                           order.status === 'cancelled' ? 'Cancelado' : order.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {orders.length > 3 && (
                <div className="text-center mt-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowAllOrders(!showAllOrders)}
                  >
                    {showAllOrders ? 'Ver Menos' : `Ver Todos (${orders.length})`}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
