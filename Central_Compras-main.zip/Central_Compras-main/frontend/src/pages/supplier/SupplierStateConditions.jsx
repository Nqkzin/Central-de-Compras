
import React, { useState, useEffect } from "react";
import { toast } from 'sonner';
import { apiClient } from "@/services/apiClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, MapPin, Edit, DollarSign, Calendar, Percent, Copy, CheckCircle, Trash2, Package, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

const STATES = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"];

export default function SupplierStateConditions() {
  const [user, setUser] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [editingCondition, setEditingCondition] = useState(null);
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    state: "",
    cashback_percentage: 0,
    max_cashback_amount: 0, // NEW FIELD
    pedido_minimo: 0,
    pedido_minimo_frete_cif: 0,
    payment_term_days: 30,
    unit_price_adjustment: 0,
    catalog_url: "",
    notes: "",
    status: "active"
  });
  const [showReplicateDialog, setShowReplicateDialog] = useState(false);
  const [selectedStates, setSelectedStates] = useState([]);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [conditionToDelete, setConditionToDelete] = useState(null);

  const stripInactiveTag = (text) => {
    if (!text) return '';
    return text.replace(/\[INATIVA\]/gi, '').trim();
  };

  useEffect(() => {
    const loadUser = async () => {
      try {
        const previewData = localStorage.getItem('preview_mode');
        if (previewData) {
          const preview = JSON.parse(previewData);
          if (preview.type === 'supplier' && preview.id) {
            setUser({
              supplier_id: preview.id,
              user_type: 'supplier'
            });
          }
        } else {
          const currentUser = await apiClient.auth.me();
          setUser(currentUser);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const { data: conditions, isLoading } = useQuery({
    queryKey: ['supplierStateConditions', user?.supplier_id],
    queryFn: () => apiClient.entities.StateCondition.filter({ supplier_id: user?.supplier_id }),
    initialData: [],
    enabled: !!user?.supplier_id,
  });

  const createConditionMutation = useMutation({
    mutationFn: async (conditionData) => {
      console.log('Creating condition (with id_conta fallback):', conditionData);
      // tentar obter id_conta do fornecedor se não vier
      let accountId = null;
      try {
        const supplierList = await apiClient.entities.Supplier.filter({ id: user?.supplier_id });
        if (Array.isArray(supplierList) && supplierList.length > 0) {
          accountId = supplierList[0].id_conta || supplierList[0].account_id || null;
        }
      } catch (e) {
        console.warn('Não foi possível obter id_conta do fornecedor:', e);
      }
      return apiClient.entities.StateCondition.create({
        ...conditionData,
        supplier_id: user?.supplier_id,
        id_conta: accountId
      });
    },
    onSuccess: (data) => {
      console.log('Condition created successfully:', data);
      if (user?.supplier_id) {
        queryClient.invalidateQueries({ queryKey: ['supplierStateConditions', user.supplier_id] });
      } else {
        queryClient.invalidateQueries({ queryKey: ['supplierStateConditions'] });
      }
      queryClient.invalidateQueries({ queryKey: ['stateConditions'] });
      setShowDialog(false);
      setShowSuccessAlert(true);
      setTimeout(() => setShowSuccessAlert(false), 3000);
      resetForm();
    },
    onError: (error) => {
      console.error('Error creating condition:', error);
      toast.error('Erro ao criar condição. Tente novamente.');
    }
  });

  const updateConditionMutation = useMutation({
    mutationFn: ({ id, data }) => {
      console.log('Updating condition:', id, data);
      return apiClient.entities.StateCondition.update(id, data);
    },
    onSuccess: (data) => {
      console.log('Condition updated successfully:', data);
      queryClient.invalidateQueries({ queryKey: ['supplierStateConditions'] });
      queryClient.invalidateQueries({ queryKey: ['stateConditions'] });
      setShowDialog(false);
      setShowSuccessAlert(true);
      setTimeout(() => setShowSuccessAlert(false), 3000);
      resetForm();
    },
    onError: (error) => {
      console.error('Error updating condition:', error);
      toast.error('Erro ao atualizar condição. Tente novamente.');
    }
  });

  const bulkCreateMutation = useMutation({
    mutationFn: async (conditionsArray) => {
      console.log('Bulk creating conditions (with id_conta fallback):', conditionsArray);
      let accountId = null;
      try {
        const supplierList = await apiClient.entities.Supplier.filter({ id: user?.supplier_id });
        if (Array.isArray(supplierList) && supplierList.length > 0) {
          accountId = supplierList[0].id_conta || supplierList[0].account_id || null;
        }
      } catch (e) {
        console.warn('Não foi possível obter id_conta do fornecedor:', e);
      }
      return await apiClient.entities.StateCondition.bulkCreate(
        conditionsArray.map(c => ({
          ...c,
          supplier_id: user?.supplier_id,
          id_conta: accountId
        }))
      );
    },
    onSuccess: (data) => {
      console.log('Bulk create successful:', data);
      if (user?.supplier_id) {
        queryClient.invalidateQueries({ queryKey: ['supplierStateConditions', user.supplier_id] });
      } else {
        queryClient.invalidateQueries({ queryKey: ['supplierStateConditions'] });
      }
      queryClient.invalidateQueries({ queryKey: ['stateConditions'] });
      setShowReplicateDialog(false);
      setSelectedStates([]);
      setShowSuccessAlert(true);
      setTimeout(() => setShowSuccessAlert(false), 3000);
    },
    onError: (error) => {
      console.error('Error bulk creating:', error);
      toast.error('Erro ao replicar condições. Tente novamente.');
    }
  });

  const deleteConditionMutation = useMutation({
    mutationFn: (id) => {
      console.log('Deleting condition:', id);
      return apiClient.entities.StateCondition.delete(id);
    },
    onSuccess: () => {
      console.log('Condition deleted successfully');
      queryClient.invalidateQueries({ queryKey: ['supplierStateConditions'] });
      queryClient.invalidateQueries({ queryKey: ['stateConditions'] });
      setShowDeleteDialog(false);
      setConditionToDelete(null);
      toast.success('Condição excluída com sucesso!');
    },
    onError: (error) => {
      console.error('Error deleting condition:', error);
      toast.error('Erro ao excluir condição. Tente novamente.');
    }
  });

  const resetForm = () => {
    setFormData({
      state: "",
      cashback_percentage: 0,
      max_cashback_amount: 0, // NEW FIELD
      pedido_minimo: 0,
      pedido_minimo_frete_cif: 0,
      payment_term_days: 30,
      unit_price_adjustment: 0,
      catalog_url: "",
      notes: "",
      status: "active"
    });
    setEditingCondition(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingCondition) {
      updateConditionMutation.mutate({ id: editingCondition.id, data: formData });
    } else {
      createConditionMutation.mutate(formData);
    }
  };

  const handleEdit = (condition) => {
    setEditingCondition(condition);
    // Normaliza valores numéricos ao entrar no formulário para evitar strings
    setFormData({
      state: condition.state || '',
      cashback_percentage: parseFloat(condition.cashback_percentage ?? 0),
      max_cashback_amount: parseFloat(condition.max_cashback_amount ?? 0),
      pedido_minimo: parseFloat(condition.pedido_minimo ?? 0),
      pedido_minimo_frete_cif: parseFloat(condition.pedido_minimo_frete_cif ?? 0),
      payment_term_days: parseInt(condition.payment_term_days ?? 30),
      unit_price_adjustment: parseFloat(condition.unit_price_adjustment ?? 0),
      catalog_url: condition.catalog_url || '',
      notes: stripInactiveTag(condition.notes || ''),
      status: condition.status || 'active'
    });
    setShowDialog(true);
  };

  const handleReplicate = (condition) => {
    // Ao replicar, mantemos os campos relevantes mas limpamos o state
    setFormData({
      state: condition.state, // estado base mostrado no resumo
      cashback_percentage: parseFloat(condition.cashback_percentage || 0),
      max_cashback_amount: parseFloat(condition.max_cashback_amount || 0),
      pedido_minimo: parseFloat(condition.pedido_minimo || 0),
      pedido_minimo_frete_cif: parseFloat(condition.pedido_minimo_frete_cif || 0),
      payment_term_days: parseInt(condition.payment_term_days || 30),
      unit_price_adjustment: parseFloat(condition.unit_price_adjustment || 0),
      catalog_url: condition.catalog_url || '',
      notes: stripInactiveTag(condition.notes || ''),
      status: condition.status || 'active'
    });
    setSelectedStates([]);
    setShowReplicateDialog(true);
  };

  const handleDeleteClick = (condition) => {
    setConditionToDelete(condition);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (conditionToDelete) {
      deleteConditionMutation.mutate(conditionToDelete.id);
    }
  };

  const handleBulkReplicate = () => {
    const conditionsToCreate = selectedStates.map(state => ({
      state,
      cashback_percentage: parseFloat(formData.cashback_percentage || 0),
      max_cashback_amount: parseFloat(formData.max_cashback_amount || 0),
      pedido_minimo: parseFloat(formData.pedido_minimo || 0),
      pedido_minimo_frete_cif: parseFloat(formData.pedido_minimo_frete_cif || 0),
      payment_term_days: parseInt(formData.payment_term_days || 30),
      unit_price_adjustment: parseFloat(formData.unit_price_adjustment || 0),
      catalog_url: formData.catalog_url,
      notes: formData.notes,
      status: formData.status
    }));
    bulkCreateMutation.mutate(conditionsToCreate);
  };

  const toggleState = (state) => {
    if (selectedStates.includes(state)) {
      setSelectedStates(selectedStates.filter(s => s !== state));
    } else {
      setSelectedStates([...selectedStates, state]);
    }
  };

  const getUsedStates = () => {
    return conditions.map(c => c.state);
  };

  const availableStates = editingCondition 
    ? STATES 
    : STATES.filter(state => !getUsedStates().includes(state));

  return (
    <div className="p-6 lg:p-8">
      {showSuccessAlert && (
          <Alert className="mb-6 bg-green-50 border-green-200">
            <AlertDescription className="flex items-center gap-2 text-green-800">
              <CheckCircle className="h-4 w-4" />
              <strong>✅ Condição salva com sucesso!</strong>
            </AlertDescription>
          </Alert>
        )}
      <div className="max-w-9xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Condições por Estado</h1>
            <p className="text-gray-600">Configure condições comerciais específicas para cada estado</p>
          </div>
          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button 
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                disabled={availableStates.length === 0 && !editingCondition}
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Condição
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingCondition ? 'Editar Condição' : 'Criar Nova Condição por Estado'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <Alert>
                  <AlertDescription className="text-sm">
                    <strong>💡 Dica:</strong> Configure condições especiais para cada estado brasileiro. 
                    As condições serão aplicadas automaticamente aos pedidos das lojas daquele estado.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label>Estado (UF) *</Label>
                    <Select 
                      value={formData.state} 
                      onValueChange={(value) => setFormData({...formData, state: value})} 
                      required
                      // Permitimos alterar o estado durante a edição
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o estado" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableStates.map(state => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="col-span-2 border-t pt-4">
                    <h3 className="font-semibold mb-3 flex items-center gap-2">
                      <Percent className="w-4 h-4" />
                      Benefícios
                    </h3>
                  </div>

                  <div>
                    <Label>Cashback (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.cashback_percentage}
                      onChange={(e) => setFormData({...formData, cashback_percentage: parseFloat(e.target.value) || 0})}
                      placeholder="Ex: 10"
                    />
                    <p className="text-xs text-gray-500 mt-1">Percentual de cashback sobre o pedido</p>
                  </div>

                  <div>
                    <Label>Valor Máximo de Cashback (R$)</Label> {/* NEW INPUT */}
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.max_cashback_amount}
                      onChange={(e) => setFormData({...formData, max_cashback_amount: parseFloat(e.target.value) || 0})}
                      placeholder="Ex: 100.00"
                    />
                    <p className="text-xs text-gray-500 mt-1">Limite máximo de cashback em reais</p>
                  </div>

                  <div>
                    <Label>Pedido Mínimo (R$)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.pedido_minimo}
                      onChange={(e) => setFormData({...formData, pedido_minimo: parseFloat(e.target.value) || 0})}
                      placeholder="Ex: 500.00"
                    />
                    <p className="text-xs text-gray-500 mt-1">Valor mínimo por pedido para o estado</p>
                  </div>

                  <div>
                    <Label>Pedido Mínimo p/ Frete CIF (R$)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.pedido_minimo_frete_cif}
                      onChange={(e) => setFormData({...formData, pedido_minimo_frete_cif: parseFloat(e.target.value) || 0})}
                      placeholder="Ex: 1000.00"
                    />
                    <p className="text-xs text-gray-500 mt-1">Valor a partir do qual o frete é CIF</p>
                  </div>

                  <div className="col-span-2"> {/* Changed to col-span-2 as per outline */}
                    <Label>Prazo de Pagamento (dias) *</Label>
                    <Input
                      type="number"
                      value={formData.payment_term_days}
                      onChange={(e) => setFormData({...formData, payment_term_days: parseInt(e.target.value) || 30})}
                      required
                      placeholder="Ex: 45"
                    />
                    <p className="text-xs text-gray-500 mt-1">Prazo para pagamento em dias</p>
                  </div>

                  <div className="col-span-2 border-t pt-4">
                    <h3 className="font-semibold mb-3 flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      Ajustes de Preço
                    </h3>
                  </div>

                  <div className="col-span-2">
                    <Label>Ajuste por Unidade (R$)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.unit_price_adjustment}
                      onChange={(e) => setFormData({...formData, unit_price_adjustment: parseFloat(e.target.value) || 0})}
                      placeholder="Ex: 2.00 ou -1.50"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Acréscimo (+) ou desconto (-) por unidade
                    </p>
                  </div>

                  <div className="col-span-2 border-t pt-4">
                    <h3 className="font-semibold mb-3">Catálogo e Informações</h3>
                  </div>

                  <div className="col-span-2">
                    <Label>Link do Catálogo de Produtos</Label>
                    <Input
                      type="url"
                      value={formData.catalog_url}
                      onChange={(e) => setFormData({...formData, catalog_url: e.target.value})}
                      placeholder="https://exemplo.com/catalogo"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Link para catálogo digital ou promoções (visível para as lojas)
                    </p>
                  </div>

                  <div className="col-span-2">
                    <Label>Observações</Label>
                    <Textarea
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      rows={3}
                      placeholder="Informações adicionais sobre as condições..."
                    />
                  </div>

                  <div>
                    <Label>Status</Label>
                    <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Ativa</SelectItem>
                        <SelectItem value="inactive">Inativa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancelar
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-gradient-to-r from-blue-600 to-indigo-600"
                    disabled={createConditionMutation.isPending || updateConditionMutation.isPending}
                  >
                    {(createConditionMutation.isPending || updateConditionMutation.isPending)
                      ? 'Salvando...'
                      : editingCondition ? 'Salvar Alterações' : 'Criar Condição'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Alert className="mb-6 bg-blue-50 border-blue-200">
          <AlertDescription>
            <strong>Como funciona:</strong> Quando uma loja do estado configurado fizer um pedido, 
            as condições especiais serão aplicadas automaticamente (cashback, prazos, acréscimos, etc).
          </AlertDescription>
        </Alert>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : conditions.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="py-12 text-center text-gray-500">
              <MapPin className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg">Nenhuma condição configurada ainda</p>
              <p className="text-sm mt-2">Configure condições especiais por estado</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {conditions.map((condition) => (
              <Card key={condition.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="h-2 bg-gradient-to-r from-blue-500 to-indigo-500" />
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-lg flex items-center justify-center">
                        <MapPin className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="text-2xl font-bold">{condition.state}</CardTitle>
                        <p className="text-sm text-gray-500">Condições Especiais</p>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {condition.cashback_percentage > 0 && (
                      <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                        <span className="text-sm text-gray-600">Cashback:</span>
                        <span className="font-semibold text-green-600">
                          {condition.cashback_percentage}%
                          {Number(condition.max_cashback_amount) > 0 && (
                            <span className="text-xs text-gray-500 ml-1">
                              (máx: R$ {Number(condition.max_cashback_amount || 0).toFixed(2)})
                            </span>
                          )}
                        </span>
                      </div>
                    )}
                    {Number(condition.pedido_minimo) > 0 && (
                      <div className="flex items-center justify-between p-2 bg-amber-50 rounded">
                        <span className="text-sm text-gray-600">Pedido Mínimo:</span>
                        <span className="font-semibold text-amber-700">R$ {Number(condition.pedido_minimo || 0).toFixed(2)}</span>
                      </div>
                    )}
                    {Number(condition.pedido_minimo_frete_cif) > 0 && (
                      <div className="flex items-center justify-between p-2 bg-amber-50 rounded">
                        <span className="text-sm text-gray-600">Frete CIF a partir de:</span>
                        <span className="font-semibold text-amber-700">R$ {Number(condition.pedido_minimo_frete_cif || 0).toFixed(2)}</span>
                      </div>
                    )}
                    {condition.payment_term_days && (
                      <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                        <span className="text-sm text-gray-600">Prazo:</span>
                        <span className="font-semibold text-blue-600">{condition.payment_term_days} dias</span>
                      </div>
                    )}
                    {condition.unit_price_adjustment !== 0 && (
                      <div className="flex items-center justify-between p-2 bg-orange-50 rounded">
                        <span className="text-sm text-gray-600">Ajuste Unitário:</span>
                        <span className={`font-semibold ${Number(condition.unit_price_adjustment) > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                          R$ {Number(condition.unit_price_adjustment || 0).toFixed(2)}
                        </span>
                      </div>
                    )}
                    {condition.catalog_url && (
                      <div className="mt-3">
                        <Button
                          onClick={() => window.open(condition.catalog_url, '_blank')}
                          variant="outline"
                          size="sm"
                          className="w-full border-purple-300 text-purple-700 hover:bg-purple-50 hover:border-purple-400"
                        >
                          <Package className="w-4 h-4 mr-2" />
                          Ver Catálogo de Produtos
                          <ExternalLink className="w-3 h-3 ml-auto" />
                        </Button>
                      </div>
                    )}
                    {condition.notes && (
                      <div className="text-xs text-gray-600 border-t pt-2">
                        {stripInactiveTag(condition.notes)}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t">
                    <Badge variant={condition.status === 'active' ? 'default' : 'secondary'}>
                      {condition.status === 'active' ? 'Ativa' : 'Inativa'}
                    </Badge>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleReplicate(condition)}
                        title="Replicar para outros estados"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(condition)}
                        title="Editar condição"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteClick(condition)}
                        title="Excluir condição"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Delete Confirmation Dialog */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Confirmar Exclusão</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                Tem certeza que deseja excluir a condição para o estado <strong>{conditionToDelete?.state}</strong>?
              </p>
              <Alert className="bg-amber-50 border-amber-200">
                <AlertDescription className="text-sm text-amber-800">
                  ⚠️ Esta ação não pode ser desfeita. As lojas deste estado perderão as condições especiais configuradas.
                </AlertDescription>
              </Alert>
              <div className="flex justify-end gap-3 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowDeleteDialog(false)}
                  disabled={deleteConditionMutation.isPending}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={confirmDelete}
                  disabled={deleteConditionMutation.isPending}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {deleteConditionMutation.isPending ? 'Excluindo...' : 'Excluir'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Replicate Dialog */}
        <Dialog open={showReplicateDialog} onOpenChange={(open) => {
          setShowReplicateDialog(open);
          if (!open) setSelectedStates([]); // Clear selected states when dialog closes
        }}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Replicar Condições para Outros Estados</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription className="text-sm">
                  Selecione os estados que receberão as mesmas condições configuradas.
                </AlertDescription>
              </Alert>

              <div>
                <Label className="mb-3 block">Estados Disponíveis (não configurados):</Label>
                <div className="grid grid-cols-4 gap-2 max-h-64 overflow-y-auto p-2 border rounded-lg bg-white">
                  {STATES.filter(s => !getUsedStates().includes(s)).length === 0 && (
                    <p className="col-span-4 text-xs text-gray-500">Todos os estados já possuem condição.</p>
                  )}
                  {STATES.filter(s => !getUsedStates().includes(s)).map(state => {
                    const active = selectedStates.includes(state);
                    return (
                      <button
                        type="button"
                        key={state}
                        onClick={() => toggleState(state)}
                        className={`flex items-center justify-center px-2 py-1 text-sm rounded border transition-colors
                          ${active ? 'bg-blue-600 text-white border-blue-600' : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-300'}`}
                      >
                        {state}
                      </button>
                    );
                  })}
                </div>
                {selectedStates.length > 0 && (
                  <p className="mt-2 text-xs text-blue-600">{selectedStates.length} estado(s) selecionado(s).</p>
                )}
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm font-semibold mb-2 flex items-center gap-2">
                  <Copy className="w-4 h-4" /> Resumo da replicação
                </p>
                <div className="space-y-1 text-sm text-gray-600">
                  {formData.state && <p>• Condição origem: {formData.state}</p>}
                  {selectedStates.length > 0 && (
                    <p>• Destinos: {selectedStates.join(', ')}</p>
                  )}
                  {formData.cashback_percentage > 0 && (
                    <p>• Cashback: {formData.cashback_percentage}%{Number(formData.max_cashback_amount) > 0 && (
                      <span> (máx: R$ {Number(formData.max_cashback_amount || 0).toFixed(2)})</span>
                    )}</p>
                  )}
                    {Number(formData.pedido_minimo) > 0 && (
                      <p>• Pedido mínimo: R$ {Number(formData.pedido_minimo || 0).toFixed(2)}</p>
                    )}
                    {Number(formData.pedido_minimo_frete_cif) > 0 && (
                      <p>• CIF a partir de: R$ {Number(formData.pedido_minimo_frete_cif || 0).toFixed(2)}</p>
                    )}
                  <p>• Prazo de Pagamento: {formData.payment_term_days} dias</p>
                  <p>• Ajuste unitário: R$ {Number(formData.unit_price_adjustment || 0).toFixed(2)}</p>
                  {formData.catalog_url && <p>• Catálogo: {formData.catalog_url}</p>}
                  {formData.notes && <p>• Observações: {formData.notes}</p>}
                  <p>• Status: {formData.status === 'active' ? 'Ativa' : 'Inativa'}</p>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowReplicateDialog(false);
                    setSelectedStates([]);
                  }}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleBulkReplicate}
                  disabled={selectedStates.length === 0 || bulkCreateMutation.isPending}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600"
                >
                  {bulkCreateMutation.isPending 
                    ? 'Replicando...' 
                    : `Replicar para ${selectedStates.length} ${selectedStates.length === 1 ? 'Estado' : 'Estados'}`}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
