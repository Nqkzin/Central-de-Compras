import React, { useState, useEffect } from "react";
import { apiClient } from "@/services/apiClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ShoppingCart, Package, Store, Calendar, ChevronRight, Check, XCircle } from "lucide-react";
import { toast } from 'sonner';
import { format } from "date-fns";

const STATUS_CONFIG = {
  pending: { label: 'Pendente', color: 'bg-yellow-100 text-yellow-800' },
  processing: { label: 'Em Processamento', color: 'bg-blue-100 text-blue-800' },
  separated: { label: 'Separado', color: 'bg-purple-100 text-purple-800' },
  shipped: { label: 'Enviado', color: 'bg-indigo-100 text-indigo-800' },
  delivered: { label: 'Entregue', color: 'bg-green-100 text-green-800' },
  cancelled: { label: 'Cancelado', color: 'bg-red-100 text-red-800' },
};

export default function SupplierOrders() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [orderToCancel, setOrderToCancel] = useState(null);
  const [cancelling, setCancelling] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    let cancelled = false;
    const loadUser = async () => {
      try {
        const previewData = localStorage.getItem('preview_mode');
        if (previewData) {
          const preview = JSON.parse(previewData);
          if (preview.type === 'supplier' && preview.id) {
            // Buscar fornecedor para garantir ID consistente com backend (igual Dashboard)
            const suppliers = await apiClient.entities.Supplier.filter({ id: preview.id });
            if (!cancelled && suppliers[0]) {
              setUser({
                supplier_id: suppliers[0].id,
                user_type: 'supplier'
              });
            }
          }
        } else {
          const currentUser = await apiClient.auth.me();
          if (!cancelled) setUser(currentUser);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    loadUser();
    return () => { cancelled = true; };
  }, []);

  // Usa lista global e fallback específico para evitar divergências e tela branca
  const { data: allOrders, isLoading: allOrdersLoading } = useQuery({
    queryKey: ['orders'],
    queryFn: () => apiClient.entities.Order.list('-created_date'),
    initialData: [],
  });
  const { data: scopedOrders, isLoading: scopedLoading } = useQuery({
    queryKey: ['supplierOrdersScoped', user?.supplier_id],
    queryFn: () => apiClient.entities.Order.filter({ supplier_id: user?.supplier_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.supplier_id,
  });
  const supplierIdNorm = user?.supplier_id != null ? String(user.supplier_id) : null;
  let orders = (allOrders || []).filter(o => String(o.supplier_id) === supplierIdNorm);
  if (supplierIdNorm && orders.length === 0 && scopedOrders.length > 0) {
    orders = scopedOrders;
  }
  const ordersLoading = allOrdersLoading || scopedLoading;

  const { data: stores } = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiClient.entities.Store.list(),
    initialData: [],
  });

  // Estado para feedback visual do botão clicado
  const [updatingStatus, setUpdatingStatus] = useState(null);
  const [statusToastId, setStatusToastId] = useState(null);
  const [showInvoicePrompt, setShowInvoicePrompt] = useState(false);
  const [invoiceForm, setInvoiceForm] = useState({ numero_nota_fiscal: '', chave_nota_fiscal: '' });
  const [invoiceErrors, setInvoiceErrors] = useState({ numero_nota_fiscal: null, chave_nota_fiscal: null });

  // Mutation para cancelar pedido
  const cancelOrderMutation = useMutation({
    mutationFn: ({ id }) => apiClient.entities.Order.update(id, { status: 'cancelled' }),
    onMutate: async ({ id }) => {
      setCancelling(true);
      await Promise.all([
        queryClient.cancelQueries({ queryKey: ['orders'] }),
        queryClient.cancelQueries({ queryKey: ['supplierOrdersScoped', user?.supplier_id] })
      ]);

      const prevOrders = queryClient.getQueryData(['orders']);
      const prevScoped = queryClient.getQueryData(['supplierOrdersScoped', user?.supplier_id]);
      const applyOptimistic = (arr) => Array.isArray(arr) ? arr.map(o => o.id === id ? { ...o, status: 'cancelled' } : o) : arr;
      if (prevOrders) queryClient.setQueryData(['orders'], applyOptimistic(prevOrders));
      if (prevScoped) queryClient.setQueryData(['supplierOrdersScoped', user?.supplier_id], applyOptimistic(prevScoped));
      if (selectedOrder && selectedOrder.id === id) setSelectedOrder(s => s ? ({ ...s, status: 'cancelled' }) : s);

      return { prevOrders, prevScoped };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prevOrders) queryClient.setQueryData(['orders'], ctx.prevOrders);
      if (ctx?.prevScoped) queryClient.setQueryData(['supplierOrdersScoped', user?.supplier_id], ctx.prevScoped);
      toast.error('Erro ao cancelar pedido');
    },
    onSuccess: () => {
      toast.success('Pedido cancelado com sucesso');
    },
    onSettled: () => {
      setCancelling(false);
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['supplierOrdersScoped', user?.supplier_id] });
    }
  });

  const updateOrderMutation = useMutation({
    mutationFn: ({ id, data }) => apiClient.entities.Order.update(id, data),
    onMutate: async ({ id, data }) => {
      setUpdatingStatus(data.status);
      const tid = toast.loading('Atualizando status...');
      setStatusToastId(tid);
      // Cancelar refetches para evitar conflito durante otimista
      await Promise.all([
        queryClient.cancelQueries({ queryKey: ['orders'] }),
        queryClient.cancelQueries({ queryKey: ['supplierOrdersScoped', user?.supplier_id] })
      ]);

      const prevOrders = queryClient.getQueryData(['orders']);
      const prevScoped = queryClient.getQueryData(['supplierOrdersScoped', user?.supplier_id]);

      const applyOptimistic = (arr) => Array.isArray(arr) ? arr.map(o => o.id === id ? { ...o, status: data.status } : o) : arr;
      if (prevOrders) {
        queryClient.setQueryData(['orders'], applyOptimistic(prevOrders));
      }
      if (prevScoped) {
        queryClient.setQueryData(['supplierOrdersScoped', user?.supplier_id], applyOptimistic(prevScoped));
      }
      if (selectedOrder && selectedOrder.id === id) {
        setSelectedOrder(s => s ? { ...s, status: data.status } : s);
      }

      return { prevOrders, prevScoped };
    },
    onError: (error, _vars, context) => {
      // Rollback otimista
      if (context?.prevOrders) {
        queryClient.setQueryData(['orders'], context.prevOrders);
      }
      if (context?.prevScoped) {
        queryClient.setQueryData(['supplierOrdersScoped', user?.supplier_id], context.prevScoped);
      }
      toast.error(error?.message || 'Falha ao atualizar status');
    },
    onSuccess: () => {
      // Invalidate ambas coleções para garantir dados consistentes
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['supplierOrdersScoped', user?.supplier_id] });
      toast.success('Status atualizado');
    },
    onSettled: () => {
      setUpdatingStatus(null);
      if (statusToastId) toast.dismiss(statusToastId);
      setStatusToastId(null);
    }
  });

  const getStoreName = (storeId) => {
    const store = stores.find(s => s.id === storeId);
    return store?.name || 'N/A';
  };

  const canCancel = (status) => !['shipped', 'delivered', 'cancelled'].includes(status);
  
  const handleCancelOrder = (orderId, status) => {
    if (!canCancel(status)) {
      toast.error('Não é possível cancelar este pedido');
      return;
    }
    setOrderToCancel(orderId);
    setShowCancelDialog(true);
  };

  const confirmCancelOrder = () => {
    if (!orderToCancel) return;
    cancelOrderMutation.mutate({ id: orderToCancel });
    setShowCancelDialog(false);
    setOrderToCancel(null);
  };

  const handleUpdateStatus = (orderId, newStatus) => {
    // Enforce front-end sequence (defensive) — backend also validates
    const sequence = ['pending', 'processing', 'separated', 'shipped', 'delivered'];
    const current = selectedOrder?.status;
    const currentIndex = sequence.indexOf(current);
    const nextIndex = sequence.indexOf(newStatus);
    if (currentIndex === -1 || nextIndex === -1) return;
    // Só permite avançar exatamente um passo ou cancelar explicitamente
    if (!(nextIndex === currentIndex + 1)) return;
    if (newStatus === 'separated') {
      setInvoiceForm({ numero_nota_fiscal: '', chave_nota_fiscal: '' });
      setShowInvoicePrompt(true);
    } else {
      updateOrderMutation.mutate({ id: orderId, data: { status: newStatus } });
    }
  };

  const filteredOrders = filterStatus === "all" 
    ? orders 
    : orders.filter(o => o.status === filterStatus);

  const orderStats = {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    processing: orders.filter(o => ['processing', 'separated'].includes(o.status)).length,
    shipped: orders.filter(o => o.status === 'shipped').length,
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Pedidos Recebidos</h1>
          <p className="text-gray-600">Gerencie os pedidos das lojas e atualize o status</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total de Pedidos</p>
                  <p className="text-2xl font-bold text-gray-900">{orderStats.total}</p>
                </div>
                <ShoppingCart className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Novos Pedidos</p>
                  <p className="text-2xl font-bold text-yellow-600">{orderStats.pending}</p>
                </div>
                <Package className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Em Processo</p>
                  <p className="text-2xl font-bold text-blue-600">{orderStats.processing}</p>
                </div>
                <Package className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Enviados</p>
                  <p className="text-2xl font-bold text-purple-600">{orderStats.shipped}</p>
                </div>
                <Package className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
            <div className="flex items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" />
                Lista de Pedidos ({filteredOrders.length})
              </CardTitle>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[200px]">
                  <span className="text-sm">
                    {filterStatus === 'all' && 'Todos os Status'}
                    {filterStatus === 'pending' && 'Pendentes'}
                    {filterStatus === 'processing' && 'Em Processamento'}
                    {filterStatus === 'separated' && 'Separados'}
                    {filterStatus === 'shipped' && 'Enviados'}
                    {filterStatus === 'delivered' && 'Entregues'}
                    {filterStatus === 'cancelled' && 'Cancelados'}
                  </span>
                </SelectTrigger>
                <SelectContent align="end" className="w-[200px]">
                  <SelectItem value="all">Todos os Status</SelectItem>
                  <SelectItem value="pending">Pendentes</SelectItem>
                  <SelectItem value="processing">Em Processamento</SelectItem>
                  <SelectItem value="separated">Separados</SelectItem>
                  <SelectItem value="shipped">Enviados</SelectItem>
                  <SelectItem value="delivered">Entregues</SelectItem>
                  <SelectItem value="cancelled">Cancelados</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {ordersLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : filteredOrders.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-lg">Nenhum pedido encontrado</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Pedido</TableHead>
                      <TableHead>Loja</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Valor Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.map((order) => (
                      <TableRow key={order.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="font-medium">#{order.id.slice(0, 8)}</div>
                          <div className="text-xs text-gray-500">
                            {order.items?.length || 0} itens
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Store className="w-4 h-4 text-gray-400" />
                            {getStoreName(order.store_id)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Calendar className="w-4 h-4" />
                            {format(new Date(order.created_date), 'dd/MM/yyyy')}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-semibold text-gray-900">
                            R$ {Number(order.total_amount || 0).toFixed(2)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={STATUS_CONFIG[order.status]?.color}>
                            {STATUS_CONFIG[order.status]?.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedOrder(order)}
                          >
                            <ChevronRight className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Gerenciar Pedido #{selectedOrder?.id.slice(0, 8)}</DialogTitle>
            </DialogHeader>
            {selectedOrder && (
              <div className="space-y-6">
                {/* ... rest of dialog content remains the same ... */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Loja</p>
                    <p className="font-semibold">{getStoreName(selectedOrder.store_id)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Data do Pedido</p>
                    <p className="font-semibold">
                      {format(new Date(selectedOrder.created_date), 'dd/MM/yyyy HH:mm')}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Status Atual</p>
                    <Badge className={STATUS_CONFIG[selectedOrder.status]?.color}>
                      {STATUS_CONFIG[selectedOrder.status]?.label}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Prazo de Pagamento</p>
                    <p className="font-semibold">{selectedOrder.payment_term_days || 30} dias</p>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Atualizar Status do Pedido</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      variant="outline"
                      onClick={() => handleUpdateStatus(selectedOrder.id, 'processing')}
                      disabled={selectedOrder.status !== 'pending' || updatingStatus !== null}
                      className="justify-start relative"
                    >
                      {updatingStatus === 'processing' ? (
                        <span className="flex items-center"><span className="mr-2 animate-spin w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full" />Atualizando...</span>
                      ) : (
                        <><Check className="w-4 h-4 mr-2" />Marcar como Processando</>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleUpdateStatus(selectedOrder.id, 'separated')}
                      disabled={selectedOrder.status !== 'processing' || updatingStatus !== null}
                      className="justify-start relative"
                    >
                      {updatingStatus === 'separated' ? (
                        <span className="flex items-center"><span className="mr-2 animate-spin w-4 h-4 border-2 border-purple-500 border-t-transparent rounded-full" />Atualizando...</span>
                      ) : (
                        <><Check className="w-4 h-4 mr-2" />Marcar como Separado</>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleUpdateStatus(selectedOrder.id, 'shipped')}
                      disabled={selectedOrder.status !== 'separated' || updatingStatus !== null}
                      className="justify-start relative"
                    >
                      {updatingStatus === 'shipped' ? (
                        <span className="flex items-center"><span className="mr-2 animate-spin w-4 h-4 border-2 border-indigo-500 border-t-transparent rounded-full" />Atualizando...</span>
                      ) : (
                        <><Check className="w-4 h-4 mr-2" />Marcar como Enviado</>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleUpdateStatus(selectedOrder.id, 'delivered')}
                      disabled={selectedOrder.status !== 'shipped' || updatingStatus !== null}
                      className="justify-start relative"
                    >
                      {updatingStatus === 'delivered' ? (
                        <span className="flex items-center"><span className="mr-2 animate-spin w-4 h-4 border-2 border-green-500 border-t-transparent rounded-full" />Atualizando...</span>
                      ) : (
                        <><Check className="w-4 h-4 mr-2" />Marcar como Entregue</>
                      )}
                    </Button>
                  </div>
                </div>

                {(selectedOrder.numero_nota_fiscal || selectedOrder.chave_nota_fiscal) && (
                  <div className="bg-purple-50 border border-purple-100 rounded p-3">
                    <p className="text-sm text-gray-700 font-semibold mb-2">Nota Fiscal</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                      <div className="min-w-0 flex items-center">
                        <span className="text-gray-500">Número:</span>
                        <span className="ml-2 font-mono px-2 py-0.5 bg-white border rounded text-xs truncate max-w-[220px] md:max-w-[260px]" title={selectedOrder.numero_nota_fiscal || ''}>
                          {selectedOrder.numero_nota_fiscal || '-'}
                        </span>
                      </div>
                      <div className="min-w-0 flex items-center">
                        <span className="text-gray-500">Chave:</span>
                        <span className="ml-2 font-mono px-2 py-0.5 bg-white border rounded text-xs truncate max-w-[220px] md:max-w-[260px]" title={selectedOrder.chave_nota_fiscal || ''}>
                          {selectedOrder.chave_nota_fiscal ? `${selectedOrder.chave_nota_fiscal.slice(0,6)}…${selectedOrder.chave_nota_fiscal.slice(-6)}` : '-'}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                <div>
                  <h3 className="font-semibold mb-3">Itens do Pedido</h3>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produto</TableHead>
                          <TableHead>Qtd</TableHead>
                          <TableHead>Preço Unit.</TableHead>
                          <TableHead>Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedOrder.items?.map((item, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{item.product_name}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>R$ {Number(item.unit_price || 0).toFixed(2)}</TableCell>
                            <TableCell className="font-semibold">
                              R$ {Number(item.total || 0).toFixed(2)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal:</span>
                    <span className="font-semibold">R$ {Number(selectedOrder.subtotal || 0).toFixed(2)}</span>
                  </div>
                  {selectedOrder.additional_amount > 0 && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Acréscimos:</span>
                      <span className="font-semibold text-orange-600">
                        R$ {Number(selectedOrder.additional_amount || 0).toFixed(2)}
                      </span>
                    </div>
                  )}
                  {selectedOrder.cashback_amount > 0 && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Cashback para Loja:</span>
                      <span className="font-semibold text-green-600">
                        R$ {Number(selectedOrder.cashback_amount || 0).toFixed(2)}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold border-t pt-2">
                    <span>Total:</span>
                    <span className="text-blue-600">
                      R$ {Number(selectedOrder.total_amount || 0).toFixed(2)}
                    </span>
                  </div>
                </div>

                {selectedOrder.notes && (
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Observações da Loja</p>
                    <p className="text-sm bg-gray-50 p-3 rounded">{selectedOrder.notes}</p>
                  </div>
                )}

                <div className="flex justify-between flex-col sm:flex-row gap-3 pt-6 border-t">
                  {canCancel(selectedOrder.status) && (
                    <Button
                      onClick={() => handleCancelOrder(selectedOrder.id, selectedOrder.status)}
                      disabled={cancelling}
                      className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white font-semibold shadow-sm disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      {cancelling ? (
                        <span className="flex items-center"><span className="mr-2 animate-spin w-4 h-4 border-2 border-white/70 border-t-transparent rounded-full" />Cancelando...</span>
                      ) : (
                        'Cancelar Pedido'
                      )}
                    </Button>
                  )}
                  <div className="flex justify-end gap-3 w-full sm:w-auto">
                    <Button variant="outline" onClick={() => setSelectedOrder(null)} className="w-full sm:w-auto">
                      Fechar
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={showInvoicePrompt} onOpenChange={(open) => { setShowInvoicePrompt(open); if (!open) setInvoiceErrors({ numero_nota_fiscal: null, chave_nota_fiscal: null }); }}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Informar Nota Fiscal</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div>
                <label className="text-sm text-gray-700">Número da NF (opcional)</label>
                <input
                  className="mt-1 w-full border rounded px-2 py-1"
                  value={invoiceForm.numero_nota_fiscal}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^0-9]/g,'').slice(0,9);
                    setInvoiceForm({ ...invoiceForm, numero_nota_fiscal: v });
                    setInvoiceErrors(err => ({ ...err, numero_nota_fiscal: v.length > 9 ? 'Máximo 9 dígitos' : null }));
                  }}
                  placeholder="Ex.: 123456789"
                />
                <p className="text-[11px] text-gray-500 mt-1">Até 9 dígitos</p>
                {invoiceErrors.numero_nota_fiscal && (
                  <p className="text-xs text-red-600 mt-1">{invoiceErrors.numero_nota_fiscal}</p>
                )}
              </div>
              <div>
                <label className="text-sm text-gray-700">Chave da NF-e (44 dígitos, opcional)</label>
                <input
                  className="mt-1 w-full border rounded px-2 py-1 font-mono"
                  value={invoiceForm.chave_nota_fiscal}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^0-9]/g,'').slice(0,44);
                    setInvoiceForm({ ...invoiceForm, chave_nota_fiscal: v });
                    const err = v.length > 0 && v.length !== 44 ? 'Deve conter exatamente 44 dígitos' : null;
                    setInvoiceErrors(er => ({ ...er, chave_nota_fiscal: err }));
                  }}
                  maxLength={44}
                  placeholder="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                />
                <div className="flex justify-between items-center">
                  <p className="text-[11px] text-gray-500 mt-1">Se disponível, informe agora; pode ser adicionado depois.</p>
                  <p className="text-[11px] text-gray-500 mt-1">{(invoiceForm.chave_nota_fiscal?.length||0)}/44</p>
                </div>
                {invoiceErrors.chave_nota_fiscal && (
                  <p className="text-xs text-red-600 mt-1">{invoiceErrors.chave_nota_fiscal}</p>
                )}
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setShowInvoicePrompt(false)}>Cancelar</Button>
                <Button onClick={() => {
                  if (!selectedOrder) return;
                  // Validate before submit
                  if (invoiceForm.chave_nota_fiscal && invoiceForm.chave_nota_fiscal.length !== 44) {
                    setInvoiceErrors(err => ({ ...err, chave_nota_fiscal: 'Deve conter exatamente 44 dígitos' }));
                    return;
                  }
                  setShowInvoicePrompt(false);
                  updateOrderMutation.mutate({
                    id: selectedOrder.id,
                    data: {
                      status: 'separated',
                      numero_nota_fiscal: invoiceForm.numero_nota_fiscal || null,
                      chave_nota_fiscal: invoiceForm.chave_nota_fiscal || null,
                    }
                  });
                }} disabled={!!invoiceErrors.chave_nota_fiscal || !!invoiceErrors.numero_nota_fiscal}>Confirmar e Separar</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Diálogo de confirmação de cancelamento */}
        <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Confirmar Cancelamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                Tem certeza que deseja cancelar este pedido? Esta ação não pode ser desfeita.
              </p>
              <div className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowCancelDialog(false);
                    setOrderToCancel(null);
                  }}
                  disabled={cancelling}
                >
                  Não, Manter Pedido
                </Button>
                <Button 
                  onClick={confirmCancelOrder}
                  disabled={cancelling}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  {cancelling ? 'Cancelando...' : 'Sim, Cancelar Pedido'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}