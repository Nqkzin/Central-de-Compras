
import React, { useState, useEffect } from "react";
import { apiClient } from "@/services/apiClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Package, Edit, Search, Tag, AlertCircle, Loader2, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { formatProductCode, capitalizeName, validateEAN13, formatEAN13 } from "@/components/utils/validators";
import AIDescriptionHelper from "@/components/AIDescriptionHelper";

const CATEGORIES = [
  "Alimentos e Bebidas",
  "Limpeza e Higiene",
  "Papelaria e Escritório",
  "Eletrônicos",
  "Vestuário",
  "Móveis e Decoração",
  "Ferramentas e Equipamentos",
  "Outros"
];

export default function SupplierProducts() {
  const [user, setUser] = useState(null);
  const [supplier, setSupplier] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [validationErrors, setValidationErrors] = useState({});
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    code: "",
    gtin: "",
    internal_code: "",
    codigo_referencia: "",
    category: "",
    price: 0,
    promotional_price: null,
    unit: "UN",
    stock_quantity: 0,
    image_url: "",
    status: "active"
  });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageInputMode, setImageInputMode] = useState('upload'); // 'upload' ou 'url'

  useEffect(() => {
    let cancelled = false;
    const loadUser = async () => {
      try {
        const previewData = localStorage.getItem('preview_mode');
        if (previewData) {
          const preview = JSON.parse(previewData);
            if (preview.type === 'supplier' && preview.id) {
              const supplierData = await apiClient.entities.Supplier.filter({ id: preview.id });
              if (!cancelled && supplierData[0]) {
                setSupplier(supplierData[0]);
                setUser({
                  supplier_id: supplierData[0].id, // garante ID consistente
                  user_type: 'supplier'
                });
              }
            }
        } else {
          const currentUser = await apiClient.auth.me();
          if (!cancelled) setUser(currentUser);
          if (currentUser?.supplier_id) {
            const supplierData = await apiClient.entities.Supplier.filter({ id: currentUser.supplier_id });
            if (!cancelled && supplierData[0]) {
              setSupplier(supplierData[0]);
            }
          }
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    loadUser();
    return () => { cancelled = true; };
  }, []);

  // Usar lista global de produtos + fallback filtrado para evitar divergência de IDs em preview
  const { data: allProducts, isLoading: allProductsLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => apiClient.entities.Product.list('-created_date'),
    initialData: [],
  });
  const { data: scopedProducts, isLoading: scopedLoading } = useQuery({
    queryKey: ['supplierProductsScoped', user?.supplier_id],
    queryFn: () => apiClient.entities.Product.filter({ supplier_id: user?.supplier_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.supplier_id,
  });
  const supplierIdNorm = user?.supplier_id != null ? String(user.supplier_id) : null;
  // Alguns registros podem vir com id_fornecedor em lugar de supplier_id dependendo da origem.
  let products = (allProducts || []).filter(p => {
    const pid = p.supplier_id != null ? p.supplier_id : p.id_fornecedor;
    return String(pid) === supplierIdNorm;
  });
  if (supplierIdNorm && products.length === 0 && scopedProducts.length > 0) {
    products = scopedProducts.filter(p => {
      const pid = p.supplier_id != null ? p.supplier_id : p.id_fornecedor;
      return String(pid) === supplierIdNorm;
    });
  }
  const isLoading = allProductsLoading || scopedLoading;

  const createProductMutation = useMutation({
    mutationFn: (productData) => apiClient.entities.Product.create({
      ...productData,
      supplier_id: user?.supplier_id
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['supplierProducts'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      setShowDialog(false);
      resetForm();
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: ({ id, data }) => apiClient.entities.Product.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['supplierProducts'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      setShowDialog(false);
      resetForm();
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      code: "",
      gtin: "",
      internal_code: "",
      codigo_referencia: "",
      category: "",
      price: 0,
      promotional_price: null,
      unit: "UN",
      stock_quantity: 0,
      image_url: "",
      status: "active"
    });
    setEditingProduct(null);
    setValidationErrors({});
    setUploadingImage(false);
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.name.trim()) {
      errors.name = "Nome do produto é obrigatório";
    }

    if (!formData.category) {
      errors.category = "Categoria é obrigatória";
    }

    if (!formData.price || formData.price <= 0) {
      errors.price = "Preço deve ser maior que zero";
    }

    if (formData.stock_quantity < 0) {
      errors.stock_quantity = "Estoque não pode ser negativo";
    }

    // If GTIN provided, validate 13 digits
    if (formData.gtin && !validateEAN13(formData.gtin)) {
      errors.gtin = "GTIN deve ter exatamente 13 números";
    }
    // If internal code provided, validate 8 numeric digits
    if (formData.internal_code) {
      const cleaned = String(formData.internal_code).replace(/\D/g, '');
      if (cleaned.length !== 8) {
        errors.internal_code = 'Código interno deve ter exatamente 8 números';
      }
    }
    // Validação do código referência
    if (formData.codigo_referencia) {
      const cleaned = String(formData.codigo_referencia).replace(/\D/g, '');
      if (cleaned.length > 10) {
        errors.codigo_referencia = 'Código referência deve ter no máximo 10 números';
      }
    }
    // Validação do preço promocional
    if (formData.promotional_price) {
      const promoPrice = Number(formData.promotional_price);
      const normalPrice = Number(formData.price);
      if (promoPrice >= normalPrice) {
        errors.promotional_price = 'Preço promocional deve ser menor que o preço normal';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    const dataToSave = {
      ...formData,
      name: capitalizeName(formData.name),
      description: formData.description.trim(),
      // prefer sending explicit gtin/internal_code/codigo_referencia
      gtin: formData.gtin || undefined,
      internal_code: formData.internal_code || undefined,
      codigo_referencia: formData.codigo_referencia || undefined,
      promotional_price: formData.promotional_price ? Number(formData.promotional_price) : null,
    };

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data: dataToSave });
    } else {
      createProductMutation.mutate(dataToSave);
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    // Map product to formData fields
    setFormData({
      name: product.name || '',
      description: product.description || '',
      code: product.code || '',
      gtin: product.gtin || '',
      internal_code: product.internal_code || '',
      codigo_referencia: product.codigo_referencia || '',
      category: product.category || '',
      price: product.price || 0,
      promotional_price: product.promotional_price || null,
      unit: product.unit || 'UN',
      stock_quantity: product.stock_quantity || 0,
      image_url: product.image_url || '',
      status: product.status || 'active'
    });
    setShowDialog(true);
  };

  const handleInputChange = (field, value) => {
    let formattedValue = value;

    if (field === 'code' || field === 'gtin') {
      formattedValue = formatEAN13(value);
    } else if (field === 'price' || field === 'stock_quantity') {
      formattedValue = value === '' ? 0 : parseFloat(value) || 0;
    }

    setFormData({ ...formData, [field]: formattedValue });

    if (validationErrors[field]) {
      setValidationErrors({ ...validationErrors, [field]: null });
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const result = await apiClient.integrations.Core.UploadFile({ file });
      setFormData({...formData, image_url: result.file_url});
    } catch (error) {
      console.error("Error uploading image:", error);
    } finally {
      setUploadingImage(false);
    }
  };

  const filteredProducts = products.filter(product =>
    product.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.code?.includes(searchTerm)
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (supplier && supplier.can_manage_products === false) {
    return (
      <div className="p-6 lg:p-8">
        <div className="max-w-9xl mx-auto">
          <Alert className="bg-yellow-50 border-yellow-200 mb-6">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <strong>⚠️ Permissão Restrita:</strong> Você não tem permissão para cadastrar ou editar produtos.
              Entre em contato com o administrador para solicitar acesso.
            </AlertDescription>
          </Alert>

          <Card className="border-none shadow-lg">
            <CardHeader className="border-b bg-gradient-to-r from-green-50 to-emerald-50">
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Catálogo de Produtos ({filteredProducts.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div>
              ) : filteredProducts.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Package className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p className="text-lg">Nenhum produto cadastrado ainda</p>
                  <p className="text-sm mt-2">Peça ao administrador para adicionar produtos.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produto</TableHead>
                        <TableHead>Código</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead>Preço</TableHead>
                        <TableHead>Estoque</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow key={product.id} className="hover:bg-gray-50">
                          <TableCell>
                            <div className="font-medium text-gray-900">{product.name}</div>
                            {product.description && (
                              <div className="text-xs text-gray-500 mt-1 truncate max-w-[200px]">
                                {product.description}
                              </div>
                            )}
                          </TableCell>
                          <TableCell>
                            <span className="text-sm text-gray-600 font-mono">{product.gtin || product.internal_code || product.code || '-'}</span>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="text-xs">
                              <Tag className="w-3 h-3 mr-1" />
                              {product.category}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="font-semibold text-gray-900">
                              R$ {Number(product.price || 0).toFixed(2)}
                            </div>
                            <div className="text-xs text-gray-500">
                              por {product.unit}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={product.stock_quantity > 0 ? "default" : "secondary"}>
                              {product.stock_quantity || 0} {product.unit}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                              {product.status === 'active' ? 'Ativo' : 'Inativo'}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Meus Produtos</h1>
            <p className="text-gray-600">Gerencie o catálogo de produtos oferecidos</p>
          </div>
          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                Novo Produto
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProduct ? 'Editar Produto' : 'Cadastrar Novo Produto'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label>Nome do Produto *</Label>
                    <Input
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="Ex: Café Torrado 500g"
                      className={validationErrors.name ? 'border-red-500' : ''}
                    />
                    {validationErrors.name && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.name}</p>
                    )}
                  </div>

                  <div className="col-span-2">
                    <Label>Foto do Produto</Label>
                    <div className="space-y-3">
                      {/* Abas para escolher modo */}
                      <div className="flex gap-2 border-b">
                        <button
                          type="button"
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            imageInputMode === 'upload'
                              ? 'text-blue-600 border-b-2 border-blue-600'
                              : 'text-gray-500 hover:text-gray-700'
                          }`}
                          onClick={() => setImageInputMode('upload')}
                        >
                          Upload de Arquivo
                        </button>
                        <button
                          type="button"
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            imageInputMode === 'url'
                              ? 'text-blue-600 border-b-2 border-blue-600'
                              : 'text-gray-500 hover:text-gray-700'
                          }`}
                          onClick={() => setImageInputMode('url')}
                        >
                          URL da Imagem
                        </button>
                      </div>

                      {/* Input baseado no modo selecionado */}
                      {imageInputMode === 'upload' ? (
                        <div className="space-y-2">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            disabled={uploadingImage}
                          />
                          <p className="text-xs text-gray-500">
                            Formatos: JPG, PNG ou WebP. Tamanho recomendado: 800x800px
                          </p>
                          {uploadingImage && (
                            <div className="flex items-center gap-2 text-sm text-blue-600">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              Fazendo upload...
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Input
                            type="url"
                            placeholder="https://exemplo.com/produto.jpg"
                            value={formData.image_url}
                            onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                          />
                          <p className="text-xs text-gray-500">
                            Cole a URL completa da imagem (ex: de um repositório online, CDN, etc.)
                          </p>
                        </div>
                      )}

                      {/* Preview da imagem */}
                      {formData.image_url && !uploadingImage && (
                        <div className="relative inline-block">
                          <img 
                            src={formData.image_url} 
                            alt="Preview" 
                            className="w-32 h-32 object-cover rounded-lg border"
                            onError={(e) => {
                              e.target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100"%3E%3Crect fill="%23ddd" width="100" height="100"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%23999" font-size="14"%3EImagem inválida%3C/text%3E%3C/svg%3E';
                            }}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow"
                            onClick={() => setFormData({...formData, image_url: ""})}
                          >
                            <XCircle className="w-4 h-4 text-red-600" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label>GTIN (EAN-13)</Label>
                    <Input
                      value={formData.gtin}
                      onChange={(e) => handleInputChange('gtin', e.target.value)}
                      placeholder="7891234567890"
                      maxLength={13}
                      className={validationErrors.gtin ? 'border-red-500' : ''}
                    />
                    <p className="text-xs text-gray-500 mt-1">13 dígitos numéricos (opcional)</p>
                    {validationErrors.gtin && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.gtin}</p>
                    )}
                  </div>
                  <div>
                    <Label>Código Interno (8 dígitos)</Label>
                    <Input
                      value={formData.internal_code}
                      onChange={(e) => handleInputChange('internal_code', e.target.value)}
                      placeholder="00000001"
                      maxLength={8}
                      className={validationErrors.internal_code ? 'border-red-500' : ''}
                    />
                    <p className="text-xs text-gray-500 mt-1">8 dígitos numéricos (opcional)</p>
                    {validationErrors.internal_code && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.internal_code}</p>
                    )}
                  </div>
                  <div>
                    <Label>Código Referência</Label>
                    <Input
                      value={formData.codigo_referencia}
                      onChange={(e) => handleInputChange('codigo_referencia', e.target.value.replace(/\D/g, ''))}
                      placeholder="Código referência (opcional)"
                      maxLength={10}
                      className={validationErrors.codigo_referencia ? 'border-red-500' : ''}
                    />
                    {validationErrors.codigo_referencia && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.codigo_referencia}</p>
                    )}
                    {!validationErrors.codigo_referencia && (
                      <p className="text-xs text-gray-500 mt-1">Apenas números, máximo 10 dígitos (opcional)</p>
                    )}
                  </div>
                  <div>
                    <Label>Categoria *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => handleInputChange('category', value)}
                    >
                      <SelectTrigger className={validationErrors.category ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {CATEGORIES.map(cat => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {validationErrors.category && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.category}</p>
                    )}
                  </div>
                  <div>
                    <Label>Unidade</Label>
                    <Select value={formData.unit} onValueChange={(value) => handleInputChange('unit', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UN">Unidade (UN)</SelectItem>
                        <SelectItem value="CX">Caixa (CX)</SelectItem>
                        <SelectItem value="KG">Quilograma (KG)</SelectItem>
                        <SelectItem value="LT">Litro (LT)</SelectItem>
                        <SelectItem value="MT">Metro (MT)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Preço Unitário *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.price}
                      onChange={(e) => handleInputChange('price', e.target.value)}
                      placeholder="0.00"
                      className={validationErrors.price ? 'border-red-500' : ''}
                    />
                    {validationErrors.price && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.price}</p>
                    )}
                  </div>
                  <div>
                    <Label>Preço Promocional</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.promotional_price || ''}
                      onChange={(e) => handleInputChange('promotional_price', e.target.value)}
                      placeholder="Opcional"
                      className={validationErrors.promotional_price ? 'border-red-500' : ''}
                    />
                    {validationErrors.promotional_price && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.promotional_price}</p>
                    )}
                    {!validationErrors.promotional_price && (
                      <p className="text-xs text-gray-500 mt-1">Deixe vazio para usar o preço normal</p>
                    )}
                  </div>
                  <div>
                    <Label>Quantidade em Estoque</Label>
                    <Input
                      type="number"
                      min="0"
                      value={formData.stock_quantity}
                      onChange={(e) => handleInputChange('stock_quantity', e.target.value)}
                      placeholder="0"
                      className={validationErrors.stock_quantity ? 'border-red-500' : ''}
                    />
                    {validationErrors.stock_quantity && (
                      <p className="text-xs text-red-500 mt-1">{validationErrors.stock_quantity}</p>
                    )}
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Select value={formData.status} onValueChange={(value) => handleInputChange('status', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Ativo</SelectItem>
                        <SelectItem value="inactive">Inativo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2">
                    <Label>Descrição</Label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      rows={3}
                      placeholder="Descreva o produto..."
                    />
                    <div className="mt-2">
                      <AIDescriptionHelper
                        productName={formData.name}
                        type="product"
                        onSuggestionReceived={(description) => {
                          handleInputChange('description', description);
                        }}
                      />
                    </div>
                  </div>
                </div>

                {Object.keys(validationErrors).length > 0 && (
                  <Alert className="bg-red-50 border-red-200">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      Por favor, corrija os erros acima antes de continuar.
                    </AlertDescription>
                  </Alert>
                )}

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-green-600 to-emerald-600"
                    disabled={createProductMutation.isPending || updateProductMutation.isPending}
                  >
                    {(createProductMutation.isPending || updateProductMutation.isPending)
                      ? 'Salvando...'
                      : editingProduct ? 'Salvar Alterações' : 'Cadastrar Produto'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-green-50 to-emerald-50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Catálogo de Produtos ({filteredProducts.length})
              </CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar produtos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Package className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-lg">Nenhum produto cadastrado ainda</p>
                <p className="text-sm mt-2">Adicione produtos ao seu catálogo</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Produto</TableHead>
                      <TableHead>Código</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Preço</TableHead>
                      <TableHead>Estoque</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProducts.map((product) => (
                      <TableRow key={product.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {product.image_url && (
                              <img src={product.image_url} alt={product.name} className="w-10 h-10 object-cover rounded-md" />
                            )}
                            <div>
                              <div className="font-medium text-gray-900">{product.name}</div>
                              {product.description && (
                                <div className="text-xs text-gray-500 mt-1 truncate max-w-[200px]">
                                  {product.description}
                                </div>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-gray-600 font-mono">{product.gtin || product.internal_code || product.code || '-'}</span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            <Tag className="w-3 h-3 mr-1" />
                            {product.category}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {product.promotional_price && Number(product.promotional_price) > 0 ? (
                            <div>
                              <div className="flex items-center gap-1 mb-1">
                                <Badge variant="secondary" className="bg-green-100 text-green-700 text-[10px] px-1.5 py-0 h-4">
                                  PROMOÇÃO
                                </Badge>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-400 line-through">R$ {Number(product.price || 0).toFixed(2)}</span>
                                <span className="font-semibold text-green-600">R$ {Number(product.promotional_price).toFixed(2)}</span>
                              </div>
                              <div className="text-xs text-gray-500">por {product.unit}</div>
                            </div>
                          ) : (
                            <div>
                              <div className="font-semibold text-gray-900">
                                R$ {Number(product.price || 0).toFixed(2)}
                              </div>
                              <div className="text-xs text-gray-500">
                                por {product.unit}
                              </div>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant={product.stock_quantity > 0 ? "default" : "secondary"}>
                            {product.stock_quantity || 0} {product.unit}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                            {product.status === 'active' ? 'Ativo' : 'Inativo'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(product)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
