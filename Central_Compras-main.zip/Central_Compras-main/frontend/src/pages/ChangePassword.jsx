import React, { useState } from 'react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiClient } from '@/services/apiClient';

export default function ChangePassword() {
  const { mustChangePassword } = useAuth();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (next.length < 6) return toast.error('Nova senha deve ter ao menos 6 caracteres');
    if (next !== confirm) return toast.error('Confirmação não confere');
    setLoading(true);
    try {
      await apiClient.request('/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({
          current_password: mustChangePassword ? undefined : current,
          new_password: next,
        })
      });
      toast.success('Senha alterada. Faça login novamente.');
      // limpar flags e forçar re-login
      localStorage.removeItem('auth_token');
      localStorage.removeItem('must_change_password');
      window.location.href = '/login';
    } catch (e) {
      toast.error(e.message || 'Falha ao alterar senha');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 to-orange-100">
      <Card className="w-full max-w-md border-none shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-900">
            {mustChangePassword ? 'Defina sua nova senha' : 'Alterar Senha'}
          </CardTitle>
          <p className="text-gray-600 mt-2">
            {mustChangePassword ? 'Por segurança, é necessário alterar a senha no primeiro acesso.' : 'Atualize sua senha'}
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!mustChangePassword && (
              <div>
                <Input
                  type="password"
                  placeholder="Senha atual"
                  value={current}
                  onChange={(e) => setCurrent(e.target.value)}
                  required
                />
              </div>
            )}
            <div>
              <Input
                type="password"
                placeholder="Nova senha"
                value={next}
                onChange={(e) => setNext(e.target.value)}
                required
              />
            </div>
            <div>
              <Input
                type="password"
                placeholder="Confirmar nova senha"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600"
              disabled={loading}
            >
              {loading ? 'Salvando...' : 'Salvar Senha'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}