import React, { useState, useEffect } from "react";
import { apiClient } from "@/services/apiClient"; // Alterado para apiClient
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Store, MapPin, User, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  formatCEP, 
  formatPhone
} from "@/components/utils/validators";

const STATES = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"];

export default function StoreProfile() {
  const [user, setUser] = useState(null);
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    address: "",
    city: "",
    state: "",
    zip_code: "",
    responsible_name: "",
    responsible_email: "",
    responsible_phone: "",
  });
  const isReadOnly = !user || user.user_type === 'store';

  useEffect(() => {
    const loadData = async () => {
      try {
  const currentUser = await apiClient.auth.me(); // Alterado para apiClient
  setUser(currentUser);
        const overrideId = localStorage.getItem('active_store_id');
        let storeId = overrideId || currentUser?.store_id;
        if (!storeId && Array.isArray(currentUser?.store_ids) && currentUser.store_ids.length > 0) {
          storeId = String(currentUser.store_ids[0]);
          try { localStorage.setItem('active_store_id', storeId); } catch {}
        }

        if (storeId) {
          const storeData = await apiClient.entities.Store.filter({ id: storeId }); // Alterado para apiClient
          const storeInfo = storeData[0];
          if (storeInfo) {
            setStore(storeInfo);
            setFormData({
              address: storeInfo.address || "",
              city: storeInfo.city || "",
              state: storeInfo.state || "",
              zip_code: storeInfo.zip_code || "",
              responsible_name: storeInfo.responsible_name || "",
              responsible_email: storeInfo.responsible_email || "",
              responsible_phone: storeInfo.responsible_phone || "",
            });
          }
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) {
      return;
    }
  };

  const handleInputChange = (field, value) => {
    if (isReadOnly) {
      return;
    }
    let formattedValue = value;

    if (field === 'zip_code') {
      formattedValue = formatCEP(value);
    } else if (field === 'responsible_phone') {
      formattedValue = formatPhone(value);
    }

    setFormData({ ...formData, [field]: formattedValue });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-center">
          <p className="text-gray-600">Não foi possível carregar os dados da loja.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Meus Dados</h1>
          <p className="text-gray-600">Consulte as informações da sua loja</p>
        </div>

        {isReadOnly && (
          <Alert className="mb-6 bg-blue-50 border-blue-200">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-900">
              Alterações no cadastro são realizadas pelo time administrativo. Entre em contato com a central para solicitar ajustes.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="border-none shadow-lg">
            <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5" />
                Informações da Loja
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div>
                <p className="text-sm text-gray-500">Nome da Loja</p>
                <p className="font-semibold text-gray-900">{store.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">CNPJ</p>
                <p className="font-semibold text-gray-900">{store.cnpj}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Status</p>
                <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${
                  store.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {store.status === 'active' ? 'Ativa' : 'Inativa'}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2 border-none shadow-lg">
            <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
              <CardTitle>Detalhes da Loja</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Endereço
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Label>Endereço Completo</Label>
                      <Input
                        value={formData.address}
                        onChange={(e) => handleInputChange('address', e.target.value)}
                        placeholder="Rua, número, complemento"
                        disabled={isReadOnly}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>Nome Fantasia (visualização)</Label>
                      <Input value={store.name} disabled className="bg-gray-50" />
                      <p className="text-xs text-gray-500 mt-1">Campo somente leitura. Solicite a alteração ao time administrativo.</p>
                    </div>
                    <div>
                      <Label>Cidade</Label>
                      <Input
                        value={formData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        placeholder="Ex: São Paulo"
                        disabled={isReadOnly}
                      />
                    </div>
                    <div>
                      <Label>Estado</Label>
                      <Select value={formData.state} onValueChange={(value) => handleInputChange('state', value)} disabled={isReadOnly}>
                        <SelectTrigger disabled={isReadOnly}>
                          <span className="text-sm text-gray-700">
                            {formData.state || 'Selecione'}
                          </span>
                        </SelectTrigger>
                        <SelectContent>
                          {STATES.map(state => (
                            <SelectItem key={state} value={state}>{state}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>CEP</Label>
                      <Input
                        value={formData.zip_code}
                        onChange={(e) => handleInputChange('zip_code', e.target.value)}
                        placeholder="00000-000"
                        maxLength={9}
                        disabled={isReadOnly}
                      />
                    </div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Responsável
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Label>Nome Completo</Label>
                      <Input
                        value={formData.responsible_name}
                        onChange={(e) => handleInputChange('responsible_name', e.target.value)}
                        placeholder="Ex: João da Silva"
                        disabled={isReadOnly}
                      />
                    </div>
                    <div>
                      <Label>Email</Label>
                      <Input
                        type="email"
                        value={formData.responsible_email}
                        onChange={(e) => handleInputChange('responsible_email', e.target.value)}
                        placeholder="email@exemplo.com"
                        disabled={isReadOnly}
                      />
                    </div>
                    <div>
                      <Label>Telefone</Label>
                      <Input
                        value={formData.responsible_phone}
                        onChange={(e) => handleInputChange('responsible_phone', e.target.value)}
                        placeholder="(00) 00000-0000"
                        maxLength={15}
                        disabled={isReadOnly}
                      />
                    </div>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}