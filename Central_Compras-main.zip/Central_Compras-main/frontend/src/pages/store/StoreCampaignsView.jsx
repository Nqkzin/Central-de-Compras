import React, { useState, useEffect } from "react";
import { apiClient } from "@/services/apiClient"; // Alterado para apiClient
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Gift, DollarSign, Package, Calendar, ShoppingCart, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function StoreCampaignsView() {
  const [store, setStore] = useState(null);

  useEffect(() => {
    const loadStore = async () => {
      const currentUser = await apiClient.auth.me();
      if (currentUser?.store_id) {
        const storeData = await apiClient.entities.Store.filter({ id: currentUser.store_id });
        if (storeData[0]) setStore(storeData[0]);
      }
    };
    loadStore();
  }, []);

  const { data: campaigns, isLoading } = useQuery({
    queryKey: ['campaigns'],
    // Alinha com a aba do fornecedor: ordenar por início mais recente
    queryFn: () => apiClient.entities.Campaign.filter({ status: 'active' }, '-start_date'),
    initialData: [],
  });

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.list(), // Alterado para apiClient
    initialData: [],
  });

  const { data: orders } = useQuery({
    queryKey: ['orders'],
    queryFn: () => apiClient.entities.Order.list(),
    initialData: [],
  });

  const getSupplierName = (supplierId) => {
    return suppliers.find(s => s.id === supplierId)?.name || 'Fornecedor';
  };

  const getCampaignProgress = (campaign) => {
    // Prefer backend-provided progress for consistência global
    if (campaign?.progress && typeof campaign.progress.current === 'number') {
      const p = campaign.progress;
      return {
        mode: p.mode,
        current: p.current,
        target: p.target,
        remaining: Math.max(0, (p.target || 0) - (p.current || 0)),
        percent: Math.min(100, p.percent ?? 0),
        active: !!p.active
      };
    }
    // Fallback mínimo apenas para campanhas de valor (quantidades exigem items não retornados)
    if (campaign?.type === 'cashback_value') {
      const relevant = orders.filter(o => o.supplier_id === campaign.supplier_id && ['processing','separated','shipped','delivered'].includes(o.status));
      const sum = relevant.reduce((acc, o) => acc + Number(o.subtotal || 0), 0);
      const target = Number(campaign.min_value || 0);
      const percent = target > 0 ? Math.min(100, (sum / target) * 100) : 0;
      return { mode: 'value', current: sum, target, remaining: Math.max(0, target - sum), percent, active: target > 0 && sum >= target };
    }
    return { mode: null, current: 0, target: 0, remaining: 0, percent: 0, active: false };
  };

  const toMoney = (v) => Number(v || 0).toFixed(2);
  const daysLeft = (end) => {
    if (!end) return null;
    const diff = Math.ceil((new Date(end).getTime() - Date.now()) / (1000*60*60*24));
    return diff;
  };

  const isCampaignActive = (campaign) => {
    const now = new Date();
    const startDate = campaign.start_date ? new Date(campaign.start_date) : null;
    const endDate = campaign.end_date ? new Date(campaign.end_date) : null;
    
    if (startDate && now < startDate) return false; // Ainda não começou
    if (endDate && now > endDate) return false; // Já terminou
    
    return true;
  };

  const getCampaignIcon = (type) => {
    switch(type) {
      case 'cashback_value': return DollarSign;
      case 'cashback_quantity': return Package;
      case 'gift_quantity': return Gift;
      default: return TrendingUp;
    }
  };

  const getCampaignTypeLabel = (type) => {
    switch(type) {
      case 'cashback_value': return 'Cashback por Valor';
      case 'cashback_quantity': return 'Cashback por Quantidade';
      case 'gift_quantity': return 'Brinde por Quantidade';
      default: return type;
    }
  };

  const getStatusLabel = (status) => {
    const labels = { active: 'Ativa', inactive: 'Inativa' };
    return labels[status] || status;
  };

  // Normaliza URL de imagem como na tela do fornecedor
  const resolveImageUrl = (url) => {
    if (!url) return null;
    if (/^https?:\/\//i.test(url)) return url;
    return `http://localhost:3001${url.startsWith('/') ? '' : '/'}${url}`;
  };

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Campanhas e Promoções</h1>
          <p className="text-gray-600">Aproveite as promoções ativas dos fornecedores</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
          </div>
        ) : campaigns.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="py-12 text-center text-gray-500">
              <TrendingUp className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg">Nenhuma campanha ativa no momento</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {campaigns.map((campaign) => {
              const Icon = getCampaignIcon(campaign.type);
              const progress = getCampaignProgress(campaign);
              const supplier = suppliers.find(s => s.id === campaign.supplier_id);
              const remainingDays = daysLeft(campaign.end_date);
              const completed = progress && progress.progress >= 100;
              const isActive = isCampaignActive(campaign);
              const notStarted = campaign.start_date && new Date() < new Date(campaign.start_date);
              const expired = campaign.end_date && new Date() > new Date(campaign.end_date);

              const imageUrl = resolveImageUrl(campaign.image_url);
              return (
                <Card key={campaign.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                  {imageUrl && (
                    <img
                      src={imageUrl}
                      alt={campaign.name}
                      className="w-full h-32 object-cover rounded-t-lg"
                    />
                  )}
                  {!imageUrl && <div className="h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-t-lg" />}
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Icon className="w-6 h-6 text-purple-600" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <CardTitle className="text-lg truncate" title={campaign.name}>
                            {campaign.name}
                          </CardTitle>
                          <p className="text-xs text-gray-500 mt-1 truncate" title={getSupplierName(campaign.supplier_id)}>
                            {getSupplierName(campaign.supplier_id)}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    {campaign.description && (
                      <div className="mt-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-100">
                        <p className="text-sm text-gray-700 leading-relaxed" title={campaign.description}>
                          {campaign.description}
                        </p>
                      </div>
                    )}

                    <div className="mt-3 flex items-center gap-2 flex-wrap">
                      <Badge variant="secondary" className="w-fit">
                        {getCampaignTypeLabel(campaign.type)}
                      </Badge>
                      {completed && (
                        <Badge className="bg-green-100 text-green-700 border-green-200">Meta atingida</Badge>
                      )}
                      {typeof remainingDays === 'number' && (
                        <Badge className="bg-blue-50 text-blue-700 border-blue-200 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {remainingDays >= 0 ? `${remainingDays} dia(s) restantes` : 'Encerrada'}
                        </Badge>
                      )}
                      <Badge variant={campaign.status === 'active' ? 'default' : 'secondary'}>
                        {getStatusLabel(campaign.status)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">

                    <div className="space-y-2 text-sm">
                      {campaign.type === 'cashback_value' && (
                        <div className="space-y-2">
                          <div className="p-3 bg-amber-50 rounded-lg">
                            <div className="flex justify-between text-xs mb-2">
                              <span className="font-medium">Progresso Valor</span>
                              <span className="font-semibold">{progress.percent.toFixed(0)}%</span>
                            </div>
                            <div className="w-full bg-white rounded-full h-2">
                              <div className="bg-amber-500 h-2 rounded-full transition-all" style={{ width: `${progress.percent}%` }} />
                            </div>
                            <div className="flex justify-between text-[11px] mt-2 text-gray-600">
                              <span>R$ {toMoney(progress.current)}</span>
                              <span>Meta: R$ {toMoney(progress.target)}</span>
                            </div>
                          </div>
                          <div className="flex justify-between p-2 bg-green-50 rounded">
                            <span className="text-gray-600">Cashback:</span>
                            <span className="font-semibold text-green-600">{campaign.cashback_percentage}%</span>
                          </div>
                          {progress.active && (
                            <div className="text-xs text-emerald-700 bg-emerald-100 border border-emerald-200 rounded p-2">
                              Meta atingida — qualquer compra gera cashback.
                            </div>
                          )}
                        </div>
                      )}

                      {(campaign.type === 'cashback_quantity' || campaign.type === 'gift_quantity') && (
                        <div className="space-y-2">
                          <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                            <div className="flex justify-between text-xs mb-2">
                              <span className="font-medium">Progresso Quantidade</span>
                              <span className="font-semibold">{progress.percent.toFixed(0)}%</span>
                            </div>
                            <div className="w-full bg-white rounded-full h-2">
                              <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all" style={{ width: `${progress.percent}%` }} />
                            </div>
                            <div className="flex justify-between text-[11px] mt-2 text-gray-600">
                              <span>{progress.current}</span>
                              <span>Meta: {progress.target}</span>
                            </div>
                          </div>
                          {campaign.type === 'cashback_quantity' && (
                            <div className="flex justify-between p-2 bg-green-50 rounded">
                              <span className="text-gray-600">Cashback:</span>
                              <span className="font-semibold text-green-600">{campaign.cashback_percentage}%</span>
                            </div>
                          )}
                          {campaign.type === 'gift_quantity' && (
                            <div className="p-2 bg-yellow-50 rounded">
                              <span className="text-gray-600 text-xs">Brinde:</span>
                              <p className="font-semibold text-sm text-purple-600 mt-1" title={campaign.gift_description}>{campaign.gift_description}</p>
                            </div>
                          )}
                          {progress.active && (
                            <div className="text-xs text-emerald-700 bg-emerald-100 border border-emerald-200 rounded p-2">
                              Meta atingida — benefícios ativos.
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {(campaign.start_date || campaign.end_date) && (
                      <div className="text-xs text-gray-500 border-t pt-3 flex items-center gap-2 flex-wrap">
                        <Calendar className="w-3 h-3" />
                        {campaign.start_date && (
                          <span>Início: {new Date(campaign.start_date).toLocaleDateString('pt-BR')}</span>
                        )}
                        {campaign.end_date && (
                          <span>• Fim: {new Date(campaign.end_date).toLocaleDateString('pt-BR')}</span>
                        )}
                      </div>
                    )}

                    {notStarted && (
                      <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded p-2 flex items-center gap-2">
                        <Clock className="w-3 h-3" />
                        Campanha ainda não iniciada
                      </div>
                    )}

                    {expired && (
                      <div className="text-xs text-gray-600 bg-gray-50 border border-gray-200 rounded p-2">
                        Campanha encerrada
                      </div>
                    )}

                    <Link to={`${createPageUrl('StoreNewOrder')}?supplier_id=${campaign.supplier_id}`}>
                      <Button 
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                        disabled={!isActive}
                      >
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        {notStarted ? 'Aguardando Início' : expired ? 'Campanha Encerrada' : 'Fazer Pedido Agora'}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}