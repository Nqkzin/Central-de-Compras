import React, { useState, useEffect } from "react";
import { apiClient } from "@/services/apiClient"; // Alterado para apiClient
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Trash2, ShoppingCart, Package, AlertCircle, CheckCircle, Gift } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useNavigate } from "react-router-dom";
import { toast } from 'sonner';
import { createPageUrl } from "@/utils";

export default function StoreNewOrder() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const preSelectedSupplierId = urlParams.get('supplier_id');

  const [user, setUser] = useState(null);
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSupplierId, setSelectedSupplierId] = useState(preSelectedSupplierId || "");
  const [orderItems, setOrderItems] = useState([]);
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [success, setSuccess] = useState(false);
  const [showSupplierChangeWarning, setShowSupplierChangeWarning] = useState(false);
  const [pendingSupplierId, setPendingSupplierId] = useState(null);
  const activeStoreId = (typeof window !== 'undefined' && localStorage.getItem('active_store_id')) || null;

  // Safe currency formatter to handle strings/null and pt-BR format
  const toMoney = (value) => {
    if (value === null || value === undefined || value === "") return "0,00";
    let num;
    if (typeof value === "string") {
      const raw = value.toString().trim();
      if (raw.includes(",")) {
        const normalized = raw.replace(/\./g, "").replace(",", ".");
        num = Number(normalized);
      } else {
        num = Number(raw);
      }
    } else {
      num = Number(value);
    }
    if (!Number.isFinite(num)) return "0,00";
    return num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // Numeric normalizer for calculations
  const num = (v, fallback = 0) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  };

  // Helper para traduzir forma de pagamento
  const getPaymentMethodLabel = (method) => {
    const labels = {
      'boleto': 'Boleto Bancário',
      'pix': 'PIX',
      'cartao_credito': 'Cartão de Crédito',
      'cartao_debito': 'Cartão de Débito',
      'transferencia': 'Transferência Bancária',
      'dinheiro': 'Dinheiro',
      'cheque': 'Cheque',
      'outros': 'Outros'
    };
    return labels[method] || method;
  };

  useEffect(() => {
    const loadUserAndStore = async () => {
      try {
  const currentUser = await apiClient.auth.me(); // Alterado para apiClient
  setUser(currentUser);
  // Permitir sobrescrever via contexto ativo se existir (admin ou loja com múltiplas)
  const overrideId = localStorage.getItem('active_store_id');
  let effectiveStoreId = overrideId || currentUser?.store_id;
  // Fallback: se usuário tiver múltiplas lojas (store_ids) e nenhuma ativa definida, usar a primeira e salvar
  if (!effectiveStoreId && Array.isArray(currentUser?.store_ids) && currentUser.store_ids.length > 0) {
    effectiveStoreId = String(currentUser.store_ids[0]);
    try { localStorage.setItem('active_store_id', effectiveStoreId); } catch {}
  }
        if (effectiveStoreId) {
          const storeData = await apiClient.entities.Store.filter({ id: effectiveStoreId }); // Alterado para apiClient
          if (storeData[0]) {
            setStore(storeData[0]);
          }
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUserAndStore();
  }, []);

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.filter({ status: 'active' }), // Alterado para apiClient
    initialData: [],
  });

  const { data: products = [], isLoading: isLoadingProducts } = useQuery({
    queryKey: ['products', selectedSupplierId],
    queryFn: () => apiClient.entities.Product.filter({ 
      status: 'active', 
      supplier_id: selectedSupplierId ? String(selectedSupplierId) : undefined 
    }),
    enabled: !!selectedSupplierId,
    onError: (error) => {
      toast.error(`Erro ao carregar produtos: ${error?.message || 'Falha ao consultar a API.'}`);
    }
  });

  const { data: stateConditions } = useQuery({
    queryKey: ['stateConditions', selectedSupplierId, store?.state],
    queryFn: () => apiClient.entities.StateCondition.filter({ // Alterado para apiClient
      supplier_id: selectedSupplierId,
      state: store?.state,
      status: 'active'
    }),
    initialData: [],
    enabled: !!selectedSupplierId && !!store?.state,
  });

  const { data: campaigns } = useQuery({
    queryKey: ['campaigns', selectedSupplierId],
    queryFn: () => apiClient.entities.Campaign.filter({ // Alterado para apiClient
      supplier_id: selectedSupplierId,
      status: 'active'
    }),
    initialData: [],
    enabled: !!selectedSupplierId,
  });

  // Orders of the supplier to compute global campaign progress fallback (processed statuses only)
  const { data: supplierOrders = [] } = useQuery({
    queryKey: ['supplierOrdersForCampaignProgress', selectedSupplierId],
    queryFn: () => apiClient.entities.Order.filter({ supplier_id: selectedSupplierId }),
    initialData: [],
    enabled: !!selectedSupplierId,
  });

  // Helper: derive progress object similar to other pages (value campaigns global activation)
  const processedStatuses = new Set(['processing','separated','shipped','delivered']);
  const getCampaignProgress = (campaign) => {
    if (!campaign) return { mode: null, current: 0, target: 0, percent: 0, active: false };
    // Prefer backend-provided (vem do endpoint /api/campaigns com cálculo correto)
    if (campaign.progress && typeof campaign.progress.current === 'number') {
      return {
        mode: campaign.progress.mode,
        current: campaign.progress.current,
        target: campaign.progress.target,
        percent: Math.min(100, campaign.progress.percent || 0),
        active: !!campaign.progress.active
      };
    }
    // Fallback compute
    if (campaign.type === 'cashback_value') {
      const sum = supplierOrders
        .filter(o => processedStatuses.has(o.status))
        .reduce((acc, o) => acc + num(o.subtotal || o.total_amount || 0), 0);
      const target = num(campaign.min_value, 0);
      const percent = target > 0 ? Math.min(100, (sum / target) * 100) : 0;
      return { mode: 'value', current: sum, target, percent, active: target > 0 && sum >= target };
    }
    if (campaign.type === 'cashback_quantity' || campaign.type === 'gift_quantity') {
      let currentQty = 0;
      supplierOrders.filter(o => processedStatuses.has(o.status)).forEach(order => {
        (order.items || []).forEach(item => {
          if (String(item.product_id) === String(campaign.product_id)) {
            currentQty += num(item.quantity, 0);
          }
        });
      });
      const target = num(campaign.min_quantity, 0);
      const percent = target > 0 ? Math.min(100, (currentQty / target) * 100) : 0;
      return { mode: 'quantity', current: currentQty, target, percent, active: target > 0 && currentQty >= target };
    }
    return { mode: null, current: 0, target: 0, percent: 0, active: false };
  };

  const createOrderMutation = useMutation({
    mutationFn: (orderData) => apiClient.entities.Order.create(orderData), // Alterado para apiClient
    onSuccess: (created) => {
      // Semeia cache com o pedido criado para garantir exibição imediata do cashback e regra
      try {
        const newOrder = {
          ...created,
          // Compat: alguns campos podem vir undefined no retorno derivado; assegura defaults
          cashback_amount: Number(created?.cashback_amount || 0),
          subtotal: Number(created?.subtotal || 0),
          total_amount: Number(created?.total_amount || 0),
          created_date: created?.created_date || new Date().toISOString(),
          // Regra visual derivada dos diagnósticos do backend
          cashback_rule: created?.diagnostics?.cashback?.branch === 'campaign_priority'
            ? 'campaign'
            : (created?.diagnostics?.cashback?.branch === 'state_only' ? 'state' : undefined)
        };
        // Atualiza lista global
        const prevAll = queryClient.getQueryData(['orders']);
        if (Array.isArray(prevAll)) {
          queryClient.setQueryData(['orders'], [newOrder, ...prevAll]);
        }
        // Atualiza lista filtrada por loja
        if (store?.id) {
          const prevScoped = queryClient.getQueryData(['storeOrdersScoped', store.id]) || [];
          if (Array.isArray(prevScoped)) {
            queryClient.setQueryData(['storeOrdersScoped', store.id], [newOrder, ...prevScoped]);
          }
        }
      } catch {}
      // Revalida em seguida para sincronizar com backend
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      if (store?.id) queryClient.invalidateQueries({ queryKey: ['storeOrdersScoped', store.id] });

      toast.success('Pedido realizado com sucesso!');
      setSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl('StoreOrders'));
      }, 900);
    },
    onError: async (error) => {
      let msg = error?.message;
      // Se for resposta HTTP, tentar extrair body JSON { error }
      if (!msg && error?.response) {
        try {
          const data = await error.response.json();
          msg = data?.error || JSON.stringify(data);
        } catch (_) {}
      }
      toast.error(`Erro ao finalizar pedido: ${msg || 'Tente novamente mais tarde.'}`);
    }
  });

  const supplierProducts = (products || []).filter(
    p => String(p.supplier_id) === String(selectedSupplierId)
  );

  const handleSupplierChange = (newSupplierId) => {
    if (orderItems.length > 0 && newSupplierId !== selectedSupplierId) {
      setPendingSupplierId(newSupplierId);
      setShowSupplierChangeWarning(true);
    } else {
      setSelectedSupplierId(newSupplierId);
    }
  };

  const confirmSupplierChange = () => {
    setOrderItems([]);
    setNotes("");
    setSelectedSupplierId(pendingSupplierId);
    setShowSupplierChangeWarning(false);
    setPendingSupplierId(null);
  };

  const cancelSupplierChange = () => {
    setShowSupplierChangeWarning(false);
    setPendingSupplierId(null);
  };

  const addProduct = (product) => {
    // Verificar se o produto pertence a uma campanha
    const isCampaignProduct = (campaigns || []).some(c => 
      c.product_id && String(c.product_id) === String(product.id)
    );
    
    // Verificar se já existem produtos no carrinho
    if (orderItems.length > 0) {
      const hasNormalProducts = !orderItems.every(item => {
        return (campaigns || []).some(c => c.product_id && String(c.product_id) === String(item.product_id));
      });
      
      const hasOnlyCampaignProducts = orderItems.every(item => {
        return (campaigns || []).some(c => c.product_id && String(c.product_id) === String(item.product_id));
      });
      
      // Não permitir adicionar produto de campanha se já tem produtos normais
      if (isCampaignProduct && hasNormalProducts) {
        toast.error('Não é possível adicionar produtos de campanha junto com produtos normais. Finalize este pedido primeiro ou remova os itens.');
        return;
      }
      
      // Não permitir adicionar produto normal se já tem produtos de campanha
      if (!isCampaignProduct && hasOnlyCampaignProducts) {
        toast.error('Não é possível adicionar produtos normais junto com produtos de campanha. Finalize este pedido primeiro ou remova os itens.');
        return;
      }
    }
    
    const existing = orderItems.find(i => i.product_id === product.id);
    // Usar preço promocional se disponível, senão usar preço normal
    const unitPrice = product.promotional_price && Number(product.promotional_price) > 0 
      ? Number(product.promotional_price) 
      : Number(product.price) || 0;
    const available = Number(product.stock_quantity || 0);
    if (available <= 0) {
      toast.error('Produto sem estoque disponível');
      return;
    }
    if (existing) {
      if (existing.quantity + 1 > available) {
        toast.warning(`Limite atingido. Estoque disponível: ${available}.`);
        return;
      }
      setOrderItems(orderItems.map(item =>
        item.product_id === product.id
          ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * unitPrice, unit_price: unitPrice }
          : item
      ));
    } else {
      setOrderItems([...orderItems, {
        product_id: product.id,
        product_name: product.name,
        quantity: 1,
        unit_price: unitPrice,
        total: unitPrice
      }]);
    }
  };

  const updateQuantity = (productId, quantity) => {
    // Permite campo vazio temporariamente
    if (quantity === '' || quantity === null || quantity === undefined) {
      setOrderItems(orderItems.map(item =>
        item.product_id === productId
          ? { ...item, quantity: '', total: 0 }
          : item
      ));
      return;
    }
    
    const q = Number(quantity);
    if (isNaN(q) || q <= 0) return; // Não remove, apenas ignora
    
    const product = products.find(p => p.id === productId);
    const available = Number(product?.stock_quantity || 0);
    if (q > available) {
      toast.warning(`Máximo permitido para este produto: ${available}.`);
      return;
    }
    setOrderItems(orderItems.map(item =>
      item.product_id === productId
        ? { ...item, quantity: q, total: q * item.unit_price }
        : item
    ));
  };

  const removeProduct = (productId) => {
    setOrderItems(orderItems.filter(item => item.product_id !== productId));
  };

  const calculateSubtotal = () => {
    return orderItems.reduce((sum, item) => sum + item.total, 0);
  };

  const calculateOrderDetails = () => {
    const subtotal = calculateSubtotal();
    let additionalAmount = 0;
    let paymentTermDays = 30;
    const appliedCampaigns = [];
    const campaignInsights = []; // informações para UI sobre ativação retroativa
    const stateCondition = stateConditions[0];

    // Ajuste unitário / prazo sempre avaliados independentemente da prioridade de cashback
    if (stateCondition) {
      const adj = num(stateCondition.unit_price_adjustment, 0);
      if (adj !== 0) {
        const totalUnits = orderItems.reduce((sum, item) => sum + item.quantity, 0);
        additionalAmount = totalUnits * adj;
      }
      const prazo = num(stateCondition.payment_term_days, 30);
      if (prazo > 0) paymentTermDays = prazo;
    }

    // --- Calcular cashback de campanhas (soma das elegíveis) ---
    // Replica (simplificado) a lógica do backend: VALOR aplica sobre subtotal, QUANTIDADE sobre total do produto alvo
    // Campanhas de tipo gift_quantity não geram cashback
    const itemsMap = new Map();
    orderItems.forEach(it => {
      itemsMap.set(String(it.product_id), {
        qty: it.quantity,
        total: it.total
      });
    });
    
    // Helper: verificar se campanha está no período ativo
    const isCampaignActive = (campaign) => {
      const now = new Date();
      now.setHours(0, 0, 0, 0); // Zera horas para comparar apenas datas
      
      if (campaign.start_date) {
        const startDate = new Date(campaign.start_date);
        startDate.setHours(0, 0, 0, 0);
        if (now < startDate) return false; // Ainda não começou
      }
      
      if (campaign.end_date) {
        const endDate = new Date(campaign.end_date);
        endDate.setHours(0, 0, 0, 0);
        if (now > endDate) return false; // Já terminou (usa > porque queremos incluir o dia final)
      }
      
      return true;
    };
    
    let campaignCashback = 0;
    const giftCampaigns = []; // Array para armazenar campanhas de brinde ativas
    
    campaigns.forEach(c => {
      // Ignora campanhas fora do período
      if (!isCampaignActive(c)) return;
      
      const percent = num(c.cashback_percentage, 0) / 100;
      const prog = getCampaignProgress(c);
      let willActivate = false;
      let qualifiesNow = false;
      let predictedCashback = 0;
      
      if (c.type === 'cashback_value') {
        if (percent <= 0) return;
        const target = num(c.min_value, 0);
        const current = prog.current; // soma já processada
        const afterOrder = current + subtotal; // se este pedido for processado
        willActivate = !prog.active && target > 0 && afterOrder >= target;
        qualifiesNow = prog.active || subtotal >= target || willActivate; // retroativo se vai ativar
        if (qualifiesNow) {
          predictedCashback = subtotal * percent; // aplica sobre todo o subtotal
          campaignCashback += predictedCashback;
          appliedCampaigns.push(c.id);
        }
      } else if (c.type === 'cashback_quantity') {
        if (percent <= 0) return;
        const pid = c.product_id ? String(c.product_id) : null;
        const info = pid ? itemsMap.get(pid) : null;
        if (pid && info) {
          const targetQty = num(c.min_quantity, 0);
          const currentQty = prog.current;
          const afterQty = currentQty + info.qty;
          willActivate = !prog.active && targetQty > 0 && afterQty >= targetQty;
          qualifiesNow = prog.active || info.qty >= targetQty || willActivate;
          if (qualifiesNow) {
            predictedCashback = info.total * percent;
            campaignCashback += predictedCashback;
            appliedCampaigns.push(c.id);
          }
        }
      } else if (c.type === 'gift_quantity') {
        // Lógica para campanhas de brinde
        const pid = c.product_id ? String(c.product_id) : null;
        const info = pid ? itemsMap.get(pid) : null;
        if (pid && info) {
          const targetQty = num(c.min_quantity, 0);
          const currentQty = prog.current;
          const afterQty = currentQty + info.qty;
          willActivate = !prog.active && targetQty > 0 && afterQty >= targetQty;
          qualifiesNow = prog.active || info.qty >= targetQty || willActivate;
          if (qualifiesNow && c.gift_description) {
            giftCampaigns.push({
              id: c.id,
              name: c.name,
              gift_description: c.gift_description,
              willActivate
            });
            appliedCampaigns.push(c.id);
          }
        }
      }
      
      campaignInsights.push({
        id: c.id,
        name: c.name,
        type: c.type,
        active: prog.active,
        willActivate,
        qualifiesNow,
        percent: percent * 100,
        predictedCashback
      });
    });

    // --- Prioridade: se houver campanha com cashback (>0) ignora completamente a condição de estado ---
    let cashbackAmount = 0;
    if (campaignCashback > 0) {
      cashbackAmount = campaignCashback;
    } else if (stateCondition) {
      const perc = num(stateCondition.cashback_percentage, 0);
      if (perc > 0) {
        let stateCb = subtotal * (perc / 100);
        const maxCb = num(stateCondition.max_cashback_amount, 0);
        if (maxCb > 0 && stateCb > maxCb) stateCb = maxCb;
        cashbackAmount = stateCb;
      }
    }

    const totalAmount = subtotal + additionalAmount;
    return { subtotal, cashbackAmount, additionalAmount, totalAmount, paymentTermDays, appliedCampaigns, campaignInsights, giftCampaigns };
  };

  const handleSubmit = () => {
    // Validação de forma de pagamento
    if (!paymentMethod) {
      toast.error('Selecione a forma de pagamento antes de finalizar o pedido');
      return;
    }
    
    // Sempre resolver store_id diretamente do localStorage no momento do envio
    const overrideId = localStorage.getItem('active_store_id');
    const effectiveStoreId = overrideId || store?.id;
    if (!selectedSupplierId || orderItems.length === 0 || !effectiveStoreId) return;

    const details = calculateOrderDetails();
    
    // Helper: verificar se campanha está no período ativo
    const isCampaignActive = (campaign) => {
      const now = new Date();
      now.setHours(0, 0, 0, 0); // Zera horas para comparar apenas datas
      
      if (campaign.start_date) {
        const startDate = new Date(campaign.start_date);
        startDate.setHours(0, 0, 0, 0);
        if (now < startDate) return false; // Ainda não começou
      }
      
      if (campaign.end_date) {
        const endDate = new Date(campaign.end_date);
        endDate.setHours(0, 0, 0, 0);
        if (now > endDate) return false; // Já terminou (usa > porque queremos incluir o dia final)
      }
      
      return true;
    };
    
    // Verificar campanhas por quantidade e adicionar aos applied_campaigns
    const appliedCampaignIds = [...details.appliedCampaigns];
    
    campaigns.forEach(campaign => {
      // Só considera campanhas dentro do período
      if (!isCampaignActive(campaign)) return;
      
      if (campaign.type === 'cashback_quantity' || campaign.type === 'gift_quantity') {
        const productInOrder = orderItems.find(item => item.product_id === campaign.product_id);
        if (productInOrder && productInOrder.quantity >= campaign.min_quantity) {
          if (!appliedCampaignIds.includes(campaign.id)) {
            appliedCampaignIds.push(campaign.id);
          }
        }
      }
    });

    const orderData = {
      store_id: Number(effectiveStoreId),
      supplier_id: Number(selectedSupplierId),
      status: 'pending',
      items: orderItems,
      subtotal: details.subtotal,
      cashback_amount: details.cashbackAmount,
      additional_amount: details.additionalAmount,
      total_amount: details.totalAmount,
      payment_term_days: details.paymentTermDays,
      payment_method: paymentMethod || null,
      notes,
      applied_campaigns: appliedCampaignIds
    };

    createOrderMutation.mutate(orderData);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full border-none shadow-lg">
          <CardContent className="pt-12 pb-12 text-center">
            <AlertCircle className="w-16 h-16 mx-auto mb-4 text-red-500" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Erro</h2>
            <p className="text-gray-600 mb-6">Não foi possível carregar os dados da loja.</p>
            <Button onClick={() => navigate(createPageUrl('Dashboard'))}>
              Voltar ao Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const orderDetails = calculateOrderDetails();
  const stateCondition = stateConditions[0];

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full border-none shadow-lg">
          <CardContent className="pt-12 pb-12 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Pedido Realizado!</h2>
            <p className="text-gray-600 mb-6">Seu pedido foi enviado ao fornecedor com sucesso.</p>
            <Button onClick={() => navigate(createPageUrl('StoreOrders'))}>
              Ver Meus Pedidos
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Novo Pedido</h1>
          <p className="text-gray-600">Selecione o fornecedor e adicione produtos ao seu pedido</p>
        </div>

        {showSupplierChangeWarning && (
          <Alert className="mb-6 bg-yellow-50 border-yellow-200">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <strong>⚠️ Atenção!</strong> Você possui {orderItems.length} item(ns) no carrinho. 
              Ao trocar de fornecedor, o carrinho será esvaziado. Deseja continuar?
              <div className="flex gap-2 mt-3">
                <Button size="sm" variant="outline" onClick={cancelSupplierChange}>
                  Cancelar
                </Button>
                <Button size="sm" onClick={confirmSupplierChange} className="bg-yellow-600 hover:bg-yellow-700">
                  Sim, Trocar Fornecedor
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-none shadow-lg">
              <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardTitle>Selecionar Fornecedor</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <Select value={String(selectedSupplierId || "")} onValueChange={(v) => handleSupplierChange(v)}>
                  <SelectTrigger>
                    <span className="truncate text-sm text-gray-700">
                      {selectedSupplierId
                        ? (suppliers.find(s => String(s.id) === String(selectedSupplierId))?.name || 'Escolha um fornecedor')
                        : 'Escolha um fornecedor'}
                    </span>
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map(supplier => (
                      <SelectItem key={supplier.id} value={String(supplier.id)}>
                        {supplier.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedSupplierId && (
                  <Alert className="mt-4 bg-blue-50 border-blue-200">
                    <AlertDescription className="text-sm text-blue-800">
                      <strong>ℹ️ Informação:</strong> Você só pode adicionar produtos de um fornecedor por pedido. 
                      Para comprar de outro fornecedor, finalize este pedido primeiro.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {selectedSupplierId && (
              <Card className="border-none shadow-lg">
                <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
                  <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5" />
                    Produtos Disponíveis
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="max-h-96 overflow-y-auto">
                    {isLoadingProducts ? (
                      <div className="p-8 text-center text-gray-500">
                        Carregando produtos...
                      </div>
                    ) : supplierProducts.length === 0 ? (
                      <div className="p-8 text-center text-gray-500">
                        <Package className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Nenhum produto disponível</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Produto</TableHead>
                            <TableHead>Preço</TableHead>
                            <TableHead>Estoque</TableHead>
                            <TableHead>Ação</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {supplierProducts.map(product => {
                            const hasPromotion = product.promotional_price && Number(product.promotional_price) > 0;
                            const displayPrice = hasPromotion ? product.promotional_price : product.price;
                            return (
                            <TableRow key={product.id}>
                              <TableCell>
                                <div className="font-medium">{product.name}</div>
                                <div className="text-xs text-gray-500">{product.code}</div>
                              </TableCell>
                              <TableCell>
                                <div className="flex flex-col gap-1">
                                  {hasPromotion && (
                                    <div className="flex items-center gap-1">
                                      <Badge variant="secondary" className="bg-green-100 text-green-700 text-xs px-1.5 py-0">
                                        PROMOÇÃO
                                      </Badge>
                                    </div>
                                  )}
                                  <div className="flex items-center gap-2">
                                    {hasPromotion && (
                                      <span className="text-xs text-gray-400 line-through">R$ {toMoney(product.price)}</span>
                                    )}
                                    <span className={hasPromotion ? "font-semibold text-green-600" : ""}>
                                      R$ {toMoney(displayPrice)}/{product.unit}
                                    </span>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant={product.stock_quantity > 0 ? "default" : "secondary"}>
                                  {product.stock_quantity} {product.unit}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button
                                  size="sm"
                                  onClick={() => addProduct(product)}
                                  disabled={product.stock_quantity <= 0}
                                  className="gap-1"
                                >
                                  <ShoppingCart className="w-4 h-4" />
                                  Adicionar
                                </Button>
                              </TableCell>
                            </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="space-y-6">
            <Card className="border-none shadow-lg sticky top-6">
              <CardHeader className="border-b bg-gradient-to-r from-green-50 to-emerald-50">
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5" />
                  Carrinho ({orderItems.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-4">
                {orderItems.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <ShoppingCart className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Carrinho vazio</p>
                  </div>
                ) : (
                  <>
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      {orderItems.map(item => (
                        <div key={item.product_id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <p className="font-medium text-sm">{item.product_name}</p>
                            <p className="text-xs text-gray-500">R$ {toMoney(item.unit_price)}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              min="1"
                              max={products.find(p => p.id === item.product_id)?.stock_quantity || 1}
                              value={item.quantity}
                              onChange={(e) => updateQuantity(item.product_id, e.target.value)}
                              onBlur={(e) => {
                                // Ao sair do campo, se estiver vazio ou inválido, volta para 1
                                if (!e.target.value || parseInt(e.target.value) <= 0) {
                                  updateQuantity(item.product_id, 1);
                                }
                              }}
                              className="w-20 h-8 text-sm"
                            />
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeProduct(item.product_id)}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="border-t pt-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Subtotal:</span>
                        <span className="font-semibold">R$ {Number(orderDetails.subtotal || 0).toFixed(2)}</span>
                      </div>
                      {orderDetails.additionalAmount !== 0 && (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Acréscimo (Estado):</span>
                          <span className="font-semibold text-orange-600">
                            R$ {Number(orderDetails.additionalAmount || 0).toFixed(2)}
                          </span>
                        </div>
                      )}
                      {orderDetails.cashbackAmount > 0 && (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Cashback:</span>
                          <span className="font-semibold text-green-600">
                            R$ {Number(orderDetails.cashbackAmount || 0).toFixed(2)}
                            {num(stateCondition?.max_cashback_amount, 0) > 0 && (
                              <span className="text-xs text-gray-500 ml-1">
                                (máx: R$ {Number(stateCondition?.max_cashback_amount || 0).toFixed(2)})
                              </span>
                            )}
                          </span>
                        </div>
                      )}
                      {/* Exibição de brindes ganhos */}
                      {orderDetails.giftCampaigns && orderDetails.giftCampaigns.length > 0 && (
                        <div className="space-y-2 mt-2">
                          {orderDetails.giftCampaigns.map(gift => (
                            <div key={gift.id} className="bg-gradient-to-r from-emerald-50 to-green-50 border border-emerald-300 rounded-lg px-3 py-2">
                              <div className="flex items-center gap-2">
                                <Gift className="w-5 h-5 text-emerald-600" />
                                <div className="flex-1">
                                  <p className="text-sm font-semibold text-emerald-800">
                                    🎁 Brinde Ganho!
                                  </p>
                                  <p className="text-xs text-emerald-700 mt-0.5">
                                    {gift.gift_description}
                                  </p>
                                  {gift.willActivate && (
                                    <p className="text-[10px] text-emerald-600 mt-1">
                                      ⚠️ Este brinde será confirmado quando o fornecedor processar o pedido.
                                    </p>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      {/* Retroativo / previsão por campanha */}
                      {orderDetails.campaignInsights.filter(ci => ci.willActivate && !ci.active).length > 0 && (
                        <div className="space-y-1 mt-2">
                          {orderDetails.campaignInsights.filter(ci => ci.willActivate && !ci.active).map(ci => (
                            <div key={ci.id} className="flex justify-between text-xs bg-amber-50 border border-amber-200 rounded px-2 py-1">
                              <span className="text-amber-700 truncate" title={ci.name}>Ativará meta: {ci.name}</span>
                              <span className="font-semibold text-amber-700">Prev: R$ {Number(ci.predictedCashback || 0).toFixed(2)}</span>
                            </div>
                          ))}
                          <p className="text-[10px] text-amber-600 ml-1">Se o fornecedor processar este pedido, o cashback acima será confirmado.</p>
                        </div>
                      )}
                      <div className="flex justify-between text-lg font-bold border-t pt-2">
                        <span>Total:</span>
                        <span className="text-blue-600">R$ {Number(orderDetails.totalAmount || 0).toFixed(2)}</span>
                      </div>
                      <div className="text-xs text-gray-500">
                        Prazo: {orderDetails.paymentTermDays} dias
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm">Forma de Pagamento</Label>
                      <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                        <SelectTrigger>
                          <span className="truncate">
                            {paymentMethod ? getPaymentMethodLabel(paymentMethod) : 'Selecione a forma de pagamento'}
                          </span>
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="boleto">Boleto Bancário</SelectItem>
                          <SelectItem value="pix">PIX</SelectItem>
                          <SelectItem value="cartao_credito">Cartão de Crédito</SelectItem>
                          <SelectItem value="cartao_debito">Cartão de Débito</SelectItem>
                          <SelectItem value="transferencia">Transferência Bancária</SelectItem>
                          <SelectItem value="dinheiro">Dinheiro</SelectItem>
                          <SelectItem value="cheque">Cheque</SelectItem>
                          <SelectItem value="outros">Outros</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm">Observações</Label>
                      <Textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Informações adicionais sobre o pedido..."
                        rows={3}
                      />
                    </div>

                    <Button
                      onClick={handleSubmit}
                      className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                      disabled={createOrderMutation.isPending || !paymentMethod}
                    >
                      {createOrderMutation.isPending ? 'Processando...' : 'Finalizar Pedido'}
                    </Button>
                    {!paymentMethod && orderItems.length > 0 && (
                      <p className="text-xs text-amber-600 text-center">
                        Selecione a forma de pagamento para continuar
                      </p>
                    )}
                  </>
                )}
              </CardContent>
            </Card>

            {/* Compact progress overview for active supplier campaigns */}
            {selectedSupplierId && campaigns.length > 0 && (
              <Card className="border-none shadow-lg">
                <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-pink-50">
                  <CardTitle className="text-sm font-medium">Progresso das Campanhas</CardTitle>
                </CardHeader>
                <CardContent className="pt-4 space-y-3">
                  {campaigns.map(c => {
                    // Verificar se está no período ativo
                    const now = new Date();
                    now.setHours(0, 0, 0, 0);
                    
                    let isActive = true;
                    if (c.start_date) {
                      const startDate = new Date(c.start_date);
                      startDate.setHours(0, 0, 0, 0);
                      if (now < startDate) isActive = false;
                    }
                    if (c.end_date) {
                      const endDate = new Date(c.end_date);
                      endDate.setHours(0, 0, 0, 0);
                      if (now > endDate) isActive = false;
                    }
                    
                    if (!isActive) return null; // Não mostra campanhas fora do período
                    if (c.type !== 'cashback_value' && c.type !== 'cashback_quantity') return null;
                    
                    const prog = getCampaignProgress(c);
                    const label = c.type === 'cashback_value' ? 'Valor' : 'Quantidade';
                    return (
                      <div key={c.id} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-medium truncate" title={c.name}>{c.name}</span>
                          <span className="text-gray-600">{prog.percent.toFixed(0)}%</span>
                        </div>
                        <div className={`h-2 rounded bg-${c.type === 'cashback_value' ? 'amber' : 'purple'}-100`}>
                          <div
                            className={`h-2 rounded ${c.type === 'cashback_value' ? 'bg-amber-500' : 'bg-gradient-to-r from-purple-500 to-pink-500'}`}
                            style={{ width: `${prog.percent}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-gray-500">
                          <span>Atual: {c.type === 'cashback_value' ? 'R$ ' + num(prog.current,0).toFixed(2) : prog.current}</span>
                          <span>Meta: {c.type === 'cashback_value' ? 'R$ ' + num(prog.target,0).toFixed(2) : prog.target}</span>
                        </div>
                        {prog.active && (
                          <p className="text-[10px] text-emerald-700">Meta atingida — qualquer compra gera cashback.</p>
                        )}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            )}

            {stateConditions.length > 0 && stateConditions[0] && (
              <Alert className="bg-blue-50 border-blue-200">
                <AlertCircle className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-sm">
                  <strong>Condições para {store?.state}:</strong>
                  {num(stateConditions[0].cashback_percentage, 0) > 0 && (
                    <p>• Cashback: {num(stateConditions[0].cashback_percentage, 0)}%
                      {num(stateConditions[0].max_cashback_amount, 0) > 0 && (
                        <span className="text-xs"> (máx: R$ {Number(stateConditions[0].max_cashback_amount || 0).toFixed(2)})</span>
                      )}
                    </p>
                  )}
                  {stateConditions[0].payment_term_days && (
                    <p>• Prazo: {stateConditions[0].payment_term_days} dias</p>
                  )}
                  {num(stateConditions[0].unit_price_adjustment, 0) !== 0 && (
                    <p>• Ajuste unitário: R$ {Number(stateConditions[0].unit_price_adjustment || 0).toFixed(2)}</p>
                  )}
                </AlertDescription>
              </Alert>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}