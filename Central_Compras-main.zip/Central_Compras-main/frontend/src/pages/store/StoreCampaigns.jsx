import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/services/apiClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, Gift, DollarSign, Package, ShoppingCart, Clock, Calendar } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

// Página de campanhas para a LOJA baseada no layout do fornecedor, mas sem edição
export default function StoreCampaigns() {
  const navigate = useNavigate();
  const [openDetails, setOpenDetails] = React.useState(false);
  const [selected, setSelected] = React.useState(null);

  const { data: campaigns, isLoading } = useQuery({
    queryKey: ['storeCampaigns'],
    queryFn: () => apiClient.entities.Campaign.filter({ status: 'active' }, '-start_date'),
    initialData: [],
  });

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.list(),
    initialData: [],
  });

  // Orders para fallback de progresso quando necessário
  const { data: orders } = useQuery({
    queryKey: ['orders'],
    queryFn: () => apiClient.entities.Order.list(),
    initialData: [],
  });

  const { data: products } = useQuery({
    queryKey: ['products'],
    queryFn: () => apiClient.entities.Product.list(),
    initialData: [],
  });

  const getCampaignIcon = (type) => {
    switch(type) {
      case 'cashback_value': return DollarSign;
      case 'cashback_quantity': return Package;
      case 'gift_quantity': return Gift;
      default: return TrendingUp;
    }
  };

  const getCampaignTypeLabel = (type) => {
    const labels = {
      cashback_value: 'Cashback por Valor',
      cashback_quantity: 'Cashback por Quantidade',
      gift_quantity: 'Brinde por Quantidade',
    };
    return labels[type] || type;
  };

  const toMoney = (v) => Number(v || 0).toFixed(2);
  const daysLeft = (end) => {
    if (!end) return null;
    const diff = Math.ceil((new Date(end).getTime() - Date.now()) / (1000*60*60*24));
    return diff;
  };

  const getCampaignProgress = (campaign) => {
    if (campaign?.progress && typeof campaign.progress.percent === 'number') {
      const p = campaign.progress;
      return {
        mode: p.mode,
        current: p.current,
        target: p.target,
        remaining: Math.max(0, (p.target || 0) - (p.current || 0)),
        percent: Math.min(100, p.percent ?? 0),
        active: !!p.active,
      };
    }
    if (campaign?.type === 'cashback_value') {
      const relevant = orders.filter(o => o.supplier_id === campaign.supplier_id && ['processing','separated','shipped','delivered'].includes(o.status));
      const sum = relevant.reduce((acc, o) => acc + Number(o.subtotal || 0), 0);
      const target = Number(campaign.min_value || 0);
      const percent = target > 0 ? Math.min(100, (sum / target) * 100) : 0;
      return { mode: 'value', current: sum, target, remaining: Math.max(0, target - sum), percent, active: target > 0 && sum >= target };
    }
    return { mode: null, current: 0, target: 0, remaining: 0, percent: 0, active: false };
  };

  const resolveImageUrl = (url) => {
    if (!url) return null;
    if (/^https?:\/\//i.test(url)) return url;
    return `http://localhost:3001${url.startsWith('/') ? '' : '/'}${url}`;
  };

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Campanhas Ativas</h1>
            <p className="text-gray-600">Veja oportunidades de cashback e brindes antes de fazer seu pedido.</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-purple-600"></div>
          </div>
        ) : campaigns.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="py-12 text-center text-gray-500">
              <TrendingUp className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg">Nenhuma campanha ativa no momento</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {campaigns.map((campaign) => {
              const Icon = getCampaignIcon(campaign.type);
              const supplier = suppliers.find(s => s.id === campaign.supplier_id);
              const progress = getCampaignProgress(campaign);
              const remainingDays = daysLeft(campaign.end_date);
              const imageUrl = resolveImageUrl(campaign.image_url);
              return (
                <Card key={campaign.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                  {imageUrl && (
                    <img
                      src={imageUrl}
                      alt={campaign.name}
                      className="w-full h-32 object-cover rounded-t-lg"
                    />
                  )}
                  {!imageUrl && <div className="h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-t-lg" />}
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Icon className="w-6 h-6 text-purple-600" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <CardTitle className="text-lg truncate" title={campaign.name}>
                            {campaign.name}
                          </CardTitle>
                          <div className="mt-1 flex items-center gap-2 flex-wrap">
                            <Badge variant="secondary" className="w-fit">
                              {getCampaignTypeLabel(campaign.type)}
                            </Badge>
                            {progress?.active && (
                              <Badge className="bg-green-100 text-green-700 border-green-200">Meta atingida</Badge>
                            )}
                            {typeof remainingDays === 'number' && (
                              <Badge className="bg-blue-50 text-blue-700 border-blue-200">
                                <Clock className="w-3 h-3 mr-1 inline" />{remainingDays >= 0 ? `${remainingDays} dia(s) restantes` : 'Encerrada'}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-500 mt-1 truncate" title={supplier?.name}>
                            {supplier?.name}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {campaign.description && (
                      <p className="text-sm text-gray-600 line-clamp-3" title={campaign.description}>
                        {campaign.description}
                      </p>
                    )}

                    <div className="space-y-2 text-sm">
                      {campaign.type === 'cashback_value' && (
                        <div className="space-y-2">
                          <div className="p-3 bg-amber-50 rounded-lg">
                            <div className="flex justify-between text-xs mb-2">
                              <span className="font-medium">Progresso Valor</span>
                              <span className="font-semibold">{progress.percent.toFixed(0)}%</span>
                            </div>
                            <div className="w-full bg-white rounded-full h-2">
                              <div className="bg-amber-500 h-2 rounded-full transition-all" style={{ width: `${progress.percent}%` }} />
                            </div>
                            <div className="flex justify-between text-[11px] mt-2 text-gray-600">
                              <span>R$ {toMoney(progress.current)}</span>
                              <span>Meta: R$ {toMoney(progress.target)}</span>
                            </div>
                          </div>
                          <div className="flex justify-between p-2 bg-green-50 rounded">
                            <span className="text-gray-600">Cashback:</span>
                            <span className="font-semibold text-green-600">{campaign.cashback_percentage}%</span>
                          </div>
                          {progress.active && (
                            <div className="text-xs text-emerald-700 bg-emerald-100 border border-emerald-200 rounded p-2">
                              Meta atingida — qualquer compra gera cashback.
                            </div>
                          )}
                        </div>
                      )}

                      {(campaign.type === 'cashback_quantity' || campaign.type === 'gift_quantity') && (
                        <div className="space-y-2">
                          <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                            <div className="flex justify-between text-xs mb-2">
                              <span className="font-medium">Progresso Quantidade</span>
                              <span className="font-semibold">{progress.percent.toFixed(0)}%</span>
                            </div>
                            <div className="w-full bg-white rounded-full h-2">
                              <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all" style={{ width: `${progress.percent}%` }} />
                            </div>
                            <div className="flex justify-between text-[11px] mt-2 text-gray-600">
                              <span>{progress.current}</span>
                              <span>Meta: {progress.target}</span>
                            </div>
                          </div>
                          {campaign.type === 'cashback_quantity' && (
                            <div className="flex justify-between p-2 bg-green-50 rounded">
                              <span className="text-gray-600">Cashback:</span>
                              <span className="font-semibold text-green-600">{campaign.cashback_percentage}%</span>
                            </div>
                          )}
                          {campaign.type === 'gift_quantity' && (
                            <div className="p-2 bg-yellow-50 rounded">
                              <span className="text-gray-600 text-xs">Brinde:</span>
                              <p className="font-semibold text-sm text-purple-600 mt-1 line-clamp-2" title={campaign.gift_description}>{campaign.gift_description}</p>
                            </div>
                          )}
                          {progress.active && (
                            <div className="text-xs text-emerald-700 bg-emerald-100 border border-emerald-200 rounded p-2">
                              Meta atingida — benefícios ativos.
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {(campaign.start_date || campaign.end_date) && (
                      <div className="text-xs text-gray-500 border-t pt-3 flex items-center gap-2 flex-wrap">
                        <Calendar className="w-3 h-3" />
                        {campaign.start_date && <span>Início: {new Date(campaign.start_date).toLocaleDateString('pt-BR')}</span>}
                        {campaign.end_date && <span>• Fim: {new Date(campaign.end_date).toLocaleDateString('pt-BR')}</span>}
                      </div>
                    )}

                    <div className="flex gap-2 pt-2 border-t">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => navigate(`${createPageUrl('StoreNewOrder')}?supplier_id=${campaign.supplier_id}`)}
                      >
                        <ShoppingCart className="w-4 h-4 mr-1" /> Fazer Pedido
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                        onClick={() => { setSelected(campaign); setOpenDetails(true); }}
                      >
                        Detalhes
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <Dialog open={openDetails} onOpenChange={setOpenDetails}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{selected?.name || 'Detalhes da Campanha'}</DialogTitle>
            </DialogHeader>
            {selected && (
              <div className="space-y-3 text-sm">
                {selected.description && (
                  <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border-l-4 border-purple-500">
                    <p className="text-base text-gray-800 leading-relaxed">
                      {selected.description}
                    </p>
                  </div>
                )}
                
                <div className="flex items-center justify-between pt-2">
                  <span className="text-gray-500">Fornecedor</span>
                  <span className="font-medium">{suppliers.find(s => s.id === selected.supplier_id)?.name || '-'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-500">Tipo</span>
                  <span className="font-medium">{getCampaignTypeLabel(selected.type)}</span>
                </div>
                {/* Progresso dentro do modal */}
                {(() => {
                  const p = getCampaignProgress(selected);
                  if (selected.type === 'cashback_value') {
                    return (
                      <div className="space-y-2 mt-2">
                        <div className="p-3 bg-amber-50 rounded-lg">
                          <div className="flex justify-between text-xs mb-2">
                            <span className="font-medium">Progresso Valor</span>
                            <span className="font-semibold">{p.percent.toFixed(0)}%</span>
                          </div>
                          <div className="w-full bg-white rounded-full h-2">
                            <div className="bg-amber-500 h-2 rounded-full" style={{ width: `${p.percent}%` }} />
                          </div>
                          <div className="flex justify-between text-[11px] mt-2 text-gray-600">
                            <span>R$ {toMoney(p.current)}</span>
                            <span>Meta: R$ {toMoney(p.target)}</span>
                          </div>
                        </div>
                        {p.active && (
                          <div className="text-xs text-emerald-700 bg-emerald-100 border border-emerald-200 rounded p-2">
                            Meta atingida — qualquer compra gera cashback.
                          </div>
                        )}
                      </div>
                    );
                  }
                  if (selected.type === 'cashback_quantity' || selected.type === 'gift_quantity') {
                    return (
                      <div className="space-y-2 mt-2">
                        <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                          <div className="flex justify-between text-xs mb-2">
                            <span className="font-medium">Progresso Quantidade</span>
                            <span className="font-semibold">{p.percent.toFixed(0)}%</span>
                          </div>
                          <div className="w-full bg-white rounded-full h-2">
                            <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full" style={{ width: `${p.percent}%` }} />
                          </div>
                          <div className="flex justify-between text-[11px] mt-2 text-gray-600">
                            <span>{p.current}</span>
                            <span>Meta: {p.target}</span>
                          </div>
                        </div>
                        {p.active && (
                          <div className="text-xs text-emerald-700 bg-emerald-100 border border-emerald-200 rounded p-2">
                            Meta atingida — benefícios ativos.
                          </div>
                        )}
                      </div>
                    );
                  }
                  return null;
                })()}

                {selected.type === 'cashback_value' && (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">Valor Mínimo</span>
                      <span className="font-semibold">R$ {Number(selected.min_value || 0).toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">Cashback</span>
                      <span className="font-semibold text-green-600">{selected.cashback_percentage}%</span>
                    </div>
                  </>
                )}

                {(selected.type === 'cashback_quantity' || selected.type === 'gift_quantity') && (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">Produto</span>
                      <span className="font-medium">
                        {products.find(p => p.id === selected.product_id)?.name || `#${selected.product_id}`}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">Quantidade Mínima</span>
                      <span className="font-semibold">{selected.min_quantity}</span>
                    </div>
                  </>
                )}

                {selected.type === 'cashback_quantity' && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500">Cashback</span>
                    <span className="font-semibold text-green-600">{selected.cashback_percentage}%</span>
                  </div>
                )}

                {selected.type === 'gift_quantity' && selected.gift_description && (
                  <div>
                    <span className="text-gray-500 text-xs">Brinde</span>
                    <p className="font-medium mt-1">{selected.gift_description}</p>
                  </div>
                )}

                {(selected.start_date || selected.end_date) && (
                  <div className="text-xs text-gray-500 border-t pt-3">
                    {selected.start_date && <p>Início: {new Date(selected.start_date).toLocaleDateString('pt-BR')}</p>}
                    {selected.end_date && <p>Término: {new Date(selected.end_date).toLocaleDateString('pt-BR')}</p>}
                  </div>
                )}

                <Link to={`${createPageUrl('StoreNewOrder')}?supplier_id=${selected.supplier_id}`}>
                  <Button className="w-full mt-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    <ShoppingCart className="w-4 h-4 mr-2" /> Fazer Pedido Agora
                  </Button>
                </Link>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
