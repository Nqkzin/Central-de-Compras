import React, { useState, useEffect } from "react";
import { toast } from 'sonner';
import { apiClient } from "@/services/apiClient"; // Alterado para apiClient
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ShoppingCart, Package, Building2, Calendar, ChevronRight, Copy, Gift } from "lucide-react";
import { format } from "date-fns";

const STATUS_CONFIG = {
  pending: { label: 'Pendente', color: 'bg-yellow-100 text-yellow-800' },
  processing: { label: 'Em Processamento', color: 'bg-blue-100 text-blue-800' },
  separated: { label: 'Separado', color: 'bg-purple-100 text-purple-800' },
  shipped: { label: 'Enviado', color: 'bg-indigo-100 text-indigo-800' },
  delivered: { label: 'Entregue', color: 'bg-green-100 text-green-800' },
  cancelled: { label: 'Cancelado', color: 'bg-red-100 text-red-800' },
};

export default function StoreOrders() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [cancelling, setCancelling] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [orderToCancel, setOrderToCancel] = useState(null);
  const queryClient = useQueryClient();

  // Safe currency formatter to handle strings/null
  const toMoney = (value) => {
    const num = Number(value || 0);
    return num.toFixed(2);
  };

  // Helper para traduzir forma de pagamento
  const getPaymentMethodLabel = (method) => {
    const labels = {
      'boleto': 'Boleto Bancário',
      'pix': 'PIX',
      'cartao_credito': 'Cartão de Crédito',
      'cartao_debito': 'Cartão de Débito',
      'transferencia': 'Transferência Bancária',
      'dinheiro': 'Dinheiro',
      'cheque': 'Cheque',
      'outros': 'Outros'
    };
    return labels[method] || method || 'Não informado';
  };

  useEffect(() => {
    let cancelled = false;
    const loadUser = async () => {
      try {
        const currentUser = await apiClient.auth.me();
        if (!cancelled) setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    loadUser();
    return () => { cancelled = true; };
  }, []);

  // NOTE: Houve regressão na listagem filtrada via /orders?store_id=XXX.
  // Para maior robustez e evitar discrepâncias entre Dashboard (que usa lista completa)
  // e esta tela, passamos a reutilizar a mesma query global de pedidos e filtrar em memória.
  // Assim garantimos consistência enquanto investigamos possíveis diferenças no endpoint.
  const { data: allOrders, isLoading: allOrdersLoading } = useQuery({
    queryKey: ['orders'],
    queryFn: () => apiClient.entities.Order.list('-created_date'),
    initialData: [],
  });

  // Fallback: consulta específica caso filtragem local retorne vazia (possível falha em dados não carregados ainda)
  const overrideId = (typeof window !== 'undefined' && localStorage.getItem('active_store_id')) || null;
  const effectiveStoreId = overrideId || user?.store_id;

  const { data: storeScopedOrders, isLoading: scopedLoading } = useQuery({
    queryKey: ['storeOrdersScoped', effectiveStoreId],
    queryFn: () => apiClient.entities.Order.filter({ store_id: effectiveStoreId }, '-created_date'),
    initialData: [],
    enabled: !!effectiveStoreId,
  });

  // Normaliza IDs para evitar mismatch de tipo (string vs number)
  const storeIdNorm = effectiveStoreId != null ? String(effectiveStoreId) : null;
  let orders = (allOrders || []).filter(o => String(o.store_id) === storeIdNorm);
  if (storeIdNorm && orders.length === 0 && storeScopedOrders.length > 0) {
    orders = storeScopedOrders;
  }

  const ordersLoading = allOrdersLoading || scopedLoading;

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.list(), // Alterado para apiClient
    initialData: [],
  });

  const getSupplierName = (supplierId) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    return supplier?.name || 'N/A';
  };

  const copyToClipboard = async (label, value) => {
    try {
      if (!value) return;
      await navigator.clipboard.writeText(String(value));
      toast.success(`${label} copiado`);
    } catch (_e) {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = String(value);
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(textarea);
        if (ok) toast.success(`${label} copiado`); else toast.error('Não foi possível copiar');
      } catch {
        toast.error('Não foi possível copiar');
      }
    }
  };

  // Cancelar pedido (somente antes de enviado)
  const cancelOrderMutation = useMutation({
    mutationFn: ({ id }) => apiClient.entities.Order.update(id, { status: 'cancelled' }),
    onMutate: async ({ id }) => {
      setCancelling(true);
      await Promise.all([
        queryClient.cancelQueries({ queryKey: ['orders'] }),
        queryClient.cancelQueries({ queryKey: ['storeOrdersScoped', user?.store_id] })
      ]);

      const prevOrders = queryClient.getQueryData(['orders']);
      const prevScoped = queryClient.getQueryData(['storeOrdersScoped', user?.store_id]);
      const applyOptimistic = (arr) => Array.isArray(arr) ? arr.map(o => o.id === id ? { ...o, status: 'cancelled' } : o) : arr;
      if (prevOrders) queryClient.setQueryData(['orders'], applyOptimistic(prevOrders));
      if (prevScoped) queryClient.setQueryData(['storeOrdersScoped', user?.store_id], applyOptimistic(prevScoped));
      if (selectedOrder && selectedOrder.id === id) setSelectedOrder(s => s ? ({ ...s, status: 'cancelled' }) : s);

      return { prevOrders, prevScoped };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prevOrders) queryClient.setQueryData(['orders'], ctx.prevOrders);
      if (ctx?.prevScoped) queryClient.setQueryData(['storeOrdersScoped', user?.store_id], ctx.prevScoped);
    },
    onSettled: () => {
      setCancelling(false);
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['storeOrdersScoped', user?.store_id] });
    }
  });

  const canCancel = (status) => !['shipped', 'delivered', 'cancelled'].includes(status);
  const handleCancelOrder = (orderId, status) => {
    if (!canCancel(status)) return;
    setOrderToCancel(orderId);
    setShowCancelDialog(true);
  };

  const confirmCancelOrder = () => {
    if (!orderToCancel) return;
    cancelOrderMutation.mutate({ id: orderToCancel });
    setShowCancelDialog(false);
    setOrderToCancel(null);
    toast.success('Pedido cancelado com sucesso');
  };

  // Safe date formatter
  const safeFormatDate = (value, pattern = 'dd/MM/yyyy') => {
    try {
      if (!value) return '-';
      const d = new Date(value);
      if (isNaN(d.getTime())) return '-';
      return format(d, pattern);
    } catch {
      return '-';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Meus Pedidos</h1>
          <p className="text-gray-600">Acompanhe o status dos seus pedidos realizados</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total de Pedidos</p>
                  <p className="text-2xl font-bold text-gray-900">{orders.length}</p>
                </div>
                <ShoppingCart className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Pendentes</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {orders.filter(o => o.status === 'pending').length}
                  </p>
                </div>
                <Package className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Em Trânsito</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {orders.filter(o => ['processing', 'separated', 'shipped'].includes(o.status)).length}
                  </p>
                </div>
                <Package className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Entregues</p>
                  <p className="text-2xl font-bold text-green-600">
                    {orders.filter(o => o.status === 'delivered').length}
                  </p>
                </div>
                <Package className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50">
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              Histórico de Pedidos
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {ordersLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : orders.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-lg">Nenhum pedido realizado ainda</p>
                <p className="text-sm mt-2">Comece fazendo seu primeiro pedido!</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Pedido</TableHead>
                      <TableHead>Fornecedor</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Valor Total</TableHead>
                      <TableHead>Cashback</TableHead>
                      <TableHead>Brindes</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="font-medium">#{String(order.id).slice(0, 8)}</div>
                          <div className="text-xs text-gray-500">
                            {order.items?.length || 0} itens
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Building2 className="w-4 h-4 text-gray-400" />
                            {getSupplierName(order.supplier_id)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Calendar className="w-4 h-4" />
                            {safeFormatDate(order.created_date, 'dd/MM/yyyy')}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-semibold text-gray-900">
                            R$ {toMoney(order.total_amount)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {Number(order.cashback_amount) > 0 ? (
                            <div className="flex flex-col">
                              <span className="text-sm font-semibold text-green-600">R$ {toMoney(order.cashback_amount)}</span>
                              {(() => {
                                const rule = order.cashback_rule || (order?.diagnostics?.cashback?.branch === 'campaign_priority' ? 'campaign' : (order?.diagnostics?.cashback?.branch === 'state_only' ? 'state' : undefined));
                                return rule ? (
                                  <span className={`mt-1 text-[10px] px-2 py-0.5 rounded-full w-fit font-medium tracking-wide ${rule === 'campaign' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'}`}>
                                    {rule === 'campaign' ? 'Campanha' : 'Condição Estado'}
                                  </span>
                                ) : null;
                              })()}
                            </div>
                          ) : (
                            <span className="text-xs text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {(() => {
                            const giftCampaigns = (order.applied_campaigns || []).filter(c => c.campaign_type === 'gift_quantity' && c.gift_description);
                            if (giftCampaigns.length > 0) {
                              return (
                                <div className="flex items-center gap-1 text-emerald-700">
                                  <Gift className="w-4 h-4" />
                                  <span className="text-xs font-medium">{giftCampaigns.length}</span>
                                </div>
                              );
                            }
                            return <span className="text-xs text-gray-400">-</span>;
                          })()}
                        </TableCell>
                        <TableCell>
                          <Badge className={STATUS_CONFIG[order.status]?.color}>
                            {STATUS_CONFIG[order.status]?.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedOrder(order)}
                          >
                            <ChevronRight className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Detalhes do Pedido #{selectedOrder?.id.slice(0, 8)}</DialogTitle>
            </DialogHeader>
            {selectedOrder && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Fornecedor</p>
                    <p className="font-semibold">{getSupplierName(selectedOrder.supplier_id)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Data do Pedido</p>
                    <p className="font-semibold">
                      {safeFormatDate(selectedOrder.created_date, 'dd/MM/yyyy HH:mm')}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    <Badge className={STATUS_CONFIG[selectedOrder.status]?.color}>
                      {STATUS_CONFIG[selectedOrder.status]?.label}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Prazo de Pagamento</p>
                    <p className="font-semibold">{selectedOrder.payment_term_days} dias</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Forma de Pagamento</p>
                    <p className="font-semibold">{getPaymentMethodLabel(selectedOrder.payment_method)}</p>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Itens do Pedido</h3>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produto</TableHead>
                          <TableHead>Qtd</TableHead>
                          <TableHead>Preço Unit.</TableHead>
                          <TableHead>Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedOrder.items?.map((item, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{item.product_name}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>R$ {toMoney(item.unit_price)}</TableCell>
                            <TableCell className="font-semibold">
                              R$ {toMoney(item.total)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal:</span>
                    <span className="font-semibold">R$ {toMoney(selectedOrder.subtotal)}</span>
                  </div>
                  {selectedOrder.additional_amount > 0 && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Acréscimos:</span>
                      <span className="font-semibold text-orange-600">
                        R$ {toMoney(selectedOrder.additional_amount)}
                      </span>
                    </div>
                  )}
                  {selectedOrder.cashback_amount > 0 && (
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Cashback:</span>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-green-600">R$ {toMoney(selectedOrder.cashback_amount)}</span>
                        {(() => {
                          const rule = selectedOrder.cashback_rule || (selectedOrder?.diagnostics?.cashback?.branch === 'campaign_priority' ? 'campaign' : (selectedOrder?.diagnostics?.cashback?.branch === 'state_only' ? 'state' : undefined));
                          return rule ? (
                            <span className={`text-[10px] px-2 py-0.5 rounded-full w-fit font-medium tracking-wide ${rule === 'campaign' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'}`}>
                              {rule === 'campaign' ? 'Campanha' : 'Condição Estado'}
                            </span>
                          ) : null;
                        })()}
                      </div>
                    </div>
                  )}
                  {(() => {
                    const giftCampaigns = (selectedOrder.applied_campaigns || []).filter(c => c.campaign_type === 'gift_quantity' && c.gift_description);
                    if (giftCampaigns.length > 0) {
                      return (
                        <div className="bg-gradient-to-r from-emerald-50 to-green-50 border border-emerald-300 rounded-lg p-3 space-y-2">
                          <div className="flex items-center gap-2">
                            <Gift className="w-5 h-5 text-emerald-600" />
                            <span className="text-sm font-semibold text-emerald-800">Brindes Ganhos</span>
                          </div>
                          {giftCampaigns.map((gift, idx) => (
                            <div key={idx} className="bg-white rounded px-3 py-2 border border-emerald-200">
                              <p className="text-xs font-medium text-emerald-900">{gift.campaign_name}</p>
                              <p className="text-xs text-emerald-700 mt-1">🎁 {gift.gift_description}</p>
                            </div>
                          ))}
                        </div>
                      );
                    }
                    return null;
                  })()}
                  <div className="flex justify-between text-lg font-bold border-t pt-2">
                    <span>Total:</span>
                    <span className="text-blue-600">
                      R$ {toMoney(selectedOrder.total_amount)}
                    </span>
                  </div>
                </div>

                {(selectedOrder.numero_nota_fiscal || selectedOrder.chave_nota_fiscal) && (
                  <div className="bg-purple-50 border border-purple-100 rounded p-3">
                    <p className="text-sm text-gray-700 font-semibold mb-2">Nota Fiscal</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center min-w-0">
                        <span className="text-gray-500">Número:</span>
                        <span className="ml-2 font-mono px-2 py-0.5 bg-white border rounded text-xs truncate max-w-[220px] md:max-w-[260px]" title={selectedOrder.numero_nota_fiscal || ''}>
                          {selectedOrder.numero_nota_fiscal || '-'}
                        </span>
                        {selectedOrder.numero_nota_fiscal && (
                          <button
                            type="button"
                            className="ml-2 text-purple-700 hover:text-purple-900 p-1"
                            onClick={() => copyToClipboard('Número da NF', selectedOrder.numero_nota_fiscal)}
                            title="Copiar número"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      <div className="flex items-center min-w-0">
                        <span className="text-gray-500">Chave:</span>
                        <span className="ml-2 font-mono px-2 py-0.5 bg-white border rounded text-xs truncate max-w-[220px] md:max-w-[260px]" title={selectedOrder.chave_nota_fiscal || ''}>
                          {selectedOrder.chave_nota_fiscal ? `${selectedOrder.chave_nota_fiscal.slice(0,6)}…${selectedOrder.chave_nota_fiscal.slice(-6)}` : '-'}
                        </span>
                        {selectedOrder.chave_nota_fiscal && (
                          <button
                            type="button"
                            className="ml-2 text-purple-700 hover:text-purple-900 p-1"
                            onClick={() => copyToClipboard('Chave da NF-e', selectedOrder.chave_nota_fiscal)}
                            title="Copiar chave"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {selectedOrder.notes && (
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Observações</p>
                    <p className="text-sm bg-gray-50 p-3 rounded">{selectedOrder.notes}</p>
                  </div>
                )}

                <div className="flex justify-between flex-col sm:flex-row gap-3 pt-6 border-t">
                  {canCancel(selectedOrder.status) && (
                    <Button
                      onClick={() => handleCancelOrder(selectedOrder.id, selectedOrder.status)}
                      disabled={cancelling}
                      className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white font-semibold shadow-sm disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      {cancelling ? (
                        <span className="flex items-center"><span className="mr-2 animate-spin w-4 h-4 border-2 border-white/70 border-t-transparent rounded-full" />Cancelando...</span>
                      ) : (
                        'Cancelar Pedido'
                      )}
                    </Button>
                  )}
                  <div className="flex justify-end gap-3 w-full sm:w-auto">
                    <Button variant="outline" onClick={() => setSelectedOrder(null)} className="w-full sm:w-auto">
                      Fechar
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Confirmar Cancelamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-gray-700">
                Tem certeza que deseja cancelar este pedido?
              </p>
              <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded p-3">
                ⚠️ <strong>Atenção:</strong> Esta ação não pode ser desfeita.
              </p>
              <div className="flex justify-end gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowCancelDialog(false);
                    setOrderToCancel(null);
                  }}
                  disabled={cancelling}
                >
                  Não, manter pedido
                </Button>
                <Button
                  onClick={confirmCancelOrder}
                  disabled={cancelling}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  {cancelling ? (
                    <span className="flex items-center">
                      <span className="mr-2 animate-spin w-4 h-4 border-2 border-white/70 border-t-transparent rounded-full" />
                      Cancelando...
                    </span>
                  ) : (
                    'Sim, cancelar pedido'
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}