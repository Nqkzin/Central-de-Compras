import React, { useState } from "react";
import { apiClient } from "@/services/apiClient"; // Alterado para apiClient
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building2, Search, MapPin, Mail, Phone, Package, ArrowRight, ShoppingCart } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function StoreSuppliersView() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Fetch the current store to get its state for conditional queries
  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => apiClient.auth.me(),
  });

  const { data: stores } = useQuery({
    queryKey: ['stores', currentUser?.store_id],
    queryFn: () => apiClient.entities.Store.filter({ id: currentUser?.store_id }),
    initialData: [],
    enabled: !!currentUser?.store_id,
  });

  const store = stores.length > 0 ? stores[0] : null;

  const { data: suppliers, isLoading } = useQuery({
    queryKey: ['suppliers'],
    queryFn: () => apiClient.entities.Supplier.filter({ status: 'active' }), // Alterado para apiClient
    initialData: [],
  });

  const { data: products } = useQuery({
    queryKey: ['products'],
    queryFn: () => apiClient.entities.Product.filter({ status: 'active' }), // Alterado para apiClient
    initialData: [],
  });

  const { data: stateConditions } = useQuery({
    queryKey: ['stateConditions', store?.state],
    queryFn: async () => {
      return await apiClient.entities.StateCondition.filter({
        state: store?.state,
        status: 'active'
      });
    },
    initialData: [],
    enabled: !!store?.state,
  });

  const getSupplierConditions = (supplierId) => {
    return stateConditions.find(c => c.supplier_id === supplierId);
  };

  // Get all unique categories (singular field 'category')
  const allCategories = [...new Set(suppliers.map(s => s.category).filter(Boolean))];

  const filteredSuppliers = suppliers.filter(supplier => {
    const matchesSearch =
      supplier.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      supplier.city?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "all" || supplier.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getProductCount = (supplierId) => {
    return products.filter(p => p.supplier_id === supplierId).length;
  };

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-9xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Fornecedores Disponíveis</h1>
          <p className="text-gray-600">Encontre fornecedores por categoria e faça seus pedidos</p>
        </div>

        <div className="mb-6 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Buscar fornecedores por nome ou cidade..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge
              variant={selectedCategory === "all" ? "default" : "outline"}
              className="cursor-pointer px-4 py-2"
              onClick={() => setSelectedCategory("all")}
            >
              Todas as Categorias
            </Badge>
            {allCategories.map(category => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                className="cursor-pointer px-4 py-2"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : filteredSuppliers.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="py-12 text-center text-gray-500">
              <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg">Nenhum fornecedor encontrado</p>
              <p className="text-sm mt-2">Tente ajustar os filtros de busca</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSuppliers.map((supplier) => (
              <Card key={supplier.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="h-2 bg-gradient-to-r from-green-500 to-emerald-500" />
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      {supplier.image_url && (
                        <img
                          src={supplier.image_url}
                          alt={supplier.name}
                          className="w-12 h-12 rounded-lg object-cover border flex-shrink-0"
                        />
                      )}
                      {!supplier.image_url && (
                        <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Building2 className="w-6 h-6 text-white" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <CardTitle className="text-lg truncate">{supplier.name}</CardTitle>
                        <div className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                          <MapPin className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate">{supplier.city}, {supplier.state}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span className="truncate">{supplier.contact_email}</span>
                    </div>
                    {supplier.contact_phone && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Phone className="w-4 h-4" />
                        {supplier.contact_phone}
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Package className="w-4 h-4" />
                      {getProductCount(supplier.id)} produtos disponíveis
                    </div>
                  </div>

                  {supplier.category && (
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-2">Categoria:</p>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary" className="text-xs">
                          {supplier.category}
                        </Badge>
                      </div>
                    </div>
                  )}

                  {(() => {
                    const conditions = getSupplierConditions(supplier.id);
                    if (conditions) {
                      return (
                        <div className="bg-blue-50 rounded-lg p-3 space-y-2">
                          <p className="text-xs font-semibold text-blue-900">Condições para {store?.state}:</p>
                          {conditions.cashback_percentage > 0 && (
                            <p className="text-xs text-blue-700">• Cashback: {conditions.cashback_percentage}%</p>
                          )}
                          {conditions.payment_term_days && (
                            <p className="text-xs text-blue-700">• Prazo: {conditions.payment_term_days} dias</p>
                          )}
                        </div>
                      );
                    }
                    return null;
                  })()}

                  {(() => {
                    const conditions = getSupplierConditions(supplier.id);
                    if (conditions?.catalog_url) {
                      return (
                        <Button
                          onClick={() => window.open(conditions.catalog_url, '_blank')}
                          variant="outline"
                          className="w-full border-purple-300 text-purple-700 hover:bg-purple-50 hover:border-purple-400"
                        >
                          <Package className="w-4 h-4 mr-2" />
                          Ver Catálogo de Produtos
                          <ArrowRight className="w-4 h-4 ml-auto" />
                        </Button>
                      );
                    }
                    return null;
                  })()}

                  <Button
                    onClick={() => {
                      navigate(`${createPageUrl('StoreNewOrder')}?supplier_id=${supplier.id}`);
                    }}
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                  >
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Fazer Pedido
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}