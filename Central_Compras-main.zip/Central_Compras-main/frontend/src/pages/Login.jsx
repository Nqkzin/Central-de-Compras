import React, { useState } from 'react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { ShoppingCart, Mail, Lock, ArrowRight } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login({ email, password });
      // Redirecionamento será feito pelo AuthContext
    } catch (error) {
      toast.error('Erro no login: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-stretch bg-gradient-to-br from-slate-800 to-slate-700">
      {/* Lado esquerdo - Branding (desktop) */}
      <div className="hidden lg:flex lg:w-1/2 text-white p-12 flex-col justify-between">
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center mr-4 shadow-lg shadow-blue-800/30">
            <ShoppingCart className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold">CentralCompras</h1>
        </div>

        <div className="max-w-md">
          <h2 className="text-4xl font-bold mb-6">Sistema de Gestão de Compras</h2>
          <p className="text-blue-100 text-lg mb-10">Gerencie suas compras, fornecedores e pedidos em um só lugar com nossa plataforma integrada.</p>

          <div className="space-y-4">
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center mr-4 mt-1">
                <StoreIcon />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Multi-lojas</h3>
                <p className="text-blue-200">Gerencie várias lojas em um único painel</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center mr-4 mt-1">
                <TrendingIcon />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Relatórios Avançados</h3>
                <p className="text-blue-200">Acompanhe métricas e tome decisões baseadas em dados</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center mr-4 mt-1">
                <TruckIcon />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Fornecedores</h3>
                <p className="text-blue-200">Centralize o relacionamento com seus fornecedores</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex space-x-4 text-sm text-blue-200">
          <span>Termos de uso</span>
          <span>•</span>
          <span>Política de privacidade</span>
          <span>•</span>
          <span>Suporte</span>
        </div>
      </div>

      {/* Lado direito - Formulário */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 lg:p-10 bg-white">
        <Card className="w-full max-w-md border-none shadow-xl">
          <CardHeader className="text-center pt-8">
            <div className="lg:hidden mb-4 flex flex-col items-center">
              <div className="w-14 h-14 rounded-xl bg-blue-500 flex items-center justify-center shadow-md shadow-blue-800/20">
                <ShoppingCart className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <h1 className="text-xl font-bold text-gray-900">CentralCompras</h1>
                <p className="text-gray-600 text-sm">Sistema de Gestão de Compras</p>
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">Bem-vindo de volta</CardTitle>
            <p className="text-gray-600 mt-1 text-sm">Entre com suas credenciais para acessar o sistema</p>
          </CardHeader>
          <CardContent className="pb-8">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-gray-700">E-mail</Label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <Input
                    type="email"
                    placeholder="email@exemplo.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="pl-9"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-700">Senha</Label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="pl-9 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-500 hover:text-gray-700"
                  >
                    {showPassword ? 'Ocultar' : 'Mostrar'}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-sm text-gray-600">
                  <input
                    type="checkbox"
                    className="h-4 w-4 text-blue-600 focus:ring-blue-400 border-gray-300 rounded"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                  />
                  Lembrar-me
                </label>
                {/* Link de 'Esqueceu a senha?' removido por enquanto */}
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600"
                disabled={loading}
              >
                {loading ? 'Entrando...' : (
                  <span className="flex items-center justify-center gap-2">
                    Entrar <ArrowRight className="w-4 h-4" />
                  </span>
                )}
              </Button>

              {/* Opções sociais (Google/Microsoft) removidas por enquanto */}
            </form>
            {/* Link de 'Solicitar acesso' removido por enquanto */}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Ícones simples inline para evitar libs extras
function StoreIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-blue-300">
      <path d="M21 8V7a1 1 0 0 0-1-1h-1.22a3 3 0 0 0-2.83-2H8.05a3 3 0 0 0-2.83 2H4a1 1 0 0 0-1 1v1a3 3 0 0 0 2 2.82V19a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1v-8.18A3 3 0 0 0 21 8Z" />
    </svg>
  );
}
function TrendingIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-emerald-300">
      <path d="M3 3v18h18v-2H5V3H3Zm16.59 3L13 12.59 9.41 9 3 15.41 4.41 16.83 9.41 11.83 13 15.41 21 7.41 19.59 6Z" />
    </svg>
  );
}
function TruckIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-purple-300">
      <path d="M3 3h11v10H3V3Zm12 2h3l3 4v7h-3a3 3 0 1 1-6 0H9a3 3 0 1 1-6 0H2v-2h1v-2h12V5Zm4 4-2-3h-2v3h4Z" />
    </svg>
  );
}