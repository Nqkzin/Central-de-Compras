// apiClient.js - MANTENHA APENAS ESTE:
class ApiClient {
  constructor(baseURL = 'http://localhost:3001/api') {
    this.baseURL = baseURL;
    this.token = localStorage.getItem('auth_token');
  }

  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('auth_token', token);
    } else {
      localStorage.removeItem('auth_token');
    }
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (this.token) {
      config.headers.Authorization = `Bearer ${this.token}`;
    }

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        let errorMessage = `HTTP error! status: ${response.status}`;
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch (e) {
          // Ignora se não conseguir parsear JSON
        }
        throw new Error(errorMessage);
      }

      const contentLength = response.headers.get('content-length');
      if (contentLength === '0') {
        return null;
      }

      return await response.json();
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  // Auth methods
  auth = {
    me: async () => {
      return this.request('/auth/me');
    },
    login: async (credentials) => {
      const result = await this.request('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      });
      if (result.token) {
        this.setToken(result.token);
      }
      return result;
    },
    logout: () => {
      this.setToken(null);
    },
  };

  // Generic entity methods
  entity(name) {
    return {
      list: async (sort = '') => {
        const endpoint = sort ? `/${name}?sort=${sort}` : `/${name}`;
        return this.request(endpoint);
      },
      filter: async (filters = {}, sort = '') => {
        const query = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
          if (value !== undefined && value !== null && value !== '') {
            query.append(key, value);
          }
        });
        if (sort) query.append('sort', sort);
        
        return this.request(`/${name}?${query.toString()}`);
      },
      get: async (id) => {
        return this.request(`/${name}/${id}`);
      },
      create: async (data) => {
        return this.request(`/${name}`, {
          method: 'POST',
          body: JSON.stringify(data),
        });
      },
      update: async (id, data) => {
        return this.request(`/${name}/${id}`, {
          method: 'PUT',
          body: JSON.stringify(data),
        });
      },
      delete: async (id) => {
        return this.request(`/${name}/${id}`, {
          method: 'DELETE',
        });
      },
      bulkCreate: async (dataArray) => {
        // Expect an array of objects; backend expects { conditions: [...] }
        return this.request(`/${name}/bulk`, {
          method: 'POST',
          body: JSON.stringify({ conditions: dataArray }),
        });
      },
    };
  }
      // helper: fetch cashback for a store (previsto x realizado)
  // Integration methods for file upload
  integrations = {
    Core: {
      UploadFile: async ({ file }) => {
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await fetch(`${this.baseURL}/upload`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.token}`,
          },
          body: formData,
        });
        
        if (!response.ok) {
          throw new Error('Upload failed');
        }
        
        return await response.json();
      }
    }
  };

  // Specific entities
  entities = {
    Store: this.entity('stores'),
    Supplier: this.entity('suppliers'),
    Product: this.entity('products'),
    Order: this.entity('orders'),
    Campaign: this.entity('campaigns'),
    StateCondition: this.entity('state-conditions'),
    Contact: this.entity('contacts'),
    Category: this.entity('categories'),
  };
}

export const apiClient = new ApiClient();
// helper: fetch cashback (previsto x realizado) for a store
apiClient.entities.Store.cashback = async (storeId) => {
  return apiClient.request(`/stores/${storeId}/cashback`);
};
apiClient.entities.Store.cashbackSummary = async () => {
  return apiClient.request('/stores/cashback/summary');
};
// helper: admin cashback approval flows (must be defined globally)
apiClient.entities.Store.cashbackPending = async () => {
  return apiClient.request('/stores/cashback/pending');
};
apiClient.entities.Store.approveCashback = async (detailId, payload = {}) => {
  return apiClient.request(`/stores/cashback/${detailId}/approve`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
};
export default apiClient;