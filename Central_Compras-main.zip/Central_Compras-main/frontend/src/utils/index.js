export const createPageUrl = (pageName) => {
  const routes = {
    Dashboard: '/dashboard',
    AdminStores: '/admin/stores',
    AdminSuppliers: '/admin/suppliers',
    AdminProducts: '/admin/products',
    AdminCashback: '/admin/cashback',
    StoreSuppliersView: '/store/suppliers',
    StoreNewOrder: '/store/new-order',
    StoreOrders: '/store/orders',
    StoreProfile: '/store/profile',
  StoreCampaigns: '/store/campaigns',
    SupplierOrders: '/supplier/orders',
    SupplierProducts: '/supplier/products',
    SupplierCampaigns: '/supplier/campaigns',
    SupplierStateConditions: '/supplier/state-conditions',
    SupplierContacts: '/supplier/contacts',
    AdminStateConditions: '/admin/state-conditions',
    AdminCampaigns: '/admin/campaigns',
  };
  
  return routes[pageName] || '/';
};