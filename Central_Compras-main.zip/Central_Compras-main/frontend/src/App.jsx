import React from 'react';
import { Toaster } from 'sonner';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';

// Import das páginas
import Dashboard from './pages/Dashboard';
import AdminStores from './pages/admin/AdminStores';
import AdminSuppliers from './pages/admin/AdminSuppliers';
import AdminProducts from './pages/admin/AdminProducts';
import AdminCampaigns from './pages/admin/AdminCampaigns';
import AdminCashback from './pages/admin/AdminCashback';
import StoreSuppliersView from './pages/store/StoreSuppliersView';
import StoreNewOrder from './pages/store/StoreNewOrder';
import StoreOrders from './pages/store/StoreOrders';
import StoreProfile from './pages/store/StoreProfile';
import SupplierOrders from './pages/supplier/SupplierOrders';
import SupplierProducts from './pages/supplier/SupplierProducts';
import SupplierCampaigns from './pages/supplier/SupplierCampaigns';
import SupplierStateConditions from './pages/supplier/SupplierStateConditions';
import ChangePassword from './pages/ChangePassword';
import StoreCampaigns from './pages/store/StoreCampaigns';

const queryClient = new QueryClient();

function AppContent() {
  const { user, loading, mustChangePassword } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    // Se flag de troca de senha estiver ativa mas sem user (ex: token expirado), força login
    return <Login />;
  }

  // Se deve trocar senha obrigatoriamente, só permite acesso a /change-password
  if (mustChangePassword) {
    return <ChangePassword />;
  }

  return (
    <Layout>
      <Routes>
        <Route path="/change-password" element={<ChangePassword />} />
  <Route path="/" element={<Dashboard />} />
  <Route path="/dashboard" element={<Dashboard />} />
  {/* Preview removido */}
        
        {/* Admin Routes */}
        <Route path="/admin/stores" element={<AdminStores />} />
        <Route path="/admin/suppliers" element={<AdminSuppliers />} />
        <Route path="/admin/products" element={<AdminProducts />} />
        <Route path="/admin/campaigns" element={<AdminCampaigns />} />
        <Route path="/admin/cashback" element={<AdminCashback />} />
        
        {/* Store Routes */}
        <Route path="/store/suppliers" element={<StoreSuppliersView />} />
        <Route path="/store/new-order" element={<StoreNewOrder />} />
        <Route path="/store/orders" element={<StoreOrders />} />
        <Route path="/store/profile" element={<StoreProfile />} />
  <Route path="/store/campaigns" element={<StoreCampaigns />} />
        
        {/* Supplier Routes */}
        <Route path="/supplier/orders" element={<SupplierOrders />} />
        <Route path="/supplier/products" element={<SupplierProducts />} />
        <Route path="/supplier/campaigns" element={<SupplierCampaigns />} />
        <Route path="/supplier/state-conditions" element={<SupplierStateConditions />} />
      </Routes>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <>
            <Toaster position="top-right" richColors closeButton />
            <AppContent />
          </>
        </Router>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;