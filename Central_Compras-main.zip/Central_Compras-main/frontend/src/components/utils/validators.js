
// Funções de validação e formatação

// Formatar CNPJ
export const formatCNPJ = (value) => {
  const cleaned = value.replace(/\D/g, '');
  if (cleaned.length <= 14) {
    return cleaned
      .replace(/^(\d{2})(\d)/, '$1.$2')
      .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
      .replace(/\.(\d{3})(\d)/, '.$1/$2')
      .replace(/(\d{4})(\d)/, '$1-$2');
  }
  return value;
};

// Validar CNPJ
export const validateCNPJ = (cnpj) => {
  const cleaned = cnpj.replace(/\D/g, '');
  if (cleaned.length !== 14) return false;
  
  // Verificar se todos os dígitos são iguais
  if (/^(\d)\1+$/.test(cleaned)) return false;
  
  return true;
};

// Formatar CEP
export const formatCEP = (value) => {
  const cleaned = value.replace(/\D/g, '');
  if (cleaned.length <= 8) {
    return cleaned.replace(/^(\d{5})(\d)/, '$1-$2');
  }
  return value;
};

// Validar CEP
export const validateCEP = (cep) => {
  const cleaned = cep.replace(/\D/g, '');
  return cleaned.length === 8;
};

// Formatar Telefone
export const formatPhone = (value) => {
  const cleaned = value.replace(/\D/g, '');
  if (cleaned.length <= 11) {
    if (cleaned.length <= 10) {
      return cleaned.replace(/^(\d{2})(\d{4})(\d)/, '($1) $2-$3');
    }
    return cleaned.replace(/^(\d{2})(\d{5})(\d)/, '($1) $2-$3');
  }
  return value;
};

// Validar Telefone
export const validatePhone = (phone) => {
  const cleaned = phone.replace(/\D/g, '');
  return cleaned.length === 10 || cleaned.length === 11;
};

// Capitalizar nome próprio
export const capitalizeName = (name) => {
  if (!name) return '';
  
  const exceptions = ['da', 'de', 'do', 'das', 'dos', 'e'];
  
  return name
    .toLowerCase()
    .split(' ')
    .map((word, index) => {
      // Primeira palavra sempre maiúscula
      if (index === 0) {
        return word.charAt(0).toUpperCase() + word.slice(1);
      }
      // Exceções em minúsculo
      if (exceptions.includes(word)) {
        return word;
      }
      // Demais palavras com primeira letra maiúscula
      return word.charAt(0).toUpperCase() + word.slice(1);
    })
    .join(' ');
};

// Formatar código de produto (apenas alfanumérico e hífen)
export const formatProductCode = (value) => {
  return value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
};

// Validar email
export const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};

// Validar EAN 13
export const validateEAN13 = (code) => {
  if (!code) return true; // Opcional
  const cleaned = code.replace(/\D/g, '');
  return cleaned.length === 13;
};

// Formatar EAN 13 (apenas números)
export const formatEAN13 = (value) => {
  return value.replace(/\D/g, '').slice(0, 13);
};

// Remover formatação (pegar apenas números)
export const removeFormatting = (value) => {
  return value.replace(/\D/g, '');
};

// Validar Inscrição Estadual (opcional; se informado, 8 a 13 dígitos)
export const validateIE = (value) => {
  if (!value || String(value).trim() === '') return true;
  const cleaned = value.replace(/\D/g, '');
  return cleaned.length >= 8 && cleaned.length <= 13;
};

// Formatar Inscrição Estadual: somente dígitos, limite 13
export const formatIE = (value) => {
  return value.replace(/\D/g, '').slice(0, 13);
};
