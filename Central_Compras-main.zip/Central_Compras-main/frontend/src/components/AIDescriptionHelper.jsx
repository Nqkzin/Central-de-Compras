import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function AIDescriptionHelper({ productName, onSuggestionReceived, type = "product", campaignData = null }) {
  const [isGenerating, setIsGenerating] = useState(false);

  // Gerador de descrições usando templates inteligentes (100% gratuito, local)
  const generateSmartDescription = (name, type, data = null) => {
    if (type === "product") {
      // Templates variados para produtos
      const templates = [
        `${name} - Produto de alta qualidade ideal para atender às necessidades do seu negócio. Oferece excelente custo-benefício e durabilidade, sendo uma escolha confiável para o dia a dia.`,
        `${name} disponível para pronta entrega. Destaque-se com este produto que une praticidade, eficiência e qualidade superior. Perfeito para otimizar suas operações comerciais.`,
        `${name} - Solução profissional que garante resultados consistentes. Desenvolvido para quem busca qualidade e performance, este item é essencial para seu estoque.`,
        `Adiquira ${name} para elevar o padrão do seu negócio. Produto versátil e confiável, ideal para diversas aplicações comerciais com garantia de satisfação.`,
      ];
      return templates[Math.floor(Math.random() * templates.length)];
    }
    
    if (type === "campaign" && data) {
      // Templates para campanhas baseados no tipo
      let description = `${name} - `;
      
      if (data.type === 'cashback_value') {
        const percentage = data.cashback_percentage || 0;
        const minValue = data.min_value || 0;
        description += `Campanha especial de cashback! `;
        if (minValue > 0) {
          description += `Compre a partir de R$ ${minValue.toFixed(2)} `;
        }
        if (percentage > 0) {
          description += `e receba ${percentage}% de volta em créditos. `;
        }
        description += `Aproveite para aumentar seu poder de compra e economizar em suas próximas aquisições.`;
      } else if (data.type === 'cashback_quantity') {
        const percentage = data.cashback_percentage || 0;
        const minQty = data.min_quantity || 0;
        description += `Promoção imperdível! `;
        if (minQty > 0) {
          description += `Adquira ${minQty} unidades ou mais `;
        }
        if (percentage > 0) {
          description += `e ganhe ${percentage}% de cashback. `;
        }
        description += `Quanto mais você compra, mais você economiza para as próximas compras.`;
      } else if (data.type === 'gift_quantity') {
        const minQty = data.min_quantity || 0;
        const gift = data.gift_description || "brinde especial";
        description += `Oferta exclusiva com brinde! `;
        if (minQty > 0) {
          description += `Na compra de ${minQty} unidades ou mais, `;
        }
        description += `você ganha ${gift}. Uma oportunidade única de agregar valor à sua compra.`;
      }
      
      // Adicionar urgência se houver data de término
      if (data.end_date) {
        const endDate = new Date(data.end_date);
        const now = new Date();
        const daysLeft = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
        if (daysLeft > 0 && daysLeft <= 30) {
          description += ` Promoção válida por tempo limitado!`;
        }
      }
      
      return description;
    }
    
    return `${name} - Produto de qualidade para seu negócio.`;
  };

  const generateDescription = () => {
    if (!productName?.trim()) {
      toast.error("Informe o nome primeiro");
      return;
    }

    setIsGenerating(true);
    
    // Simular delay de processamento para parecer mais realista
    setTimeout(() => {
      try {
        const description = generateSmartDescription(productName, type, campaignData);
        onSuggestionReceived(description);
        toast.success("Descrição gerada com sucesso!");
      } catch (error) {
        console.error("Error generating description:", error);
        toast.error("Erro ao gerar descrição. Tente novamente.");
      } finally {
        setIsGenerating(false);
      }
    }, 800); // Delay de 800ms para simular processamento
  };

  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      onClick={generateDescription}
      disabled={isGenerating || !productName?.trim()}
      className="w-full border-purple-200 hover:bg-purple-50 hover:border-purple-300"
    >
      {isGenerating ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Gerando descrição inteligente...
        </>
      ) : (
        <>
          <Sparkles className="w-4 h-4 mr-2 text-purple-600" />
          Sugerir Descrição com IA
        </>
      )}
    </Button>
  );
}