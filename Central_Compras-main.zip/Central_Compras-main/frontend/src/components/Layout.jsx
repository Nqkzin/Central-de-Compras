// Layout.jsx (substitua seu arquivo)
import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { apiClient } from "@/services/apiClient";
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  LayoutDashboard,
  Store,
  Package,
  ShoppingCart,
  Users,
  TrendingUp,
  Settings,
  LogOut,
  Menu,
  Building2,
  Tag,
  MapPin,
  ChevronDown,
  Eye,
  XCircle,
  Key,
  DollarSign
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";

const navigationByRole = {
  admin: [
    { title: "Dashboard", url: "Dashboard", icon: LayoutDashboard },
    { title: "Lojas", url: "AdminStores", icon: Store },
    { title: "Fornecedores", url: "AdminSuppliers", icon: Building2 },
    { title: "Produtos", url: "AdminProducts", icon: Package },
    { title: "Campanhas", url: "AdminCampaigns", icon: TrendingUp },
    { title: "Cashback", url: "AdminCashback", icon: DollarSign },
  ],
  store: [
    { title: "Dashboard", url: "Dashboard", icon: LayoutDashboard },
    { title: "Campanhas", url: "StoreCampaigns", icon: TrendingUp },
    { title: "Fornecedores", url: "StoreSuppliersView", icon: Building2 },
    { title: "Fazer Pedido", url: "StoreNewOrder", icon: ShoppingCart },
    { title: "Meus Pedidos", url: "StoreOrders", icon: Package },
    { title: "Meus Dados", url: "StoreProfile", icon: Settings },
  ],
  supplier: [
    { title: "Dashboard", url: "Dashboard", icon: LayoutDashboard },
    { title: "Pedidos Recebidos", url: "SupplierOrders", icon: ShoppingCart },
    { title: "Produtos", url: "SupplierProducts", icon: Package },
    { title: "Campanhas", url: "SupplierCampaigns", icon: TrendingUp },
    { title: "Condições por Estado", url: "SupplierStateConditions", icon: MapPin },
  ],
};

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user: authUser, logout: authLogout } = useAuth(); 
  const [loading, setLoading] = useState(true);
  const [entityName, setEntityName] = useState('');
  const [previewMode, setPreviewMode] = useState(null);
  const [previewEntity, setPreviewEntity] = useState(null);
  const [previewUserDisplay, setPreviewUserDisplay] = useState(null);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordLoading, setPasswordLoading] = useState(false);

  useEffect(() => {
    // carregamento: verifica preview_mode no localStorage
    let cancelled = false;
    const loadPreview = async () => {
      // Desativa qualquer preview antigo
      localStorage.removeItem('preview_mode');
      try {
        const previewData = null; // preview desativado
        if (!previewData) {
          setPreviewMode(null);
          setPreviewEntity(null);
          setPreviewUserDisplay(null);
          return;
        }

        const preview = JSON.parse(previewData);
        setPreviewMode(preview);

        if (preview.type === 'store') {
          const stores = await apiClient.entities.Store.filter({ id: preview.id });
          if (stores && stores[0] && !cancelled) {
            setPreviewEntity(stores[0]);
            setPreviewUserDisplay({
              full_name: stores[0].responsible_name,
              email: stores[0].responsible_email,
              user_type: 'store',
              store_id: stores[0].id,
              role: 'user'
            });
          }
        } else if (preview.type === 'supplier') {
          const suppliers = await apiClient.entities.Supplier.filter({ id: preview.id });
          if (suppliers && suppliers[0] && !cancelled) {
            setPreviewEntity(suppliers[0]);
            setPreviewUserDisplay({
              full_name: suppliers[0].contact_name,
              email: suppliers[0].contact_email,
              user_type: 'supplier',
              supplier_id: suppliers[0].id,
              role: 'user'
            });
          }
        } else {
          // unsupported preview type -> clear
          setPreviewEntity(null);
          setPreviewUserDisplay(null);
        }
      } catch (error) {
        console.error("Error loading preview:", error);
        setPreviewMode(null);
        setPreviewEntity(null);
        setPreviewUserDisplay(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    loadPreview();

    return () => {
      cancelled = true;
    };
  }, []); // carregar apenas ao montar

  // Buscar razão social da entidade (loja ou fornecedor)
  useEffect(() => {
    const fetchEntityName = async () => {
      if (!authUser) return;
      
      try {
        if (authUser.user_type === 'store' && authUser.store_id) {
          const stores = await apiClient.entities.Store.filter({ id: authUser.store_id });
          if (stores && stores[0]) {
            setEntityName(stores[0].name);
          }
        } else if (authUser.user_type === 'supplier' && authUser.supplier_id) {
          const suppliers = await apiClient.entities.Supplier.filter({ id: authUser.supplier_id });
          if (suppliers && suppliers[0]) {
            setEntityName(suppliers[0].name);
          }
        }
      } catch (error) {
        console.error('Error fetching entity name:', error);
      }
    };

    fetchEntityName();
  }, [authUser]);

  // seletor de loja ativa removido

  // Funções de navegação sem reload (useNavigate)
  const handleLogout = () => {
    setShowLogoutConfirm(true);
  };

  const confirmLogout = () => {
    setShowLogoutConfirm(false);
    authLogout();
  };

  const cancelLogout = () => setShowLogoutConfirm(false);

  const handleChangePasswordClick = () => {
    setShowChangePassword(true);
    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    
    if (passwordForm.newPassword.length < 6) {
      toast.error('Nova senha deve ter ao menos 6 caracteres');
      return;
    }
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error('Confirmação não confere');
      return;
    }

    setPasswordLoading(true);
    try {
      await apiClient.request('/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({
          current_password: passwordForm.currentPassword,
          new_password: passwordForm.newPassword,
        })
      });
      toast.success('Senha alterada com sucesso!');
      setShowChangePassword(false);
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (e) {
      toast.error(e.message || 'Falha ao alterar senha');
    } finally {
      setPasswordLoading(false);
    }
  };

  // Preview removido

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  const displayUser = previewMode ? (previewUserDisplay || authUser) : authUser;
  // seletor de loja ativa removido
  const effectiveUserType = previewMode?.type === 'store'
    ? 'store'
    : previewMode?.type === 'supplier'
      ? 'supplier'
      : (authUser?.user_type || 'admin');
  const navigationItems = navigationByRole[effectiveUserType] || navigationByRole.admin;
  const displayName = displayUser?.full_name || displayUser?.name || 'Usuário';
  const displayEmail = displayUser?.email || displayUser?.username || '';
  const userInitials = (displayName).split(' ').map(n => n[0]).join('').toUpperCase().slice(0,2);

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-gray-50 to-blue-50">
        <Sidebar className="border-r border-gray-200 bg-white flex flex-col">
          <SidebarHeader className="border-b border-gray-200 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                <ShoppingCart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900 text-lg">Central de Compras</h2>
                <p className="text-xs text-gray-500">
                  {effectiveUserType === 'admin' 
                    ? 'Administrador' 
                    : entityName || (effectiveUserType === 'store' ? 'Loja' : 'Fornecedor')}
                </p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-3 flex-1 overflow-auto">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
                Navegação
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => {
                    const isActive = location.pathname === createPageUrl(item.url);
                    return (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`
                            transition-all duration-200 rounded-xl
                            ${isActive 
                              ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md hover:shadow-lg' 
                              : 'hover:bg-blue-50 text-gray-700 hover:text-blue-700'
                            }
                          `}
                        >
                          <Link to={createPageUrl(item.url)} className="flex items-center gap-3 px-4 py-3">
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

          </SidebarContent>
        </Sidebar>
        <main className="flex-1 overflow-auto">
          {previewMode && (
            <div className="bg-yellow-100 border-b border-yellow-300 px-6 py-2">
              <div className="flex items-center justify-between max-w-7xl mx-auto">
                <div className="flex items-center gap-2 text-sm text-yellow-800">
                  <Eye className="w-4 h-4" />
                  <span className="font-semibold">Modo de Visualização Ativo</span>
                  {previewEntity && (
                    <span>• Visualizando como: <strong>{previewEntity.name}</strong></span>
                  )}
                </div>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={exitPreviewMode}
                  className="text-yellow-800 hover:text-yellow-900 hover:bg-yellow-200"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Sair do Preview
                </Button>
              </div>
            </div>
          )}

          {children}
        </main>

        {/* Sidebar direita com menu de usuário */}
        <div className="w-64 border-l border-gray-200 bg-white flex flex-col">
          <div className="p-6 flex-1">
            <div className="flex flex-col items-center text-center mb-6">
              <Avatar className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-600 mb-3">
                <AvatarFallback className="text-white font-bold text-2xl">
                  {userInitials}
                </AvatarFallback>
              </Avatar>
              <h3 className="font-semibold text-gray-900 text-base">{displayName}</h3>
              {displayEmail && <p className="text-xs text-gray-500 mt-1">{displayEmail}</p>}
              <div className="mt-2 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                {effectiveUserType === 'admin' ? 'Administrador' : effectiveUserType === 'store' ? 'Loja' : 'Fornecedor'}
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={handleChangePasswordClick}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 border-gray-200 hover:border-blue-400 hover:bg-blue-50 text-gray-700 hover:text-blue-700 transition-all shadow-sm hover:shadow-md"
              >
                <Key className="w-5 h-5" />
                <span className="font-medium">Trocar Senha</span>
              </button>
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 border-gray-200 hover:border-red-400 hover:bg-red-50 text-gray-700 hover:text-red-700 transition-all shadow-sm hover:shadow-md"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Sair</span>
              </button>
            </div>
          </div>
        </div>

        {/* Logout confirmation centered */}
        <Dialog open={showLogoutConfirm} onOpenChange={setShowLogoutConfirm}>
            <DialogContent className="max-w-sm">
              <DialogHeader>
                <DialogTitle>Confirmar saída</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <p>Deseja realmente sair da sua conta? Você será redirecionado para a tela de login.</p>
                <div className="flex gap-3 justify-end pt-2">
                  <button
                    onClick={cancelLogout}
                    className="px-4 py-2 rounded border border-gray-300 text-gray-700 hover:bg-gray-100 text-sm"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={confirmLogout}
                    className="px-4 py-2 rounded bg-red-600 hover:bg-red-700 text-white font-medium text-sm"
                  >
                    Sair
                  </button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Change Password Dialog */}
          <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5 text-blue-600" />
                  Trocar Senha
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Senha Atual
                  </label>
                  <input
                    type="password"
                    value={passwordForm.currentPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nova Senha
                  </label>
                  <input
                    type="password"
                    value={passwordForm.newPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                    minLength={6}
                  />
                  <p className="text-xs text-gray-500 mt-1">Mínimo de 6 caracteres</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Confirmar Nova Senha
                  </label>
                  <input
                    type="password"
                    value={passwordForm.confirmPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div className="flex gap-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setShowChangePassword(false)}
                    className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 text-sm font-medium"
                    disabled={passwordLoading}
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium text-sm disabled:opacity-50"
                    disabled={passwordLoading}
                  >
                    {passwordLoading ? 'Salvando...' : 'Salvar Senha'}
                  </button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
      </div>
    </SidebarProvider>
  );
}
