// src/components/ui/dialog.jsx
import React, { createContext, useContext, useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

const DialogContext = createContext(null);

/**
 * Dialog root - pode ser controlado via props open/onOpenChange ou não-controlado.
 * NÃO repassa open/onOpenChange diretamente ao DOM.
 */
export const Dialog = React.forwardRef(({ open: openProp, onOpenChange, children, className, ...props }, ref) => {
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = typeof openProp === 'boolean';
  const open = isControlled ? openProp : internalOpen;

  const setOpen = (v) => {
    if (isControlled) {
      onOpenChange?.(v);
    } else {
      setInternalOpen(v);
      onOpenChange?.(v);
    }
  };

  // Expose a context with open/setOpen
  return (
    <DialogContext.Provider value={{ open, setOpen }}>
      <div ref={ref} className={cn("", className)} {...props}>
        {children}
      </div>
    </DialogContext.Provider>
  );
});
Dialog.displayName = "Dialog";

export const DialogTrigger = React.forwardRef(({ asChild = false, children, className, ...props }, ref) => {
  const ctx = useContext(DialogContext);
  if (!ctx) {
    if (asChild && React.isValidElement(children)) {
      return React.cloneElement(children, { ref, className: cn(children.props.className || "", className), ...props });
    }
    return (
      <button ref={ref} className={cn("", className)} {...props}>
        {children}
      </button>
    );
  }

  const { open, setOpen } = ctx;

  const handleClick = (e) => {
    children?.props?.onClick?.(e);
    setOpen(true);
  };

  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(children, {
      ref,
      onClick: handleClick,
      className: cn(children.props.className || "", className),
      ...props,
    });
  }

  return (
    <button
      ref={ref}
      onClick={() => setOpen(true)}
      className={cn("inline-flex items-center px-3 py-2 rounded", className)}
      {...props}
    >
      {children}
    </button>
  );
});
DialogTrigger.displayName = "DialogTrigger";

export const DialogContent = React.forwardRef(({ className, children, ...props }, ref) => {
  const ctx = useContext(DialogContext);
  const open = ctx?.open ?? false;
  const setOpen = ctx?.setOpen;

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="fixed inset-0 bg-black/60"
        onClick={() => setOpen?.(false)}
        aria-hidden="true"
      />
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        className={cn(
          "relative z-10 w-full max-w-2xl rounded-lg bg-white p-6 shadow-lg max-h-[90vh] overflow-y-auto",
          className
        )}
        {...props}
      >
        {children}
      </div>
    </div>
  );
});
DialogContent.displayName = "DialogContent";

export const DialogHeader = React.forwardRef(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("mb-4", className)} {...props} />
));
DialogHeader.displayName = "DialogHeader";

export const DialogTitle = React.forwardRef(({ className, ...props }, ref) => (
  <h2 ref={ref} className={cn("text-lg font-semibold", className)} {...props} />
));
DialogTitle.displayName = "DialogTitle";
