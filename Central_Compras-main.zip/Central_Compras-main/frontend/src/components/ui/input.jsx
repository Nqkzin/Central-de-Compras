import React from "react";
import { cn } from "@/lib/utils";

const Input = React.forwardRef(({ className, type, ...props }, ref) => {
  return (
    <input
      type={type}
      className={cn(
        /* Layout & Box Model */ "flex h-10 w-full px-3 py-2",
        /* Aparência Visual */ "rounded-md border border-gray-300 bg-background", 
        /* Tipografia */ "text-sm file:text-sm file:font-medium",
        /* Estados Especiais */ "placeholder:text-muted-foreground file:border-0 file:bg-transparent",
        /* Estados Interativos */ "ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        /* Estado Desabilitado */ "disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      ref={ref}
      {...props}
    />
  );
});
Input.displayName = "Input";

export { Input };