// src/components/ui/select.jsx
import React, { createContext, useContext, useState } from 'react';
import { cn } from '@/lib/utils';

const SelectContext = createContext(null);

export const Select = React.forwardRef(({ value: valueProp, onValueChange, children, className, ...props }, ref) => {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(valueProp ?? null);

  // keep controlled if valueProp provided
  React.useEffect(() => {
    if (typeof valueProp !== 'undefined') setValue(valueProp);
  }, [valueProp]);

  const handleChange = (val) => {
    if (onValueChange) onValueChange(val);
    else setValue(val);
    setOpen(false);
  };

  return (
    <SelectContext.Provider value={{ open, setOpen, value, onValueChange: handleChange }}>
      <div ref={ref} className={cn("relative w-full", className)} {...props}>
        {children}
      </div>
    </SelectContext.Provider>
  );
});
Select.displayName = "Select";

/* Trigger renders a button — toggles open in context */
export const SelectTrigger = React.forwardRef(({ children, className, asChild = false, ...props }, ref) => {
  const ctx = useContext(SelectContext);
  if (!ctx) {
    if (asChild && React.isValidElement(children)) {
      return React.cloneElement(children, { ref, className: cn(children.props.className || "", className), ...props });
    }
    return <button ref={ref} className={cn("px-3 py-2 rounded border", className)} {...props}>{children}</button>;
  }
  const { open, setOpen, value } = ctx;

  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(children, {
      ref,
      onClick: (e) => {
        children.props?.onClick?.(e);
        setOpen(!open);
      },
      className: cn(children.props.className || "", className),
      ...props,
    });
  }

  return (
    <button
      ref={ref}
      onClick={() => setOpen(!open)}
      type="button"
      className={cn(
        "flex items-center justify-between w-full h-10 px-3 rounded-md border border-gray-300 bg-background text-sm ring-offset-background transition-colors focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 hover:bg-gray-50",
        className
      )}
      {...props}
    >
      {children}
      <span className="ml-2 text-muted-foreground">▼</span>
    </button>
  );
});
SelectTrigger.displayName = "SelectTrigger";

/* Value component (for placeholder display) */
export const SelectValue = ({ children, placeholder }) => {
  const ctx = useContext(SelectContext);
  const display = ctx?.value ?? '';
  return <span className={cn("truncate")}>{display || placeholder || children}</span>;
};
SelectValue.displayName = "SelectValue";

/* Content: floating panel */
export const SelectContent = React.forwardRef(({ children, className, ...props }, ref) => {
  const ctx = useContext(SelectContext);
  if (!ctx) return null;
  const { open } = ctx;
  if (!open) return null;

  return (
    <div
      ref={ref}
      role="menu"
      className={cn(
        "absolute left-0 mt-1 w-full rounded-md border border-gray-200 bg-white shadow-sm z-50 max-h-56 overflow-auto",
        className
      )}
      {...props}
    >
      <div className="py-1">{children}</div>
    </div>
  );
});
SelectContent.displayName = "SelectContent";

/* SelectItem: button that calls onValueChange and closes */
export const SelectItem = React.forwardRef(({ value, children, className, ...props }, ref) => {
  const ctx = useContext(SelectContext);
  const handleClick = (e) => {
    ctx?.onValueChange?.(value);
  };

  return (
    <button
      ref={ref}
      role="menuitem"
      type="button"
      onClick={handleClick}
      className={cn("w-full text-left px-3 py-2 text-sm hover:bg-gray-100 focus:bg-gray-100 focus:outline-none", className)}
      {...props}
    >
      {children}
    </button>
  );
});
SelectItem.displayName = "SelectItem";

export default Select;
