// src/components/ui/sidebar.jsx
import React, { createContext, useContext, useState } from 'react';
import { cn } from '@/lib/utils';

/**
 * Sidebar context/provider
 */
const SidebarContext = createContext({});

export const SidebarProvider = ({ children, ...props }) => {
  const [open, setOpen] = useState(false);
  
  return (
    <SidebarContext.Provider value={{ open, setOpen }}>
      {children}
    </SidebarContext.Provider>
  );
};

export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error('useSidebar must be used within a SidebarProvider');
  }
  return context;
};

export const Sidebar = ({ className, children, ...props }) => {
  const { open } = useSidebar();

  return (
    <div
      className={cn(
        // controla visibilidade em mobile com translate e z-index
        "fixed inset-y-0 left-0 z-40 transform bg-background border-r transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0 lg:inset-auto lg:h-screen lg:w-64",
        open ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        className
      )}
      {...props}
    >
      <div className="h-full flex flex-col">
        {children}
      </div>
    </div>
  );
};

export const SidebarHeader = ({ className, ...props }) => (
  <div className={cn("flex items-center px-6 py-4", className)} {...props} />
);

export const SidebarContent = ({ className, ...props }) => (
  <div className={cn("flex-1 overflow-auto", className)} {...props} />
);

export const SidebarFooter = ({ className, ...props }) => (
  <div className={cn("mt-auto p-4", className)} {...props} />
);

export const SidebarGroup = ({ className, ...props }) => (
  <div className={cn("px-3 py-2", className)} {...props} />
);

export const SidebarGroupLabel = ({ className, ...props }) => (
  <div className={cn("px-2 py-1 text-xs font-semibold", className)} {...props} />
);

export const SidebarGroupContent = ({ className, ...props }) => (
  <div className={cn("space-y-1", className)} {...props} />
);

export const SidebarMenu = ({ className, ...props }) => (
  <nav className={cn("flex flex-col space-y-1", className)} {...props} />
);

export const SidebarMenuItem = ({ className, ...props }) => (
  <div className={cn("", className)} {...props} />
);

export const SidebarMenuButton = React.forwardRef(({ className, asChild = false, children, ...props }, ref) => {
  // remova props inválidas do DOM
  const { onOpenChange, ...pass } = props;

  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(children, {
      ref,
      className: cn(children.props.className || "", className),
      ...pass,
    });
  }

  return (
    <button
      ref={ref}
      className={cn(
        "flex items-center gap-2 rounded-md px-3 py-2 text-base font-medium transition-colors hover:bg-accent hover:text-accent-foreground",
        className
      )}
      {...pass}
    />
  );
});
SidebarMenuButton.displayName = "SidebarMenuButton";

export const SidebarTrigger = React.forwardRef(({ className, asChild = false, children, ...props }, ref) => {
  const { open, setOpen } = useSidebar();

  const toggle = (e) => {
    e?.preventDefault?.();
    setOpen(!open);
  };

  // Remover props que não devam ir ao DOM
  const { onOpenChange, ...pass } = props;

  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(children, {
      ref,
      onClick: (ev) => {
        children.props?.onClick?.(ev);
        toggle(ev);
      },
      className: cn(children.props.className || "", className),
      ...pass,
    });
  }

  return (
    <button
      ref={ref}
      onClick={toggle}
      className={cn("p-2 rounded-lg inline-flex items-center justify-center", className)}
      {...pass}
    >
      {children}
    </button>
  );
});
SidebarTrigger.displayName = "SidebarTrigger";