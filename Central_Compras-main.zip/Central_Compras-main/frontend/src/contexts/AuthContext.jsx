import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '@/services/apiClient';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      if (!token) {
        setLoading(false);
        return;
      }
      const me = await apiClient.auth.me();
      setUser(me);
      // Se usuário de loja e não houver contexto ativo, define para a loja única
      try {
        const currentActive = localStorage.getItem('active_store_id');
        if (!currentActive && me?.store_id) {
          localStorage.setItem('active_store_id', String(me.store_id));
        }
      } catch {}
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('auth_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (credentials) => {
    const result = await apiClient.auth.login(credentials);
    setUser(result.user);
    try {
      localStorage.removeItem('active_store_id');
      if (result?.user?.store_id) {
        localStorage.setItem('active_store_id', String(result.user.store_id));
      }
    } catch {}
    if (result.require_password_change) {
      // marcar flag local e redirecionar para página de troca
      localStorage.setItem('must_change_password', '1');
      window.location.href = '/change-password';
    } else {
      localStorage.removeItem('must_change_password');
    }
    return result;
  };

  const logout = () => {
    try {
      // Se apiClient.auth.logout existir e for necessário, pode manter
      if (apiClient?.auth?.logout) {
        apiClient.auth.logout();
      }
    } catch (e) {
      console.warn("Logout API failed:", e);
    }

    // remove token localmente e limpa user no contexto
    localStorage.removeItem('auth_token');
    // limpar também contexto de loja ativa
    try {
      localStorage.removeItem('active_store_id');
    } catch {}
    setUser(null);

    // redirecionamento simples (rota de login)
    window.location.href = '/login';
  };

  const value = {
    user,
    login,
    logout,
    loading,
    mustChangePassword: localStorage.getItem('must_change_password') === '1'
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};